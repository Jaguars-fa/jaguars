import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import fetch from "node-fetch";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Email API
  app.post("/api/send-email", async (req, res) => {
    const { to, subject, text, html, smtp } = req.body;

    const host = smtp?.host || process.env.EMAIL_HOST || "smtp.gmail.com";
    const port = parseInt(smtp?.port || process.env.EMAIL_PORT || "587");
    let secure = smtp?.secure !== undefined ? smtp.secure : (process.env.EMAIL_SECURE === "true");
    
    // If secure is not explicitly provided, infer it from the port
    if (smtp?.secure === undefined && process.env.EMAIL_SECURE === undefined) {
      secure = port === 465;
    }

    const user = smtp?.user || process.env.EMAIL_USER;
    const pass = smtp?.pass || process.env.EMAIL_PASS;

    if (!user || !pass) {
      console.error("Email credentials not configured");
      return res.status(500).json({ error: "Email service not configured" });
    }

    const transporter = nodemailer.createTransport({
      host,
      port,
      secure,
      auth: {
        user,
        pass,
      },
      tls: {
        // Do not fail on invalid certs
        rejectUnauthorized: false,
      },
      connectionTimeout: 10000, // 10 seconds
      greetingTimeout: 10000,   // 10 seconds
      debug: true,
      logger: true,
    });

    try {
      await transporter.sendMail({
        from: `"Member Management" <${user}>`,
        to,
        subject,
        text,
        html,
      });
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error sending email:", error);
      
      let errorMessage = error.message;
      if (error.code === 'EAUTH' || (error.message && error.message.includes('535-5.7.8'))) {
        errorMessage = "Authentication failed. If you are using Gmail, please ensure you are using an 'App Password' and not your regular account password. 2-Step Verification must be enabled to create an App Password.";
      }

      res.status(500).json({ 
        error: "Failed to send email", 
        details: errorMessage,
        code: error.code,
        command: error.command
      });
    }
  });

  // WhatsApp API Proxy
  app.post("/api/whatsapp/send", async (req, res) => {
    const { url, token, to, body } = req.body;

    if (!url || !token || !to || !body) {
      return res.status(400).json({ error: "Missing required parameters" });
    }

    try {
      const params = new URLSearchParams();
      params.append('token', token);
      params.append('to', to);
      params.append('body', body);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: params
      });

      const result = await response.json();
      res.json(result);
    } catch (error: any) {
      console.error("Error proxying WhatsApp message:", error);
      res.status(500).json({ error: "Failed to send WhatsApp message via proxy", details: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false, // Explicitly disable HMR to prevent websocket connection errors
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
