export interface Member {
  id: string;
  name: string;
  nameArabic?: string;
  nationality?: string;
  email: string;
  phone?: string;
  whatsapp?: string;
  birthday?: string;
  category?: string;
  emiratesId?: string;
  profileImage?: string;
  idImage?: string;
  status: string;
  joinedAt: string;
  uid: string;
  location?: string;
  ageGroup?: string;
  level?: string;
  coach?: string;
  activity?: string;
  parentsInformation?: string;
  receivedKit?: boolean;
  joinedWhatsApp?: boolean;
}

export interface Attendance {
  id: string;
  memberId: string;
  memberEmail?: string;
  date: string; // YYYY-MM-DD
  status: 'present' | 'absent';
  uid: string;
  notified?: boolean;
}

export interface Payment {
  id: string;
  memberId: string;
  memberEmail?: string;
  amount: number;
  date: string; // YYYY-MM-DD
  type: string;
  feesDescription?: string;
  period?: string;
  paymentOption?: string;
  status: string;
  uid: string;
  startDate?: string; // YYYY-MM-DD
  endDate?: string;   // YYYY-MM-DD
}

export interface AppConfig {
  id: string;
  registrationEnabled: boolean;
  trialEnabled?: boolean;
  trialTermsAndConditions?: string;
  logoUrl?: string;
  clubName?: string;
  emailNotifications: {
    attendance: boolean;
    attendancePresent: boolean;
    attendanceAbsent: boolean;
    payment: boolean;
    registration: boolean;
    evaluation: boolean;
    trial: boolean;
    reminder: boolean;
    kit: boolean;
    whatsapp: boolean;
    combineOnboardingEmails: boolean;
  };
  smtp: {
    host: string;
    port: number;
    secure: boolean;
    user: string;
    pass: string;
  };
  templates: {
    registration: { subject: string; body: string };
    attendance: { subject: string; body: string };
    payment: { subject: string; body: string };
    reminder: { subject: string; body: string };
    evaluation: { subject: string; body: string };
    trial_approved: { subject: string; body: string };
    trial_rejected: { subject: string; body: string };
    kit: { subject: string; body: string };
    whatsapp: { subject: string; body: string };
    onboarding_combined: { subject: string; body: string };
  };
  lists?: {
    locations: string[];
    ageGroups: string[];
    levels: string[];
    coaches: string[];
    activities: string[];
    memberCategories: string[];
    memberStatuses: string[];
    paymentTypes: string[];
    paymentStatuses: string[];
    expenseCategories: string[];
    feesDescriptions: string[];
    periods: string[];
    paymentOptions: string[];
  };
  evaluationSettings?: {
    categories: {
      id: string;
      name: string;
      activity?: string; // Link to activity name from config.lists.activities
      skills: {
        id: string;
        name: string;
        description?: string;
      }[];
    }[];
  };
  termsAndConditions?: string;
  publicInfo?: {
    information: string;
    informationArabic?: string;
    locations: string;
    locationsArabic?: string;
    activities: string;
    activitiesArabic?: string;
    programs: string;
    programsArabic?: string;
    calendar: string;
    calendarArabic?: string;
    contact: string;
    contactArabic?: string;
    heroTitle?: string;
    heroTitleArabic?: string;
    heroSubtitle?: string;
    heroSubtitleArabic?: string;
    heroDescription?: string;
    heroDescriptionArabic?: string;
    heroImageUrl?: string;
    joinTitle?: string;
    joinTitleArabic?: string;
    joinSubtitle?: string;
    joinSubtitleArabic?: string;
    joinDescription?: string;
    joinDescriptionArabic?: string;
    aboutTitle?: string;
    aboutTitleArabic?: string;
    aboutSubtitle?: string;
    aboutSubtitleArabic?: string;
    activitiesTitle?: string;
    activitiesTitleArabic?: string;
    activitiesSubtitle?: string;
    activitiesSubtitleArabic?: string;
    activitiesImageUrl?: string;
    programsTitle?: string;
    programsTitleArabic?: string;
    programsSubtitle?: string;
    programsSubtitleArabic?: string;
    programsImageUrl?: string;
    locationsTitle?: string;
    locationsTitleArabic?: string;
    locationsSubtitle?: string;
    locationsSubtitleArabic?: string;
    locationsImageUrl?: string;
    calendarTitle?: string;
    calendarTitleArabic?: string;
    calendarSubtitle?: string;
    calendarSubtitleArabic?: string;
    contactTitle?: string;
    contactTitleArabic?: string;
    contactSubtitle?: string;
    contactSubtitleArabic?: string;
    galleryTitle?: string;
    galleryTitleArabic?: string;
    gallerySubtitle?: string;
    gallerySubtitleArabic?: string;
    videosTitle?: string;
    videosTitleArabic?: string;
    videosSubtitle?: string;
    videosSubtitleArabic?: string;
    sectionOrder?: string[];
    vision?: string;
    visionArabic?: string;
    mission?: string;
    missionArabic?: string;
    values?: string;
    valuesArabic?: string;
    history?: string;
    historyArabic?: string;
    achievements?: string;
    achievementsArabic?: string;
    termsAndConditions?: string;
    termsAndConditionsArabic?: string;
    privacyPolicy?: string;
    privacyPolicyArabic?: string;
    refundPolicy?: string;
    refundPolicyArabic?: string;
    faq?: string;
    faqArabic?: string;
    contactEmail?: string;
    contactPhone?: string;
    contactAddress?: string;
    contactAddressArabic?: string;
    mapEmbedUrl?: string;
    facebook?: string;
    instagram?: string;
    twitter?: string;
    youtube?: string;
    tiktok?: string;
    snapchat?: string;
    whatsapp?: string;
    aboutDescription?: string;
    aboutDescriptionArabic?: string;
    aboutImageUrl?: string;
  };
  bankBalance?: number;
  cashBalance?: number;
  whatsapp?: {
    apiKey: string;
    instanceId: string;
    apiUrl: string;
    enabled: boolean;
  };
  uid: string;
}

export interface GalleryImage {
  id: string;
  url: string;
  caption?: string;
  captionArabic?: string;
  order: number;
  uid: string;
  createdAt: string;
  type: 'image' | 'video';
}

export interface SentEmail {
  id: string;
  to: string;
  subject: string;
  sentAt: string;
  type: 'attendance' | 'payment' | 'registration' | 'reminder' | 'evaluation' | 'trial_approved' | 'trial_rejected' | 'onboarding' | 'kit' | 'whatsapp' | 'onboarding_combined';
  uid: string;
}

export interface RegistrationRequest {
  id: string;
  name: string;
  nameArabic?: string;
  email: string;
  phone?: string;
  whatsapp?: string;
  birthday?: string;
  category?: string;
  nationality?: string;
  location?: string;
  ageGroup?: string;
  level?: string;
  coach?: string;
  activity?: string;
  parentsInformation?: string;
  profileImage?: string;
  idImage?: string;
  status: 'pending' | 'approved' | 'rejected';
  notes?: string;
  requestedAt: string;
  adminUid: string;
  preferredTime?: string;
}

export interface TrialRequest {
  id: string;
  name: string;
  email: string;
  phone: string;
  activity: string;
  preferredDate: string;
  location?: string;
  profileImage?: string;
  idImage?: string;
  notes?: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedAt: string;
  adminUid: string;
  preferredTime?: string;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  date: string; // YYYY-MM-DD
  category: string;
  description?: string;
  uid: string;
  createdAt: string;
}

export type UserRole = 'admin' | 'coach' | 'staff';

export interface Evaluation {
  id: string;
  memberId: string;
  coachId: string;
  date: string;
  scores: { [skillId: string]: number };
  notes?: string;
  status: 'pending' | 'approved';
  uid: string;
  createdAt: string;
}

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: 'active' | 'disabled';
  phone?: string;
  notes?: string;
  permissions?: string[];
  adminUid: string;
  createdAt: string;
  lastLogin?: string;
}

export interface AppState {
  members: Member[];
  attendance: Attendance[];
  payments: Payment[];
  config: AppConfig | null;
  sentEmails: SentEmail[];
  expenses: Expense[];
  users: UserAccount[];
  currentUserAccount: UserAccount | null;
  loading: boolean;
  user: any | null;
}
