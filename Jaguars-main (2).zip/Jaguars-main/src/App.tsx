import React, { useState, useEffect, useMemo } from 'react';
import { 
  onAuthStateChanged, 
  User,
  sendPasswordResetEmail
} from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  query, 
  where, 
  orderBy,
  addDoc,
  updateDoc,
  doc,
  deleteDoc,
  writeBatch,
  setDoc,
  getDocs,
  limit
} from 'firebase/firestore';
import { 
  Users,
  User as UserIcon,
  Calendar,
  CreditCard, 
  Plus, 
  Search, 
  LogOut, 
  LogIn, 
  CheckCircle2, 
  XCircle, 
  MoreVertical,
  Trash2,
  Edit2,
  Mail,
  ChevronRight,
  TrendingUp,
  Clock,
  Trophy,
  LayoutDashboard,
  Menu,
  X,
  Settings,
  History,
  Info,
  Server,
  FileText,
  Save,
  Check,
  Send,
  Image as ImageIcon,
  Camera,
  Printer,
  Download,
  Share2,
  PlusCircle,
  Star,
  ClipboardList,
  Wallet,
  Shield,
  Key,
  UserPlus,
  UserMinus,
  UserCheck,
  Link,
  Copy,
  MapPin,
  Activity,
  BookOpen,
  Phone,
  Globe,
  Languages,
  Play,
  Eye,
  ArrowRight,
  ArrowLeft,
  ChevronUp,
  ChevronDown,
  Loader2,
  MessageCircle,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  Music2,
  Ghost,
  ShieldCheck,
  Layers,
  Database,
  AlertCircle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { motion, AnimatePresence } from 'motion/react';
import { format, startOfMonth, endOfMonth, isWithinInterval, parseISO, startOfDay } from 'date-fns';
import Markdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { GoogleGenAI, Type } from "@google/genai";
import JSZip from 'jszip';

import { auth, db, login, logout, handleFirestoreError, OperationType } from './firebase';
import { Member, Attendance, Payment, AppConfig, SentEmail, RegistrationRequest, TrialRequest, Expense, UserAccount, UserRole, GalleryImage, Evaluation } from './types';
import ErrorBoundary from './components/ErrorBoundary';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Utility to compress image
const compressImage = (file: File, maxWidth = 600, maxHeight = 600, quality = 0.5): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('File is not an image'));
      return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height *= maxWidth / width;
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width *= maxHeight / height;
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Try to get under 300KB to leave room for other fields and documents
        let currentQuality = quality;
        let dataUrl = canvas.toDataURL('image/jpeg', currentQuality);
        
        // If still too large, reduce quality further
        while (dataUrl.length > 300000 && currentQuality > 0.1) {
          currentQuality -= 0.1;
          dataUrl = canvas.toDataURL('image/jpeg', currentQuality);
        }
        
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Failed to load image for compression'));
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
  });
};

// Utility to convert file to base64
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
  });
};

const BilingualInput = ({ 
  label, 
  enKey, 
  arKey, 
  placeholderEn, 
  placeholderAr, 
  localPublicInfo, 
  setLocalPublicInfo, 
  configLang, 
  bilingualMode 
}: { 
  label: string; 
  enKey: string; 
  arKey: string; 
  placeholderEn?: string; 
  placeholderAr?: string; 
  localPublicInfo: any; 
  setLocalPublicInfo: any; 
  configLang: 'en' | 'ar'; 
  bilingualMode: boolean;
}) => {
  if (bilingualMode) {
    return (
      <div className="space-y-3 p-5 bg-white rounded-2xl border border-zinc-200 shadow-sm">
        <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{label}</label>
        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold text-zinc-400 uppercase">English</span>
              <div className="h-px flex-1 bg-zinc-100"></div>
            </div>
            <input
              type="text"
              value={localPublicInfo[enKey] || ''}
              onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [enKey]: e.target.value })}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm"
              placeholder={placeholderEn}
            />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-zinc-100"></div>
              <span className="text-[9px] font-bold text-zinc-400 uppercase">Arabic</span>
            </div>
            <input
              type="text"
              value={localPublicInfo[arKey] || ''}
              onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [arKey]: e.target.value })}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm text-right font-arabic"
              placeholder={placeholderAr}
              dir="rtl"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
        {label} {configLang === 'ar' ? '(Arabic)' : '(English)'}
      </label>
      <input
        type="text"
        value={configLang === 'ar' ? (localPublicInfo[arKey] || '') : (localPublicInfo[enKey] || '')}
        onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [configLang === 'ar' ? arKey : enKey]: e.target.value })}
        className="w-full px-4 py-2.5 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm"
        placeholder={configLang === 'ar' ? placeholderAr : placeholderEn}
        dir={configLang === 'ar' ? 'rtl' : 'ltr'}
      />
    </div>
  );
};

const BilingualTextarea = ({ 
  label, 
  enKey, 
  arKey, 
  placeholderEn, 
  placeholderAr, 
  rows = 3, 
  localPublicInfo, 
  setLocalPublicInfo, 
  configLang, 
  bilingualMode 
}: { 
  label: string; 
  enKey: string; 
  arKey: string; 
  placeholderEn?: string; 
  placeholderAr?: string; 
  rows?: number; 
  localPublicInfo: any; 
  setLocalPublicInfo: any; 
  configLang: 'en' | 'ar'; 
  bilingualMode: boolean;
}) => {
  if (bilingualMode) {
    return (
      <div className="space-y-3 p-5 bg-white rounded-2xl border border-zinc-200 shadow-sm">
        <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{label}</label>
        <div className="grid grid-cols-1 gap-6">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-bold text-zinc-400 uppercase">English</span>
              <div className="h-px flex-1 bg-zinc-100"></div>
            </div>
            <textarea
              value={localPublicInfo[enKey] || ''}
              onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [enKey]: e.target.value })}
              rows={rows}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm resize-none"
              placeholder={placeholderEn}
            />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-zinc-100"></div>
              <span className="text-[9px] font-bold text-zinc-400 uppercase">Arabic</span>
            </div>
            <textarea
              value={localPublicInfo[arKey] || ''}
              onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [arKey]: e.target.value })}
              rows={rows}
              className="w-full px-4 py-2.5 bg-zinc-50 border border-zinc-100 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm text-right resize-none font-arabic"
              placeholder={placeholderAr}
              dir="rtl"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">
        {label} {configLang === 'ar' ? '(Arabic)' : '(English)'}
      </label>
      <textarea
        value={configLang === 'ar' ? (localPublicInfo[arKey] || '') : (localPublicInfo[enKey] || '')}
        onChange={(e) => setLocalPublicInfo({ ...localPublicInfo, [configLang === 'ar' ? arKey : enKey]: e.target.value })}
        rows={rows}
        className="w-full px-4 py-2.5 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900 transition-all text-sm resize-none"
        placeholder={configLang === 'ar' ? placeholderAr : placeholderEn}
        dir={configLang === 'ar' ? 'rtl' : 'ltr'}
      />
    </div>
  );
};

// Utility to send email via backend API and log to Firestore
const sendEmail = async (to: string, subject: string, text: string, type: 'attendance' | 'payment' | 'registration' | 'reminder' | 'evaluation' | 'trial_approved' | 'trial_rejected' | 'onboarding' | 'kit' | 'whatsapp' | 'onboarding_combined', uid: string, html?: string, smtp?: AppConfig['smtp']) => {
  try {
    const response = await fetch('/api/send-email', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ to, subject, text, html, smtp }),
    });
    const result = await response.json();
    
    if (result.success) {
      // Log to Firestore
      await addDoc(collection(db, 'sent_emails'), {
        to,
        subject,
        sentAt: new Date().toISOString(),
        type,
        uid
      });
    } else {
      console.error('Email API error:', result.error, result.details);
      return { success: false, error: result.details || result.error };
    }
    
    return result;
  } catch (error) {
    console.error('Error calling send-email API:', error);
    return { success: false, error };
  }
};

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick, badge }: { icon: any, label: string, active: boolean, onClick: () => void, badge?: number | string }) => (
  <button
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
      active 
        ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" 
        : "text-zinc-500 hover:bg-zinc-100 hover:text-zinc-900"
    )}
  >
    <Icon size={20} className={cn("transition-transform duration-200", active ? "scale-110" : "group-hover:scale-110")} />
    <span className="font-medium text-sm">{label}</span>
    {badge && (
      <span className="ml-auto bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[1.25rem] text-center">
        {badge}
      </span>
    )}
    {active && !badge && <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />}
  </button>
);

const StatCard = ({ label, value, icon: Icon, trend, color, onClick }: { label: string, value: string | number, icon: any, trend?: string, color: string, onClick?: () => void }) => (
  <div 
    onClick={onClick}
    className={cn(
      "bg-white p-6 rounded-2xl border border-zinc-100 shadow-sm hover:shadow-md transition-shadow duration-200",
      onClick && "cursor-pointer"
    )}
  >
    <div className="flex justify-between items-start mb-4">
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon size={24} className="text-white" />
      </div>
      {trend && (
        <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full flex items-center gap-1">
          <TrendingUp size={12} /> {trend}
        </span>
      )}
    </div>
    <p className="text-zinc-500 text-sm font-medium mb-1">{label}</p>
    <h3 className="text-2xl font-bold text-zinc-900">{value}</h3>
  </div>
);

const Modal = ({ isOpen, onClose, title, children, maxWidth = 'max-w-lg', variant = 'center' }: { isOpen: boolean, onClose: () => void, title: string, children: React.ReactNode, maxWidth?: string, variant?: 'center' | 'side' }) => (
  <AnimatePresence>
    {isOpen && (
      <div className={cn("fixed inset-0 z-50 flex p-4", variant === 'center' ? "items-center justify-center" : "justify-end p-0")}>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-zinc-900/40 backdrop-blur-sm"
        />
        <motion.div
          initial={variant === 'center' ? { opacity: 0, scale: 0.95, y: 20 } : { x: '100%' }}
          animate={variant === 'center' ? { opacity: 1, scale: 1, y: 0 } : { x: 0 }}
          exit={variant === 'center' ? { opacity: 0, scale: 0.95, y: 20 } : { x: '100%' }}
          transition={variant === 'side' ? { type: 'spring', damping: 25, stiffness: 200 } : undefined}
          className={cn(
            "relative bg-white shadow-2xl overflow-hidden flex flex-col",
            variant === 'center' ? cn("w-full rounded-3xl max-h-[90vh]", maxWidth) : "h-full w-full max-w-2xl"
          )}
        >
          <div className="px-8 py-6 border-b border-zinc-100 flex justify-between items-center bg-zinc-50/50 sticky top-0 z-10">
            <h3 className="text-2xl font-bold text-zinc-900">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-zinc-200 rounded-full transition-colors">
              <X size={24} className="text-zinc-500" />
            </button>
          </div>
          <div className="p-8 flex-1 overflow-y-auto custom-scrollbar">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

// --- Constants ---

const DEFAULT_LISTS = {
  locations: ['Main Gym', 'North Field', 'South Field'],
  ageGroups: ['U8', 'U10', 'U12', 'U14', 'U16', 'Senior'],
  levels: ['Beginner', 'Intermediate', 'Advanced', 'Elite'],
  coaches: ['Coach Ahmed', 'Coach Sarah', 'Coach John'],
  activities: ['Football', 'Basketball', 'Tennis', 'Swimming'],
  memberCategories: ['General', 'Elite', 'Scholarship'],
  memberStatuses: ['active', 'inactive'],
  paymentTypes: ['monthly', 'annual', 'other'],
  paymentStatuses: ['paid', 'pending'],
  expenseCategories: ['Coach Salary', 'Purchasing', 'Court Rent', 'Other'],
  feesDescriptions: ['Monthly Fee', 'Registration Fee', 'Kit Fee', 'Tournament Fee'],
  periods: ['1 Month', '3 Months', '6 Months', '12 Months'],
  paymentOptions: ['Cash', 'Transfer', 'Card']
};

// --- Helpers ---

const getEmbedUrl = (url: string) => {
  if (!url) return null;
  // YouTube
  const ytMatch = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (ytMatch) return `https://www.youtube.com/embed/${ytMatch[1]}`;
  
  // Vimeo
  const vimeoMatch = url.match(/(?:https?:\/\/)?(?:www\.)?vimeo\.com\/(\d+)/);
  if (vimeoMatch) return `https://player.vimeo.com/video/${vimeoMatch[1]}`;
  
  return null;
};

const getYoutubeThumbnail = (url: string) => {
  const ytMatch = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (ytMatch) return `https://img.youtube.com/vi/${ytMatch[1]}/maxresdefault.jpg`;
  return null;
};

const FilterBar = ({ 
  filters, 
  setFilters, 
  config, 
  activeTab, 
  showStatus = true 
}: { 
  filters: any, 
  setFilters: any, 
  config: any, 
  activeTab: string, 
  showStatus?: boolean 
}) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
    <div className="relative group lg:col-span-1">
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 group-focus-within:text-zinc-900 transition-colors" size={18} />
      <input
        type="text"
        placeholder="Search members..."
        value={filters.search}
        onChange={(e) => setFilters({ ...filters, search: e.target.value })}
        className="pl-12 pr-6 py-3 bg-white border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 focus:bg-white transition-all w-full shadow-sm font-medium"
      />
    </div>
    <div className="space-y-1.5">
      <select
        value={filters.coach}
        onChange={(e) => setFilters({ ...filters, coach: e.target.value })}
        className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-2xl text-sm focus:ring-2 focus:ring-zinc-900/10 outline-none shadow-sm"
      >
        <option value="">All Coaches</option>
        {config?.lists?.coaches.map(c => <option key={c} value={c}>{c}</option>)}
      </select>
    </div>
    <div className="space-y-1.5">
      <select
        value={filters.location}
        onChange={(e) => setFilters({ ...filters, location: e.target.value })}
        className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-2xl text-sm focus:ring-2 focus:ring-zinc-900/10 outline-none shadow-sm"
      >
        <option value="">All Locations</option>
        {config?.lists?.locations.map(l => <option key={l} value={l}>{l}</option>)}
      </select>
    </div>
    <div className="space-y-1.5">
      <select
        value={filters.ageGroup}
        onChange={(e) => setFilters({ ...filters, ageGroup: e.target.value })}
        className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-2xl text-sm focus:ring-2 focus:ring-zinc-900/10 outline-none shadow-sm"
      >
        <option value="">All Age Groups</option>
        {config?.lists?.ageGroups.map(a => <option key={a} value={a}>{a}</option>)}
      </select>
    </div>
    {showStatus && (
      <div className="space-y-1.5">
        <select
          value={filters.status}
          onChange={(e) => setFilters({ ...filters, status: e.target.value })}
          className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-2xl text-sm focus:ring-2 focus:ring-zinc-900/10 outline-none shadow-sm"
        >
          <option value="">All Statuses</option>
          {activeTab === 'members' ? (
            <>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </>
          ) : activeTab === 'payments' ? (
            <>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
            </>
          ) : activeTab === 'requests' ? (
            <>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </>
          ) : (
            <>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </>
          )}
        </select>
      </div>
    )}
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'members' | 'attendance' | 'payments' | 'evaluations' | 'expenses' | 'reports' | 'config' | 'requests' | 'users' | 'bulk_email' | 'whatsapp'>('dashboard');
  const [requestTab, setRequestTab] = useState<'registration' | 'trial'>('registration');
  const [configTab, setConfigTab] = useState<'notifications' | 'logs' | 'lists' | 'smtp' | 'templates' | 'data' | 'registration' | 'branding' | 'public_info' | 'evaluations' | 'backup' | 'whatsapp_config'>('notifications');
  const [expenseTab, setExpenseTab] = useState<'list' | 'bank'>('list');
  const [configLang, setConfigLang] = useState<'en' | 'ar'>('en');
  const [bilingualMode, setBilingualMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isPublicRegistration, setIsPublicRegistration] = useState(false);
  const [isPublicTrial, setIsPublicTrial] = useState(false);
  const [isViewingTerms, setIsViewingTerms] = useState(false);
  const [isPublicInfo, setIsPublicInfo] = useState(false);
  const [publicLang, setPublicLang] = useState<'en' | 'ar'>('en');
  const [publicAdminUid, setPublicAdminUid] = useState<string | null>(null);

  const [members, setMembers] = useState<Member[]>([]);
  const [attendance, setAttendance] = useState<Attendance[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [registrationRequests, setRegistrationRequests] = useState<RegistrationRequest[]>([]);
  const [trialRequests, setTrialRequests] = useState<TrialRequest[]>([]);
  const [galleryImages, setGalleryImages] = useState<GalleryImage[]>([]);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [localSmtp, setLocalSmtp] = useState<AppConfig['smtp'] | null>(null);
  const [localTemplates, setLocalTemplates] = useState<AppConfig['templates'] | null>(null);
  const [localNotifications, setLocalNotifications] = useState<AppConfig['emailNotifications'] | null>(null);
  const [localLists, setLocalLists] = useState<Required<AppConfig>['lists']>(DEFAULT_LISTS);
  const [localTerms, setLocalTerms] = useState<string>('');
  const [localTrialTerms, setLocalTrialTerms] = useState<string>('');
  const [localEvaluationSettings, setLocalEvaluationSettings] = useState<AppConfig['evaluationSettings']>({ categories: [] });
  const [globalFilters, setGlobalFilters] = useState({
    search: '',
    coach: '',
    location: '',
    ageGroup: '',
    status: ''
  });
  const [isAddingEvaluation, setIsAddingEvaluation] = useState(false);
  const [editingEvaluationId, setEditingEvaluationId] = useState<string | null>(null);
  const [newEvaluation, setNewEvaluation] = useState<Partial<Evaluation>>({
    date: new Date().toISOString(),
    scores: {},
    notes: '',
    status: 'approved'
  });
  const [localPublicInfo, setLocalPublicInfo] = useState<AppConfig['publicInfo']>({
    information: '',
    informationArabic: '',
    locations: '',
    locationsArabic: '',
    activities: '',
    activitiesArabic: '',
    programs: '',
    programsArabic: '',
    calendar: '',
    calendarArabic: '',
    contact: '',
    contactArabic: '',
    heroTitle: '',
    heroTitleArabic: '',
    heroSubtitle: '',
    heroSubtitleArabic: '',
    heroDescription: '',
    heroDescriptionArabic: '',
    heroImageUrl: '',
    joinTitle: '',
    joinTitleArabic: '',
    joinSubtitle: '',
    joinSubtitleArabic: '',
    joinDescription: '',
    joinDescriptionArabic: '',
    aboutTitle: '',
    aboutTitleArabic: '',
    aboutSubtitle: '',
    aboutSubtitleArabic: '',
    aboutDescription: '',
    aboutDescriptionArabic: '',
    aboutImageUrl: '',
    vision: '',
    visionArabic: '',
    mission: '',
    missionArabic: '',
    values: '',
    valuesArabic: '',
    history: '',
    historyArabic: '',
    achievements: '',
    achievementsArabic: '',
    termsAndConditions: '',
    termsAndConditionsArabic: '',
    privacyPolicy: '',
    privacyPolicyArabic: '',
    refundPolicy: '',
    refundPolicyArabic: '',
    faq: '',
    faqArabic: '',
    contactEmail: '',
    contactPhone: '',
    contactAddress: '',
    contactAddressArabic: '',
    mapEmbedUrl: '',
    facebook: '',
    instagram: '',
    twitter: '',
    youtube: '',
    tiktok: '',
    snapchat: '',
    whatsapp: '',
    sectionOrder: ['images', 'videos', 'about', 'activities', 'programs', 'locations', 'calendar', 'contact'],
  });
  const [localBrandingInfo, setLocalBrandingInfo] = useState<{ clubName: string; logoUrl: string }>({
    clubName: '',
    logoUrl: ''
  });

  const [zoomedImage, setZoomedImage] = useState<string | null>(null);
  const [showAllImages, setShowAllImages] = useState(false);
  const [showAllVideos, setShowAllVideos] = useState(false);
  const [isFullGallery, setIsFullGallery] = useState(false);
  const [isFullVideos, setIsFullVideos] = useState(false);
  const [playingVideoId, setPlayingVideoId] = useState<string | null>(null);
  const [isVideoInputOpen, setIsVideoInputOpen] = useState(false);
  const [videoUrlInput, setVideoUrlInput] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [agreedToTrialTerms, setAgreedToTrialTerms] = useState(false);
  const [isSaving, setIsSaving] = useState<string | null>(null);
  const [justSaved, setJustSaved] = useState<string | null>(null);
  const [isBackingUp, setIsBackingUp] = useState<'data' | 'system' | 'attachments' | null>(null);
  const [isUploadingGallery, setIsUploadingGallery] = useState(false);
  const [isAttendanceSaving, setIsAttendanceSaving] = useState(false);
  const [sentEmails, setSentEmails] = useState<SentEmail[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [currentUserAccount, setCurrentUserAccount] = useState<UserAccount | null>(null);
  const [isAppReady, setIsAppReady] = useState(false);
  const [copied, setCopied] = useState(false);

  const [selectedBulkMemberIds, setSelectedBulkMemberIds] = useState<Set<string>>(new Set());
  const [bulkEmailSubject, setBulkEmailSubject] = useState('');
  const [bulkEmailBody, setBulkEmailBody] = useState('');
  const [isSendingBulk, setIsSendingBulk] = useState(false);
  const [bulkSendProgress, setBulkSendProgress] = useState({ current: 0, total: 0 });

  const [selectedWhatsappMemberIds, setSelectedWhatsappMemberIds] = useState<Set<string>>(new Set());
  const [whatsappMessage, setWhatsappMessage] = useState('');
  const [isSendingWhatsapp, setIsSendingWhatsapp] = useState(false);
  const [whatsappSendProgress, setWhatsappSendProgress] = useState({ current: 0, total: 0 });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'member' | 'payment' | 'attendance' | 'expense' | 'user' | 'evaluation' | 'registration_request' | 'trial_request'>('member');
  const [editingItem, setEditingItem] = useState<any>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [memberRecord, setMemberRecord] = useState<Member | null>(null);
  const [regProfileImage, setRegProfileImage] = useState<string | null>(null);
  const [regIdImage, setRegIdImage] = useState<string | null>(null);
  const [trialProfileImage, setTrialProfileImage] = useState<string | null>(null);
  const [trialIdImage, setTrialIdImage] = useState<string | null>(null);

  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState('');
  const [userStatusFilter, setUserStatusFilter] = useState('');

  const isAdmin = currentUserAccount?.role === 'admin' || user?.email === "anafj246@gmail.com";
  const isCoach = currentUserAccount?.role === 'coach';
  const isStaff = currentUserAccount?.role === 'staff';
  const isManagement = isAdmin || isCoach || isStaff;
  const currentAdminUid = currentUserAccount?.adminUid || user?.uid;

  const AVAILABLE_PAGES = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'coach', 'staff'] },
    { id: 'members', label: 'Members', icon: Users, roles: ['admin', 'coach', 'staff'] },
    { id: 'requests', label: 'Requests', icon: Plus, roles: ['admin', 'staff'] },
    { id: 'attendance', label: 'Attendance', icon: Calendar, roles: ['admin', 'coach', 'staff'] },
    { id: 'payments', label: 'Payments', icon: CreditCard, roles: ['admin', 'coach'] },
    { id: 'evaluations', label: 'Evaluations', icon: Trophy, roles: ['admin', 'coach'] },
    { id: 'expenses', label: 'Expenses', icon: Wallet, roles: ['admin'] },
    { id: 'users', label: 'Users', icon: Shield, roles: ['admin'] },
    { id: 'reports', label: 'Reports', icon: FileText, roles: ['admin'] },
    { id: 'bulk_email', label: 'Bulk Email', icon: Mail, roles: ['admin'] },
    { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle, roles: ['admin'] },
    { id: 'config', label: 'Configuration', icon: Settings, roles: ['admin'] },
  ];

  const hasPermission = (pageId: string) => {
    if (user?.email === "anafj246@gmail.com") return true;
    if (!currentUserAccount) return false;
    if (currentUserAccount.role === 'admin') return true;
    
    // Check granular permissions first
    if (currentUserAccount.permissions && currentUserAccount.permissions.length > 0) {
      return currentUserAccount.permissions.includes(pageId);
    }
    
    // Fallback to role-based defaults
    const page = AVAILABLE_PAGES.find(p => p.id === pageId);
    return page?.roles.includes(currentUserAccount.role) || false;
  };

  const [reportType, setReportType] = useState<'attendance' | 'members' | 'payments' | 'expenses' | 'evaluations'>('members');
  const [reportDate, setReportDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [reportDateRange, setReportDateRange] = useState({ 
    start: format(new Date(new Date().getFullYear(), new Date().getMonth(), 1), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd')
  });
  const [reportCategory, setReportCategory] = useState('all');
  const [reportMemberId, setReportMemberId] = useState<string>('');
  const [reportPaymentStatus, setReportPaymentStatus] = useState<string>('');
  const [reportMemberStatus, setReportMemberStatus] = useState<string>('');
  const [reportAgeGroup, setReportAgeGroup] = useState<string>('');
  const [reportLocation, setReportLocation] = useState<string>('');
  const [reportLevel, setReportLevel] = useState<string>('');
  const [reportCoach, setReportCoach] = useState<string>('');
  const [reportMemberCategory, setReportMemberCategory] = useState<string>('');
  const [reportBirthday, setReportBirthday] = useState<string>('');
  const [reportBirthdayYear, setReportBirthdayYear] = useState<string>('');
  const [reportNationality, setReportNationality] = useState<string>('');
  const [reportAttendanceStatus, setReportAttendanceStatus] = useState<string>('');
  const [reportEvaluationStatus, setReportEvaluationStatus] = useState<string>('');
  const [scannedData, setScannedData] = useState<Partial<Member>>({});
  const [removedAttachments, setRemovedAttachments] = useState<Set<string>>(new Set());
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: 'members' | 'payments' | 'attendance' | 'sent_emails' | 'expenses' | 'users' | 'registration_requests' | 'trial_requests' | 'evaluations', id: string, label: string } | null>(null);
  const [selectedAttendanceDate, setSelectedAttendanceDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [memberSearch, setMemberSearch] = useState('');
  const [isMemberDropdownOpen, setIsMemberDropdownOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const regParam = params.get('reg');
    const adminParam = params.get('admin');
    const registerParam = params.get('register');
    const viewParam = params.get('view');

    if (regParam) {
      setPublicAdminUid(regParam);
      setIsPublicRegistration(true);
      setIsPublicInfo(true);
    } else if (registerParam === 'true' && adminParam) {
      setIsPublicRegistration(true);
      setPublicAdminUid(adminParam);
      setIsPublicInfo(true);
    } else if (adminParam) {
      setPublicAdminUid(adminParam);
      setIsPublicInfo(true);
      if (viewParam === 'gallery') {
        setIsFullGallery(true);
      } else if (viewParam === 'videos') {
        setIsFullVideos(true);
      }
    }
  }, []);

  useEffect(() => {
    if (isFullGallery || isFullVideos || isPublicInfo) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [isFullGallery, isFullVideos, isPublicInfo]);

  useEffect(() => {
    if (!isModalOpen) {
      setScannedData({});
      setRemovedAttachments(new Set());
      setMemberSearch('');
      setIsMemberDropdownOpen(false);
      setSelectedMember(null);
      setIsAddingEvaluation(false);
      setEditingEvaluationId(null);
    }
  }, [isModalOpen]);

  useEffect(() => {
    if (publicAdminUid && !user) {
      const unsubscribe = onSnapshot(doc(db, 'configs', publicAdminUid), (snapshot) => {
        if (snapshot.exists()) {
          const docData = snapshot.data();
          const defaultStructure = {
            registrationEnabled: true,
            trialEnabled: true,
            trialTermsAndConditions: '',
            emailNotifications: { attendance: true, attendancePresent: true, attendanceAbsent: true, payment: true, registration: true, evaluation: true, trial: true, reminder: true, kit: true, whatsapp: true, combineOnboardingEmails: true },
            smtp: { host: 'smtp.gmail.com', port: 587, secure: false, user: '', pass: '' },
            templates: {
              registration: { subject: 'Registration Confirmation', body: 'Welcome to our club!' },
              attendance: { subject: 'Attendance Notification', body: 'Attendance recorded for today.' },
              payment: { subject: 'Payment Confirmation', body: 'Payment received. Thank you!' },
              reminder: { subject: 'Payment Reminder', body: 'This is a reminder for your upcoming payment.' },
              evaluation: { subject: 'Evaluation Assessment', body: 'Your evaluation has been recorded. Check your assessment details.' },
              trial_approved: { subject: 'Trial Session Approved', body: 'Hello {name},\n\nYour request for a trial session in {activity} on {date} at {location} has been approved!\n\nWe look forward to seeing you.\n\nBest regards,\nManagement' },
              trial_rejected: { subject: 'Trial Session Request Update', body: 'Hello {name},\n\nThank you for your interest in our club. Unfortunately, we are unable to accommodate your trial session request for {activity} at this time.\n\nBest regards,\nManagement' },
              kit: { subject: 'Kit Received Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have received your kit.\n\nBest regards,\nManagement' },
              whatsapp: { subject: 'WhatsApp Group Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have joined our WhatsApp group.\n\nBest regards,\nManagement' },
              onboarding_combined: { subject: 'Kit & WhatsApp Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have received your kit and joined our WhatsApp group.\n\nBest regards,\nManagement' }
            },
            lists: DEFAULT_LISTS
          };
          const data = {
            id: snapshot.id,
            ...defaultStructure,
            ...docData,
            emailNotifications: { ...defaultStructure.emailNotifications, ...docData.emailNotifications },
            smtp: { ...defaultStructure.smtp, ...docData.smtp },
            templates: { ...defaultStructure.templates, ...docData.templates },
            lists: { ...defaultStructure.lists, ...docData.lists },
            uid: publicAdminUid
          } as AppConfig;
          setConfig(prev => prev ? { ...data, publicInfo: prev.publicInfo || data.publicInfo } : data);
          if (data.publicInfo) {
            setLocalPublicInfo(data.publicInfo);
          }
        }
      }, (err) => console.error("Error loading config:", err));

      const unsubPublicConfig = onSnapshot(doc(db, 'public_configs', publicAdminUid), (snapshot) => {
        if (snapshot.exists()) {
          const publicData = snapshot.data();
          if (publicData.publicInfo) {
            setConfig(prev => prev ? { ...prev, publicInfo: publicData.publicInfo } : null);
            setLocalPublicInfo(prev => ({ ...prev, ...publicData.publicInfo }));
          }
        }
      }, (err) => console.error("Error loading public config:", err));

      const unsubGallery = onSnapshot(
        query(collection(db, 'gallery_images'), where('uid', '==', publicAdminUid), orderBy('order', 'asc')),
        (gallerySnapshot) => {
          setGalleryImages(gallerySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GalleryImage)));
        },
        (err) => console.error("Error loading gallery:", err)
      );

      return () => {
        unsubscribe();
        unsubPublicConfig();
        unsubGallery();
      };
    }
  }, [publicAdminUid, user]);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) {
        setLoading(false);
        setCurrentUserAccount(null);
        setIsAppReady(false);
      }
    });
    return unsubscribe;
  }, []);

  // Current User Account Listener
  useEffect(() => {
    if (!user) return;

    const unsubUserAccount = onSnapshot(doc(db, 'users', user.uid), async (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as UserAccount;
        if (data.status === 'disabled') {
          alert("Your account has been disabled. Please contact the administrator.");
          await auth.signOut();
          return;
        }
        setCurrentUserAccount({ id: snapshot.id, ...data });
        setIsAppReady(true);
      } else {
        // Check if there's an account with this email that hasn't been claimed (random ID)
        const q = query(collection(db, 'users'), where('email', '==', user.email), limit(1));
        const emailSnapshot = await getDocs(q);
        
        if (!emailSnapshot.empty) {
          const existingDoc = emailSnapshot.docs[0];
          const existingData = existingDoc.data() as UserAccount;
          
          if (existingData.status === 'disabled') {
            alert("Your account has been disabled. Please contact the administrator.");
            await auth.signOut();
            return;
          }

          // Claim this account by creating a new doc with UID and deleting the old one
          const { id, ...cleanData } = { ...existingData, lastLogin: new Date().toISOString() };
          await setDoc(doc(db, 'users', user.uid), cleanData);
          await deleteDoc(doc(db, 'users', existingDoc.id));
          
          setCurrentUserAccount({ id: user.uid, ...cleanData });
          setIsAppReady(true);
        } else if (user.email === "anafj246@gmail.com") {
          // Bootstrap first admin
          const newAdminData = {
            name: user.displayName || 'Admin',
            email: user.email,
            role: 'admin' as UserRole,
            status: 'active' as const,
            adminUid: user.uid,
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
          };
          await setDoc(doc(db, 'users', user.uid), newAdminData);
          setCurrentUserAccount({ id: user.uid, ...newAdminData });
          setIsAppReady(true);
        } else {
          // Not a registered user and not the bootstrap admin
          setCurrentUserAccount(null);
          setIsAppReady(true);
        }
      }
      setLoading(false);
    }, (err) => {
      console.error("Error fetching user account:", err);
      setLoading(false);
      setIsAppReady(true);
    });

    return unsubUserAccount;
  }, [user]);

  // Update lastLogin when app is ready
  useEffect(() => {
    if (isAppReady && currentUserAccount && user) {
      const now = new Date().toISOString();
      const lastLogin = currentUserAccount.lastLogin;
      
      // Only update if it's been more than 1 hour since last update to avoid excessive writes
      if (!lastLogin || (new Date(now).getTime() - new Date(lastLogin).getTime() > 3600000)) {
        const path = `users/${user.uid}`;
        updateDoc(doc(db, 'users', user.uid), { lastLogin: now })
          .catch(err => {
            console.error("Error updating last login:", err);
            handleFirestoreError(err, OperationType.UPDATE, path);
          });
      }
    }
  }, [isAppReady, currentUserAccount, user]);

  // Firestore Listeners
  useEffect(() => {
    if (!user || !isAppReady) return;

    const unsubscribers: (() => void)[] = [];

    if (isManagement && currentUserAccount) {
      const adminUid = currentUserAccount.adminUid;
      const role = currentUserAccount.role;

      // Common listeners for Admin, Coach, Staff
      const membersQuery = query(collection(db, 'members'), where('uid', '==', adminUid));
      unsubscribers.push(onSnapshot(membersQuery, (snapshot) => {
        setMembers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Member)));
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'members')));

      const attendanceQuery = query(collection(db, 'attendance'), where('uid', '==', adminUid));
      unsubscribers.push(onSnapshot(attendanceQuery, (snapshot) => {
        setAttendance(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Attendance)));
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'attendance')));

      // Admin & Coach listeners
      if (role === 'admin' || role === 'coach') {
        const paymentsQuery = query(collection(db, 'payments'), where('uid', '==', adminUid));
        unsubscribers.push(onSnapshot(paymentsQuery, (snapshot) => {
          setPayments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payment)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'payments')));

        const evaluationsQuery = query(collection(db, 'evaluations'), where('uid', '==', adminUid), orderBy('date', 'desc'));
        unsubscribers.push(onSnapshot(evaluationsQuery, (snapshot) => {
          setEvaluations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Evaluation)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'evaluations')));
      }

      // Admin only listeners
      if (role === 'admin') {
        const trialRequestsQuery = query(collection(db, 'trial_requests'), where('adminUid', '==', adminUid), orderBy('requestedAt', 'desc'));
        unsubscribers.push(onSnapshot(trialRequestsQuery, (snapshot) => {
          setTrialRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as TrialRequest)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'trial_requests')));

        unsubscribers.push(onSnapshot(doc(db, 'configs', adminUid), (snapshot) => {
          const defaultStructure = {
            registrationEnabled: true,
            trialEnabled: true,
            trialTermsAndConditions: '',
            emailNotifications: { attendance: true, attendancePresent: true, attendanceAbsent: true, payment: true, registration: true, evaluation: true, trial: true, reminder: true, kit: true, whatsapp: true, combineOnboardingEmails: true },
            smtp: { host: 'smtp.gmail.com', port: 587, secure: false, user: '', pass: '' },
            templates: {
              registration: { subject: 'Registration Confirmation', body: 'Hello {name},\n\nWelcome to our club! Your registration has been confirmed.\n\nBest regards,\nManagement' },
              attendance: { subject: 'Attendance Notification', body: 'Hello {name},\n\nYour attendance for today ({date}) has been recorded as: {status}.\n\nBest regards,\nManagement' },
              payment: { subject: 'Payment Confirmation', body: 'Hello {name},\n\nWe have received your payment of {amount} for {type} subscription.\n\nThank you!\nManagement' },
              reminder: { subject: 'Payment Reminder', body: 'Hello {name},\n\nThis is a friendly reminder that your payment of {amount} for {type} subscription is pending.\n\nPlease renew your subscription at your earliest convenience.\n\nBest regards,\nManagement' },
              evaluation: { subject: 'Evaluation Assessment', body: 'Hello {name},\n\nYour evaluation for {date} has been recorded.\n\nAssessment Details:\n{scores}\n\nNotes:\n{notes}\n\nBest regards,\nManagement' },
              trial_approved: { subject: 'Trial Session Approved', body: 'Hello {name},\n\nYour request for a trial session in {activity} on {date} at {location} has been approved!\n\nWe look forward to seeing you.\n\nBest regards,\nManagement' },
              trial_rejected: { subject: 'Trial Session Request Update', body: 'Hello {name},\n\nThank you for your interest in our club. Unfortunately, we are unable to accommodate your trial session request for {activity} at this time.\n\nBest regards,\nManagement' },
              kit: { subject: 'Kit Received Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have received your kit.\n\nBest regards,\nManagement' },
              whatsapp: { subject: 'WhatsApp Group Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have joined our WhatsApp group.\n\nBest regards,\nManagement' },
              onboarding_combined: { subject: 'Kit & WhatsApp Confirmation', body: 'Hello {name},\n\nThis is to confirm that you have received your kit and joined our WhatsApp group.\n\nBest regards,\nManagement' }
            },
            lists: DEFAULT_LISTS,
            evaluationSettings: { categories: [] }
          };

          if (snapshot.exists()) {
            const docData = snapshot.data();
            const data = {
              id: snapshot.id,
              ...defaultStructure,
              ...docData,
              emailNotifications: { ...defaultStructure.emailNotifications, ...docData.emailNotifications },
              smtp: { ...defaultStructure.smtp, ...docData.smtp },
              templates: { ...defaultStructure.templates, ...docData.templates },
              lists: { ...defaultStructure.lists, ...docData.lists },
              uid: adminUid
            } as AppConfig;
            
            setConfig(prev => prev ? { ...data, publicInfo: prev.publicInfo || data.publicInfo } : data);
            setLocalPublicInfo(prev => ({ ...prev, ...(data.publicInfo || {}) }));
            setLocalNotifications(prev => prev || data.emailNotifications);
            setLocalSmtp(prev => prev || data.smtp);
            setLocalTemplates(prev => prev || data.templates);
            setLocalLists(prev => (prev === DEFAULT_LISTS ? (data.lists || DEFAULT_LISTS) : prev));
            setLocalTerms(prev => prev || data.termsAndConditions || '');
            setLocalTrialTerms(prev => prev || data.trialTermsAndConditions || '');
            setLocalEvaluationSettings(prev => (prev?.categories.length === 0 ? (data.evaluationSettings || { categories: [] }) : prev));
            setLocalPublicInfo(prev => (prev.information === '' ? (data.publicInfo || {
              information: '',
              locations: '',
              activities: '',
              programs: '',
              calendar: '',
              contact: '',
              heroTitle: '',
              heroSubtitle: '',
              heroDescription: '',
              heroImageUrl: '',
              joinTitle: '',
              joinDescription: '',
              sectionOrder: ['images', 'videos', 'about', 'activities', 'programs', 'locations', 'calendar', 'contact']
            }) : prev));
            setLocalBrandingInfo(prev => (prev.clubName === '' && prev.logoUrl === '' ? {
              clubName: data.clubName || '',
              logoUrl: data.logoUrl || ''
            } : prev));
          } else {
            const defaultConfig = {
              ...defaultStructure,
              uid: adminUid
            };
            setDoc(doc(db, 'configs', adminUid), defaultConfig);
          }
        }, (err) => handleFirestoreError(err, OperationType.GET, 'configs')));

        if (adminUid && typeof adminUid === 'string' && adminUid.trim() !== '') {
          unsubscribers.push(onSnapshot(doc(db, 'public_configs', adminUid), (snapshot) => {
            if (snapshot.exists()) {
              const publicData = snapshot.data();
              if (publicData.publicInfo) {
                setConfig(prev => prev ? { ...prev, publicInfo: publicData.publicInfo } : null);
                setLocalPublicInfo(prev => ({ ...prev, ...publicData.publicInfo }));
              }
            }
          }, (err) => handleFirestoreError(err, OperationType.GET, 'public_configs')));
        }

        unsubscribers.push(onSnapshot(
          query(collection(db, 'gallery_images'), where('uid', '==', adminUid), orderBy('order', 'asc')),
          (gallerySnapshot) => {
            setGalleryImages(gallerySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as GalleryImage)));
          },
          (err) => handleFirestoreError(err, OperationType.LIST, 'gallery_images')
        ));

        const sentEmailsQuery = query(collection(db, 'sent_emails'), where('uid', '==', adminUid), orderBy('sentAt', 'desc'));
        unsubscribers.push(onSnapshot(sentEmailsQuery, (snapshot) => {
          setSentEmails(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as SentEmail)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'sent_emails')));

        const requestsQuery = query(collection(db, 'registration_requests'), where('adminUid', '==', adminUid), orderBy('requestedAt', 'desc'));
        unsubscribers.push(onSnapshot(requestsQuery, (snapshot) => {
          setRegistrationRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as RegistrationRequest)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'registration_requests')));

        const expensesQuery = query(collection(db, 'expenses'), where('uid', '==', adminUid), orderBy('date', 'desc'));
        unsubscribers.push(onSnapshot(expensesQuery, (snapshot) => {
          setExpenses(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Expense)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'expenses')));

        const usersQuery = query(collection(db, 'users'), where('adminUid', '==', adminUid));
        unsubscribers.push(onSnapshot(usersQuery, (snapshot) => {
          setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as UserAccount)));
        }, (err) => handleFirestoreError(err, OperationType.LIST, 'users')));
      }
    } else {
      // Member Listeners
      const memberQuery = query(collection(db, 'members'), where('email', '==', user.email));
      unsubscribers.push(onSnapshot(memberQuery, (snapshot) => {
        if (!snapshot.empty) {
          const m = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Member;
          setMemberRecord(m);
          setMembers([m]);
        } else {
          setMemberRecord(null);
          setMembers([]);
        }
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'members')));
    }

    return () => unsubscribers.forEach(unsub => unsub());
  }, [user, isAppReady, currentUserAccount, isManagement]);

  // Fetch member data (attendance/payments) once memberRecord is available
  useEffect(() => {
    if (!user || !memberRecord || isAdmin) return;

    const attendanceQuery = query(collection(db, 'attendance'), where('memberId', '==', memberRecord.id));
    const paymentsQuery = query(collection(db, 'payments'), where('memberId', '==', memberRecord.id));

    const unsubAttendance = onSnapshot(attendanceQuery, (snapshot) => {
      setAttendance(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Attendance)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'attendance'));

    const unsubPayments = onSnapshot(paymentsQuery, (snapshot) => {
      setPayments(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Payment)));
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'payments'));

    return () => {
      unsubAttendance();
      unsubPayments();
    };
  }, [user, memberRecord, isAdmin]);

  // --- Handlers ---

  useEffect(() => {
    if (editingItem && modalType === 'payment') {
      const member = members.find(m => m.id === editingItem.memberId);
      if (member) {
        setSelectedMember(member);
        setMemberSearch(member.name);
      }
    }
  }, [editingItem, modalType, members]);

  const handleSendBulkEmail = async () => {
    if (selectedBulkMemberIds.size === 0) {
      alert('Please select at least one member.');
      return;
    }
    if (!bulkEmailSubject || !bulkEmailBody) {
      alert('Please provide both subject and body.');
      return;
    }

    const selectedMembers = members.filter(m => selectedBulkMemberIds.has(m.id));
    setIsSendingBulk(true);
    setBulkSendProgress({ current: 0, total: selectedMembers.length });

    let successCount = 0;
    let failCount = 0;

    for (const member of selectedMembers) {
      if (!member.email) {
        failCount++;
        setBulkSendProgress(prev => ({ ...prev, current: prev.current + 1 }));
        continue;
      }

      // Replace placeholders
      const personalizedBody = bulkEmailBody
        .replace(/{{name}}/g, member.name)
        .replace(/{{email}}/g, member.email)
        .replace(/{{location}}/g, member.location || '')
        .replace(/{{ageGroup}}/g, member.ageGroup || '');

      const res = await sendEmail(
        member.email,
        bulkEmailSubject,
        personalizedBody,
        'reminder',
        config?.uid || user?.uid || '',
        personalizedBody.replace(/\n/g, '<br>'),
        config?.smtp
      );

      if (res.success) {
        successCount++;
      } else {
        failCount++;
      }

      setBulkSendProgress(prev => ({ ...prev, current: prev.current + 1 }));
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setIsSendingBulk(false);
    alert(`Bulk email sending complete!\nSuccess: ${successCount}\nFailed: ${failCount}`);
    setSelectedBulkMemberIds(new Set());
  };

  const handleSendWhatsappBulk = async () => {
    if (selectedWhatsappMemberIds.size === 0) {
      alert('Please select at least one member.');
      return;
    }
    if (!whatsappMessage) {
      alert('Please provide a message.');
      return;
    }
    if (!config?.whatsapp?.enabled || !config?.whatsapp?.apiKey || !config?.whatsapp?.instanceId) {
      alert('WhatsApp is not configured or enabled. Please check Configuration > WhatsApp Config.');
      return;
    }

    const selectedMembers = members.filter(m => selectedWhatsappMemberIds.has(m.id));
    setIsSendingWhatsapp(true);
    setWhatsappSendProgress({ current: 0, total: selectedMembers.length });

    let successCount = 0;
    let failCount = 0;

    for (const member of selectedMembers) {
      if (!member.phone && !member.whatsapp) {
        failCount++;
        setWhatsappSendProgress(prev => ({ ...prev, current: prev.current + 1 }));
        continue;
      }

      const phoneNumber = (member.whatsapp || member.phone || '').replace(/\D/g, '');
      if (!phoneNumber) {
        failCount++;
        setWhatsappSendProgress(prev => ({ ...prev, current: prev.current + 1 }));
        continue;
      }

      // Replace placeholders
      const personalizedMessage = whatsappMessage
        .replace(/{{name}}/g, member.name)
        .replace(/{{email}}/g, member.email)
        .replace(/{{location}}/g, member.location || '')
        .replace(/{{ageGroup}}/g, member.ageGroup || '');

      try {
        const url = `${config.whatsapp.apiUrl}/${config.whatsapp.instanceId}/messages/chat`;
        
        const response = await fetch('/api/whatsapp/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            url,
            token: config.whatsapp.apiKey,
            to: phoneNumber,
            body: personalizedMessage
          })
        });

        const result = await response.json();
        if (result.sent === 'true' || result.id) {
          successCount++;
        } else {
          failCount++;
        }
      } catch (err) {
        console.error("Error sending WhatsApp:", err);
        failCount++;
      }

      setWhatsappSendProgress(prev => ({ ...prev, current: prev.current + 1 }));
      await new Promise(resolve => setTimeout(resolve, 1000)); // Delay to avoid rate limiting
    }

    setIsSendingWhatsapp(false);
    alert(`WhatsApp bulk sending complete!\nSuccess: ${successCount}\nFailed: ${failCount}`);
    setSelectedWhatsappMemberIds(new Set());
  };

  const handleRejectRequest = async (requestId: string) => {
    try {
      await updateDoc(doc(db, 'registration_requests', requestId), { status: 'rejected' });
    } catch (error: any) {
      console.error("Error rejecting request:", error);
      alert("Failed to reject request.");
      handleFirestoreError(error, OperationType.UPDATE, 'registration_requests');
    }
  };

  const handleApproveRequest = async (request: RegistrationRequest) => {
    if (!user) return;
    try {
      const memberData: Omit<Member, 'id'> = {
        name: request.name,
        nameArabic: request.nameArabic || '',
        email: request.email,
        phone: request.phone || '',
        whatsapp: request.whatsapp || '',
        birthday: request.birthday || '',
        category: request.category || '',
        nationality: request.nationality || '',
        location: request.location || '',
        ageGroup: request.ageGroup || '',
        level: request.level || '',
        coach: request.coach || '',
        activity: request.activity || '',
        parentsInformation: request.parentsInformation || '',
        profileImage: request.profileImage || '',
        idImage: request.idImage || '',
        status: localLists.memberStatuses?.[0] || 'active',
        joinedAt: new Date().toISOString(),
        uid: currentAdminUid || user.uid
      };
      
      await addDoc(collection(db, 'members'), memberData);
      await updateDoc(doc(db, 'registration_requests', request.id), { status: 'approved' });
      
      if (config?.emailNotifications.registration) {
        await sendEmail(
          request.email,
          config.templates.registration.subject,
          config.templates.registration.body.replace('{name}', request.name),
          'registration',
          currentAdminUid || user.uid,
          undefined,
          config.smtp
        );
      }
    } catch (error: any) {
      console.error("Error approving request:", error);
      alert("Failed to approve request.");
      handleFirestoreError(error, OperationType.WRITE, 'members');
    }
  };

  const handleApproveTrialRequest = async (request: TrialRequest) => {
    if (!user || !config) return;
    try {
      await updateDoc(doc(db, 'trial_requests', request.id), { status: 'approved' });
      
      if (config.emailNotifications.trial) {
        await sendEmail(
          request.email,
          config.templates.trial_approved.subject,
          config.templates.trial_approved.body
            .replace('{name}', request.name)
            .replace('{activity}', request.activity)
            .replace('{date}', request.preferredDate)
            .replace('{location}', request.location || ''),
          'trial_approved',
          currentAdminUid || user.uid,
          undefined,
          config.smtp
        );
      }
      alert("Trial request approved and email sent!");
    } catch (error: any) {
      console.error("Error approving trial request:", error);
      alert("Failed to approve trial request.");
      handleFirestoreError(error, OperationType.UPDATE, 'trial_requests');
    }
  };

  const handleRejectTrialRequest = async (request: TrialRequest) => {
    if (!user || !config) return;
    try {
      await updateDoc(doc(db, 'trial_requests', request.id), { status: 'rejected' });
      
      if (config.emailNotifications.trial) {
        await sendEmail(
          request.email,
          config.templates.trial_rejected.subject,
          config.templates.trial_rejected.body
            .replace('{name}', request.name)
            .replace('{activity}', request.activity),
          'trial_rejected',
          currentAdminUid || user.uid,
          undefined,
          config.smtp
        );
      }
      alert("Trial request rejected and email sent!");
    } catch (error: any) {
      console.error("Error rejecting trial request:", error);
      alert("Failed to reject trial request.");
      handleFirestoreError(error, OperationType.UPDATE, 'trial_requests');
    }
  };

  const handleUpdateRegistrationRequest = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || isSubmitting || !editingItem) return;
    setIsSubmitting(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      const data = {
        name: formData.get('name') as string,
        email: formData.get('email') as string,
        status: formData.get('status') as any,
        notes: formData.get('notes') as string || ''
      };

      await updateDoc(doc(db, 'registration_requests', editingItem.id), data);
      setIsModalOpen(false);
      setEditingItem(null);
      alert("Registration request updated successfully!");
    } catch (err: any) {
      alert(err.message || "An error occurred while updating the request.");
      handleFirestoreError(err, OperationType.UPDATE, 'registration_requests');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpdateTrialRequest = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || isSubmitting || !editingItem) return;
    setIsSubmitting(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      const data = {
        name: formData.get('name') as string,
        email: formData.get('email') as string,
        status: formData.get('status') as any,
        notes: formData.get('notes') as string || ''
      };

      await updateDoc(doc(db, 'trial_requests', editingItem.id), data);
      setIsModalOpen(false);
      setEditingItem(null);
      alert("Trial request updated successfully!");
    } catch (err: any) {
      alert(err.message || "An error occurred while updating the request.");
      handleFirestoreError(err, OperationType.UPDATE, 'trial_requests');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddExpense = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    setIsSubmitting(true);
    const formData = new FormData(e.currentTarget);
    const data = {
      title: formData.get('title') as string,
      amount: Number(formData.get('amount')),
      date: formData.get('date') as string,
      category: formData.get('category') as Expense['category'],
      description: formData.get('description') as string,
      uid: currentAdminUid || user.uid,
      createdAt: editingItem?.createdAt || new Date().toISOString()
    };

    try {
      if (editingItem) {
        await updateDoc(doc(db, 'expenses', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'expenses'), data);
      }
      setIsModalOpen(false);
      setEditingItem(null);
    } catch (err: any) {
      alert(err.message || "An error occurred while saving the expense.");
      handleFirestoreError(err, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'expenses');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddMember = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || isSubmitting) return;
    setIsSubmitting(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      const name = formData.get('name') as string;
      const email = formData.get('email') as string;

      if (!name || !email) {
        alert("Name and Email are required.");
        setIsSubmitting(false);
        return;
      }
      
      const profileImgFile = formData.get('profileImageFile') as File;
      const idImgFile = formData.get('idImageFile') as File;
      
      let profileImage = removedAttachments.has('profileImage') ? '' : (editingItem?.profileImage || '');
      let idImage = removedAttachments.has('idImage') ? '' : (editingItem?.idImage || '');

      if (profileImgFile && profileImgFile.size > 0) {
        if (profileImgFile.size > 5 * 1024 * 1024) {
          throw new Error("Profile image is too large. Please select a file smaller than 5MB.");
        }
        if (profileImgFile.type.startsWith('image/')) {
          profileImage = await compressImage(profileImgFile);
        } else {
          if (profileImgFile.size > 800 * 1024) {
            throw new Error("Profile document (PDF) is too large. Please select a file smaller than 800KB.");
          }
          profileImage = await fileToBase64(profileImgFile);
        }
      }
      if (idImgFile && idImgFile.size > 0) {
        if (idImgFile.size > 5 * 1024 * 1024) {
          throw new Error("ID image is too large. Please select a file smaller than 5MB.");
        }
        if (idImgFile.type.startsWith('image/')) {
          idImage = await compressImage(idImgFile);
        } else {
          if (idImgFile.size > 800 * 1024) {
            throw new Error("ID document (PDF) is too large. Please select a file smaller than 800KB.");
          }
          idImage = await fileToBase64(idImgFile);
        }
      }

      // Final check for total document size (Firestore limit is 1MB)
      const estimatedSize = (profileImage.length + idImage.length) * 0.75; // rough estimate of original bytes
      if (profileImage.length + idImage.length > 900000) {
        throw new Error("The combined size of the profile image and ID document is too large for the database. Please use smaller files.");
      }

      const status = (formData.get('status') as any) || (localLists.memberStatuses?.[0] || 'active');
      const receivedKit = formData.get('receivedKit') === 'on';
      const joinedWhatsApp = formData.get('joinedWhatsApp') === 'on';

      const data = {
        name: (formData.get('name') as string) || '',
        nameArabic: (formData.get('nameArabic') as string) || '',
        nationality: (formData.get('nationality') as string) || '',
        email: (formData.get('email') as string) || '',
        phone: (formData.get('phone') as string) || '',
        whatsapp: (formData.get('whatsapp') as string) || '',
        birthday: (formData.get('birthday') as string) || '',
        category: (formData.get('category') as string) || 'General',
        emiratesId: (formData.get('emiratesId') as string) || '',
        location: (formData.get('location') as string) || '',
        ageGroup: (formData.get('ageGroup') as string) || '',
        level: (formData.get('level') as string) || '',
        coach: (formData.get('coach') as string) || '',
        activity: (formData.get('activity') as string) || '',
        parentsInformation: (formData.get('parentsInformation') as string) || '',
        profileImage,
        idImage,
        status,
        receivedKit,
        joinedWhatsApp,
        joinedAt: editingItem?.joinedAt || new Date().toISOString(),
        uid: currentAdminUid || user.uid
      };

      const sendOnboardingEmail = async (memberData: any, kit: boolean, whatsapp: boolean) => {
        if (!config) return;
        
        const sendKit = kit && config.emailNotifications.kit;
        const sendWhatsApp = whatsapp && config.emailNotifications.whatsapp;
        
        if (!sendKit && !sendWhatsApp) return;
        
        const replaceTags = (text: string) => {
          return text
            .replace(/{name}/g, memberData.name)
            .replace(/{date}/g, new Date().toLocaleDateString())
            .replace(/{status}/g, memberData.status);
        };

        // Check if we should combine emails
        if (sendKit && sendWhatsApp && config.emailNotifications.combineOnboardingEmails) {
          const subject = replaceTags(config.templates.onboarding_combined?.subject || "Kit & WhatsApp Confirmation");
          const body = replaceTags(config.templates.onboarding_combined?.body || `Hello ${memberData.name},\n\nThis is to confirm that you have received your kit and joined our WhatsApp group.\n\nBest regards,\nManagement`);
          
          await sendEmail(
            memberData.email,
            subject,
            body,
            'onboarding_combined',
            currentAdminUid || user.uid,
            `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
            config.smtp
          );
          return;
        }

        if (sendKit) {
          const subject = replaceTags(config.templates.kit?.subject || "Kit Received Confirmation");
          const body = replaceTags(config.templates.kit?.body || `Hello ${memberData.name},\n\nThis is to confirm that you have received your kit.\n\nBest regards,\nManagement`);
          
          await sendEmail(
            memberData.email,
            subject,
            body,
            'kit',
            currentAdminUid || user.uid,
            `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
            config.smtp
          );
        }

        if (sendWhatsApp) {
          const subject = replaceTags(config.templates.whatsapp?.subject || "WhatsApp Group Confirmation");
          const body = replaceTags(config.templates.whatsapp?.body || `Hello ${memberData.name},\n\nThis is to confirm that you have joined our WhatsApp group.\n\nBest regards,\nManagement`);
          
          await sendEmail(
            memberData.email,
            subject,
            body,
            'whatsapp',
            currentAdminUid || user.uid,
            `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
            config.smtp
          );
        }
      };

      if (editingItem) {
        const wasKitReceived = !!editingItem.receivedKit;
        const wasWhatsAppJoined = !!editingItem.joinedWhatsApp;
        
        await updateDoc(doc(db, 'members', editingItem.id), data);
        
        const kitNewlyChecked = receivedKit && !wasKitReceived;
        const whatsappNewlyChecked = joinedWhatsApp && !wasWhatsAppJoined;
        
        if (kitNewlyChecked || whatsappNewlyChecked) {
          await sendOnboardingEmail(data, kitNewlyChecked, whatsappNewlyChecked);
        }
      } else {
        await addDoc(collection(db, 'members'), data);
        
        if (receivedKit || joinedWhatsApp) {
          await sendOnboardingEmail(data, receivedKit, joinedWhatsApp);
        }
        
        // Send confirmation email if enabled
        if (config?.emailNotifications?.registration) {
          const template = config.templates?.registration || {
            subject: "Registration Confirmation",
            body: `Hello ${data.name},\n\nWelcome to our club! Your registration has been confirmed.\n\nBest regards,\nManagement`
          };
          const subject = template.subject;
          const body = template.body.replace('{name}', data.name);
          
          await sendEmail(
            data.email,
            subject,
            body,
            'registration',
            currentAdminUid || user.uid,
            `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
            config.smtp
          );
        }
      }
      
      setIsModalOpen(false);
      setEditingItem(null);
      setScannedData({});
    } catch (err: any) {
      alert(err.message || "An error occurred while saving the member.");
      handleFirestoreError(err, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'members');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddPayment = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || isSubmitting) return;
    setIsSubmitting(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      const memberId = (formData.get('memberId') as string) || '';
      const member = members.find(m => m.id === memberId);
      
      const data = {
        memberId,
        memberEmail: member?.email || '',
        amount: Number(formData.get('amount')) || 0,
        date: (formData.get('date') as string) || format(new Date(), 'yyyy-MM-dd'),
        type: (formData.get('type') as any) || (localLists.paymentTypes?.[0] || 'monthly'),
        feesDescription: (formData.get('feesDescription') as string) || (localLists.feesDescriptions?.[0] || ''),
        period: (formData.get('period') as string) || (localLists.periods?.[0] || ''),
        paymentOption: (formData.get('paymentOption') as string) || (localLists.paymentOptions?.[0] || ''),
        status: (formData.get('status') as any) || (localLists.paymentStatuses?.[1] || 'pending'),
        startDate: (formData.get('startDate') as string) || '',
        endDate: (formData.get('endDate') as string) || '',
        uid: currentAdminUid || user.uid
      };

      const sendPaymentEmail = async (paymentData: any) => {
        const member = members.find(m => m.id === paymentData.memberId);
        if (member && member.email) {
          if (paymentData.status === 'paid' && config?.emailNotifications?.payment) {
            const template = config.templates?.payment || {
              subject: "Payment Confirmation",
              body: `Hello ${member.name},\n\nWe have received your payment of ${paymentData.amount} for ${paymentData.type} subscription.\n\nThank you!\nManagement`
            };
            const subject = template.subject;
            const body = template.body
              .replace('{name}', member.name)
              .replace('{amount}', String(paymentData.amount))
              .replace('{type}', paymentData.type);

            await sendEmail(
              member.email,
              subject,
              body,
              'payment',
              currentAdminUid || user.uid,
              `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
              config.smtp
            );
          } else if (paymentData.status !== 'paid' && config?.emailNotifications?.reminder) {
            const template = config.templates?.reminder || {
              subject: "Payment Reminder",
              body: `Hello ${member.name},\n\nThis is a friendly reminder that your payment of ${paymentData.amount} for ${paymentData.type} subscription is pending.\n\nPlease renew your subscription at your earliest convenience.\n\nBest regards,\nManagement`
            };
            const subject = template.subject;
            const body = template.body
              .replace('{name}', member.name)
              .replace('{amount}', String(paymentData.amount))
              .replace('{type}', paymentData.type);

            await sendEmail(
              member.email,
              subject,
              body,
              'reminder',
              currentAdminUid || user.uid,
              `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
              config.smtp
            );
          }
        }
      };

      if (editingItem) {
        const statusChanged = editingItem.status !== data.status;
        await updateDoc(doc(db, 'payments', editingItem.id), data);
        if (statusChanged) {
          await sendPaymentEmail(data);
        }
      } else {
        await addDoc(collection(db, 'payments'), data);
        await sendPaymentEmail(data);
      }
      setIsModalOpen(false);
      setEditingItem(null);
    } catch (err: any) {
      alert(err.message || "An error occurred while saving the payment.");
      handleFirestoreError(err, editingItem ? OperationType.UPDATE : OperationType.CREATE, 'payments');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleScanID = async (file: File) => {
    if (!file) return;
    setIsScanning(true);
    try {
      const base64 = await fileToBase64(file);
      const base64Data = base64.split(',')[1];

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: "Extract information from this ID card. Return a JSON object with the following fields: name (full name in English), nameArabic (full name in Arabic), nationality, birthday (YYYY-MM-DD), emiratesId (format 784-XXXX-XXXXXXX-X). If a field is not found, leave it empty. Only return the JSON." },
              { inlineData: { mimeType: file.type, data: base64Data } }
            ]
          }
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              nameArabic: { type: Type.STRING },
              nationality: { type: Type.STRING },
              birthday: { type: Type.STRING },
              emiratesId: { type: Type.STRING },
            }
          }
        }
      });

      const text = response.text;
      if (text) {
        const data = JSON.parse(text);
        // Ensure all fields are strings to avoid issues with defaultValue
        const sanitizedData = {
          name: String(data.name || ''),
          nameArabic: String(data.nameArabic || ''),
          nationality: String(data.nationality || ''),
          birthday: String(data.birthday || ''),
          emiratesId: String(data.emiratesId || ''),
        };
        setScannedData(sanitizedData);
      }
    } catch (err) {
      console.error("Error scanning ID:", err);
      alert("Failed to scan ID. Please enter details manually.");
    } finally {
      setIsScanning(false);
    }
  };

  const handleRecordAttendance = async (memberId: string, status: 'present' | 'absent') => {
    if (!user) return;
    const date = selectedAttendanceDate;
    const existing = attendance.find(a => a.memberId === memberId && a.date === date);

    try {
      if (existing) {
        if (existing.status === status) {
          await deleteDoc(doc(db, 'attendance', existing.id));
          return;
        }
        await updateDoc(doc(db, 'attendance', existing.id), { status });
      } else {
        const member = members.find(m => m.id === memberId);
        await addDoc(collection(db, 'attendance'), {
          memberId,
          memberEmail: member?.email || '',
          date,
          status,
          uid: currentAdminUid || user.uid,
          notified: false
        });
      }
    } catch (err: any) {
      alert(err.message || "An error occurred while updating attendance.");
      handleFirestoreError(err, OperationType.WRITE, 'attendance');
    }
  };

  const handleSaveAttendance = async () => {
    if (!user || isAttendanceSaving) return;
    setIsAttendanceSaving(true);
    
    try {
      const date = selectedAttendanceDate;
      const recordsToNotify = attendance.filter(a => a.date === date && !a.notified);
      
      if (config?.emailNotifications?.attendance) {
        for (const record of recordsToNotify) {
          const shouldSend = (record.status === 'present' && config.emailNotifications.attendancePresent) ||
                           (record.status === 'absent' && config.emailNotifications.attendanceAbsent);
          
          if (!shouldSend) continue;

          const member = members.find(m => m.id === record.memberId);
          if (member && member.email) {
            const template = config.templates?.attendance || {
              subject: "Attendance Notification",
              body: `Hello {name},\n\nYour attendance for {date} has been recorded as: {status}.\n\nBest regards,\nManagement`
            };
            const subject = template.subject;
            const body = template.body
              .replace('{name}', member.name)
              .replace('{date}', date)
              .replace('{status}', record.status);

            await sendEmail(
              member.email,
              subject,
              body,
              'attendance',
              currentAdminUid || user.uid,
              `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
              config.smtp
            );
            
            // Mark as notified
            await updateDoc(doc(db, 'attendance', record.id), { notified: true });
          }
        }
      }
      
      alert("Attendance saved successfully!");
    } catch (err: any) {
      alert("Error saving attendance: " + err.message);
      handleFirestoreError(err, OperationType.WRITE, 'attendance');
    } finally {
      setIsAttendanceSaving(false);
    }
  };

  const handleDelete = async (type: 'members' | 'payments' | 'attendance' | 'sent_emails' | 'expenses' | 'users' | 'registration_requests' | 'trial_requests' | 'evaluations', id: string) => {
    try {
      await deleteDoc(doc(db, type, id));
      setDeleteConfirm(null);
    } catch (err: any) {
      alert(err.message || "An error occurred while deleting the item.");
      handleFirestoreError(err, OperationType.DELETE, type);
    }
  };

  const handleResetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      alert(`Password reset email sent to ${email}`);
    } catch (err: any) {
      alert(err.message || "Failed to send password reset email.");
    }
  };

  const handleAddUser = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !isAdmin) return;
    setIsSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const userData: Partial<UserAccount> = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      role: formData.get('role') as UserRole,
      status: formData.get('status') as 'active' | 'disabled' || 'active',
      phone: formData.get('phone') as string || '',
      notes: formData.get('notes') as string || '',
      permissions: formData.getAll('permissions') as string[],
      adminUid: currentAdminUid || user.uid,
      createdAt: editingItem ? editingItem.createdAt : new Date().toISOString(),
    };

    try {
      if (editingItem) {
        await updateDoc(doc(db, 'users', editingItem.id), userData);
      } else {
        await addDoc(collection(db, 'users'), userData);
      }
      setIsModalOpen(false);
      setEditingItem(null);
    } catch (err: any) {
      alert(err.message || "An error occurred while saving the user.");
      handleFirestoreError(err, OperationType.WRITE, 'users');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClearAttendance = async () => {
    if (!user || attendance.length === 0) {
      setDeleteConfirm(null);
      return;
    }
    setIsSaving('clear_attendance');
    try {
      // Firestore batches are limited to 500 operations
      const batchSize = 500;
      for (let i = 0; i < attendance.length; i += batchSize) {
        const batch = writeBatch(db);
        const chunk = attendance.slice(i, i + batchSize);
        chunk.forEach((record) => {
          batch.delete(doc(db, 'attendance', record.id));
        });
        await batch.commit();
      }
      setDeleteConfirm(null);
      alert("Attendance records cleared successfully.");
    } catch (err: any) {
      alert("Error clearing attendance: " + err.message);
      handleFirestoreError(err, OperationType.DELETE, 'attendance');
    } finally {
      setIsSaving(null);
    }
  };

  const handleExportExcel = () => {
    let data: any[] = [];
    let filename = `report-${reportType}-${format(new Date(), 'yyyy-MM-dd')}.xlsx`;

    if (reportType === 'members') {
      data = members
        .filter(member => {
          const matchesSearch = !globalFilters.search || 
                               member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                               member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
          if (!matchesSearch) return false;
          if (reportMemberStatus && member.status !== reportMemberStatus) return false;
          if (reportAgeGroup && member.ageGroup !== reportAgeGroup) return false;
          if (reportLocation && member.location !== reportLocation) return false;
          if (reportLevel && member.level !== reportLevel) return false;
          if (reportCoach && member.coach !== reportCoach) return false;
          if (reportMemberCategory && member.category !== reportMemberCategory) return false;
          if (reportBirthday && member.birthday !== reportBirthday) return false;
          if (reportBirthdayYear && member.birthday && !member.birthday.startsWith(reportBirthdayYear)) return false;
          if (reportNationality && member.nationality && !member.nationality.toLowerCase().includes(reportNationality.toLowerCase())) return false;
          return true;
        })
        .map(m => ({
          Name: m.name,
          'Name (Arabic)': m.nameArabic || '',
          Nationality: m.nationality || '',
          Email: m.email,
          Phone: m.phone || '',
          WhatsApp: m.whatsapp || '',
          Birthday: m.birthday || '',
          Category: m.category,
          'Emirates ID': m.emiratesId || '',
          Status: m.status,
          'Joined At': format(new Date(m.joinedAt), 'PP'),
          Location: m.location || '',
          'Age Group': m.ageGroup || '',
          Level: m.level || '',
          Coach: m.coach || '',
          Activity: m.activity || ''
        }));
    } else if (reportType === 'attendance') {
      data = members
        .filter(member => {
          const matchesSearch = !globalFilters.search || 
                               member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                               member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
          if (!matchesSearch) return false;
          const record = attendance.find(a => a.memberId === member.id && a.date === reportDate);
          if (reportAttendanceStatus) {
            if (reportAttendanceStatus === 'present') return record?.status === 'present';
            if (reportAttendanceStatus === 'absent') return record?.status === 'absent';
          }
          return true;
        })
        .map(member => {
          const record = attendance.find(a => a.memberId === member.id && a.date === reportDate);
          return {
            Member: member.name,
            Date: reportDate,
            Status: record ? record.status : 'Not Recorded',
            'Time Recorded': record ? 'Yes' : 'No'
          };
        });
    } else if (reportType === 'payments') {
      data = payments
        .filter(p => {
          const member = members.find(m => m.id === p.memberId);
          const matchesSearch = !globalFilters.search || 
                               (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                               (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
          return matchesSearch && (!reportMemberId || p.memberId === reportMemberId) && (!reportPaymentStatus || p.status === reportPaymentStatus);
        })
        .map(payment => {
          const member = members.find(m => m.id === payment.memberId);
          return {
            Member: member?.name || 'Unknown',
            Amount: payment.amount,
            Date: payment.date,
            'Start Date': payment.startDate || '',
            'End Date': payment.endDate || '',
            Type: payment.type,
            Status: payment.status
          };
        });
    } else if (reportType === 'expenses') {
      data = expenses
        .filter(e => {
          const date = e.date;
          const inRange = date >= reportDateRange.start && date <= reportDateRange.end;
          const matchesSearch = !globalFilters.search || 
                               e.title.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                               (e.description?.toLowerCase() || '').includes(globalFilters.search.toLowerCase());
          const categoryMatch = reportCategory === 'all' || e.category === reportCategory;
          return inRange && categoryMatch && matchesSearch;
        })
        .sort((a, b) => b.date.localeCompare(a.date))
        .map(expense => ({
          Date: expense.date,
          Title: expense.title,
          Category: expense.category,
          Amount: expense.amount,
          Description: expense.description || ''
        }));
    } else if (reportType === 'evaluations') {
      data = evaluations
        .filter(e => {
          const member = members.find(m => m.id === e.memberId);
          const matchesSearch = !globalFilters.search || 
                               (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                               (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
          const inRange = e.date >= reportDateRange.start && e.date <= reportDateRange.end;
          const statusMatch = !reportEvaluationStatus || e.status === reportEvaluationStatus;
          const memberMatch = !reportMemberId || e.memberId === reportMemberId;
          return matchesSearch && inRange && statusMatch && memberMatch;
        })
        .map(e => {
          const member = members.find(m => m.id === e.memberId);
          const coach = users.find(u => u.id === e.coachId);
          const row: any = {
            Date: format(parseISO(e.date), 'PP'),
            Member: member?.name || 'Unknown',
            Coach: coach?.name || 'Unknown',
            Status: e.status,
            Notes: e.notes || ''
          };
          
          // Add scores
          config?.evaluationSettings?.categories.forEach(cat => {
            cat.skills.forEach(skill => {
              row[`${cat.name} - ${skill.name}`] = e.scores[skill.id] || 0;
            });
          });
          
          return row;
        });
    }

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Report");
    XLSX.writeFile(wb, filename);
  };

  const handleUpdateConfig = async (updates: Partial<AppConfig>, partName?: string) => {
    if (!user || !config) return;
    if (partName) setIsSaving(partName);
    try {
      const newConfig = {
        ...config,
        ...updates
      };

      // Ensure lists has all required properties
      if (newConfig.lists) {
        newConfig.lists = {
          ...DEFAULT_LISTS,
          ...newConfig.lists
        };
      }

      const { id, ...data } = newConfig;
      
      // Split publicInfo from the rest of the config to avoid 1MB limit
      const { publicInfo, ...mainData } = data;
      
      const batch = writeBatch(db);
      batch.update(doc(db, 'configs', id), mainData);
      
      if (publicInfo) {
        batch.set(doc(db, 'public_configs', id), { publicInfo, uid: data.uid }, { merge: true });
      }
      
      await batch.commit();
      
      if (partName) {
        // Keep the "Saved" state a bit longer for visual feedback
        setIsSaving(null);
        setJustSaved(partName);
        setTimeout(() => setJustSaved(null), 3000);
      }
    } catch (err: any) {
      console.error("Error updating config:", err);
      alert(err.message || "An error occurred while saving configuration.");
      handleFirestoreError(err, OperationType.UPDATE, 'configs');
      setIsSaving(null);
    }
  };

  const handleExportData = async () => {
    if (!user || !currentAdminUid) return;
    setIsBackingUp('data');
    try {
      const collections = [
        'members', 'attendance', 'payments', 'evaluations', 
        'expenses', 'sent_emails', 'registration_requests', 
        'trial_requests', 'gallery_images'
      ];
      
      const backupData: any = {};
      
      for (const colName of collections) {
        // Some collections use 'uid', some use 'adminUid'
        const q = query(collection(db, colName), where('uid', '==', currentAdminUid));
        const q2 = query(collection(db, colName), where('adminUid', '==', currentAdminUid));
        
        const [snapshot, snapshot2] = await Promise.all([
          getDocs(q).catch(() => null),
          getDocs(q2).catch(() => null)
        ]);
        
        const docs: any[] = [];
        if (snapshot) snapshot.docs.forEach(d => docs.push({ id: d.id, ...d.data() }));
        if (snapshot2) snapshot2.docs.forEach(d => {
          if (!docs.find(existing => existing.id === d.id)) {
            docs.push({ id: d.id, ...d.data() });
          }
        });
        
        backupData[colName] = docs;
      }
      
      const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_data_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting data:', error);
      alert('Failed to export data. Please check console for details.');
    } finally {
      setIsBackingUp(null);
    }
  };

  const handleExportSystem = async () => {
    if (!user || !config) return;
    setIsBackingUp('system');
    try {
      const backupSystem = {
        config,
        metadata: {
          exportedAt: new Date().toISOString(),
          version: '1.0.0',
          app: 'Club Management System'
        }
      };
      
      const blob = new Blob([JSON.stringify(backupSystem, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_system_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting system config:', error);
      alert('Failed to export system config.');
    } finally {
      setIsBackingUp(null);
    }
  };

  const handleExportAttachments = async () => {
    if (!user || !currentAdminUid) return;
    setIsBackingUp('attachments');
    try {
      const zip = new JSZip();
      const attachmentsFolder = zip.folder("attachments");
      
      const imageUrls: { url: string; name: string }[] = [];

      // 1. Members
      members.forEach(m => {
        if (m.profileImage) imageUrls.push({ url: m.profileImage, name: `members/${m.id}_profile` });
        if (m.idImage) imageUrls.push({ url: m.idImage, name: `members/${m.id}_id` });
      });

      // 2. Registration Requests
      registrationRequests.forEach(r => {
        if (r.profileImage) imageUrls.push({ url: r.profileImage, name: `registration_requests/${r.id}_profile` });
        if (r.idImage) imageUrls.push({ url: r.idImage, name: `registration_requests/${r.id}_id` });
      });

      // 3. Trial Requests
      trialRequests.forEach(t => {
        if (t.profileImage) imageUrls.push({ url: t.profileImage, name: `trial_requests/${t.id}_profile` });
        if (t.idImage) imageUrls.push({ url: t.idImage, name: `trial_requests/${t.id}_id` });
      });

      // 4. Gallery
      galleryImages.forEach((g, i) => {
        if (g.url && g.type === 'image') imageUrls.push({ url: g.url, name: `gallery/${g.id || i}` });
      });

      // 5. Config
      if (config) {
        if (config.logoUrl) imageUrls.push({ url: config.logoUrl, name: `config/logo` });
        if (config.publicInfo?.heroImageUrl) imageUrls.push({ url: config.publicInfo.heroImageUrl, name: `config/hero` });
        if (config.publicInfo?.activitiesImageUrl) imageUrls.push({ url: config.publicInfo.activitiesImageUrl, name: `config/activities` });
        if (config.publicInfo?.programsImageUrl) imageUrls.push({ url: config.publicInfo.programsImageUrl, name: `config/programs` });
        if (config.publicInfo?.locationsImageUrl) imageUrls.push({ url: config.publicInfo.locationsImageUrl, name: `config/locations` });
        if (config.publicInfo?.aboutImageUrl) imageUrls.push({ url: config.publicInfo.aboutImageUrl, name: `config/about` });
      }

      // Fetch and add to zip
      const fetchPromises = imageUrls.map(async (item) => {
        try {
          // Use no-referrer logic if possible, but fetch needs to work
          const response = await fetch(item.url, {
            referrerPolicy: 'no-referrer'
          });
          if (!response.ok) throw new Error(`Failed to fetch ${item.url}`);
          const blob = await response.blob();
          const extension = blob.type.split('/')[1] || 'jpg';
          attachmentsFolder?.file(`${item.name}.${extension}`, blob);
        } catch (err) {
          console.warn(`Could not download attachment: ${item.name}`, err);
        }
      });

      await Promise.all(fetchPromises);

      const content = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `attachments_backup_${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting attachments:', error);
      alert('Failed to export attachments. Check console for details.');
    } finally {
      setIsBackingUp(null);
    }
  };

  const handleAddGalleryImage = async (url: string, type: 'image' | 'video' = 'image') => {
    if (!user) return;
    setIsUploadingGallery(true);
    try {
      await addDoc(collection(db, 'gallery_images'), {
        url,
        type,
        order: galleryImages.length,
        uid: currentAdminUid,
        createdAt: new Date().toISOString()
      });
    } catch (err) {
      console.error("Error adding gallery item:", err);
      handleFirestoreError(err, OperationType.CREATE, 'gallery_images');
    } finally {
      setIsUploadingGallery(false);
    }
  };

  const handleRemoveGalleryImage = async (imageId: string) => {
    try {
      await deleteDoc(doc(db, 'gallery_images', imageId));
    } catch (err) {
      console.error("Error removing gallery image:", err);
      handleFirestoreError(err, OperationType.DELETE, 'gallery_images');
    }
  };

  const handleUpdateGalleryImage = async (imageId: string, updates: Partial<GalleryImage>) => {
    try {
      await updateDoc(doc(db, 'gallery_images', imageId), updates);
    } catch (err) {
      console.error("Error updating gallery image:", err);
      handleFirestoreError(err, OperationType.UPDATE, 'gallery_images');
    }
  };

  // --- Derived Stats ---

  const stats = useMemo(() => {
    const filteredMembers = members.filter(m => {
      const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                           m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
      const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
      const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
      const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
      const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
      return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
    });

    const filteredPayments = payments.filter(p => {
      const member = members.find(m => m.id === p.memberId);
      if (!member) return false;
      const matchesSearch = member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                           member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
      const matchesCoach = !globalFilters.coach || member.coach === globalFilters.coach;
      const matchesLocation = !globalFilters.location || member.location === globalFilters.location;
      const matchesAgeGroup = !globalFilters.ageGroup || member.ageGroup === globalFilters.ageGroup;
      const matchesStatus = !globalFilters.status || p.status === globalFilters.status;
      return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
    });

    const activeMembers = filteredMembers.filter(m => m.status === (localLists.memberStatuses?.[0] || 'active')).length;
    const totalRevenue = filteredPayments
      .filter(p => p.status === (localLists.paymentStatuses?.[0] || 'paid'))
      .reduce((sum, p) => sum + p.amount, 0);
    
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = totalRevenue - totalExpenses;
    const initialBankBalance = config?.bankBalance || 0;
    const initialCashBalance = config?.cashBalance || 0;
    const totalInitialBalance = initialBankBalance + initialCashBalance;
    const currentTotalBalance = totalInitialBalance + totalRevenue - totalExpenses;
    
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayAttendance = attendance.filter(a => {
      const member = members.find(m => m.id === a.memberId);
      if (!member) return false;
      const matchesSearch = member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                           member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
      const matchesCoach = !globalFilters.coach || member.coach === globalFilters.coach;
      const matchesLocation = !globalFilters.location || member.location === globalFilters.location;
      const matchesAgeGroup = !globalFilters.ageGroup || member.ageGroup === globalFilters.ageGroup;
      const matchesStatus = !globalFilters.status || member.status === globalFilters.status;
      return a.date === today && a.status === 'present' && matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
    }).length;
    
    const pendingPayments = filteredPayments.filter(p => p.status === 'pending').length;
    const pendingEvaluations = evaluations.filter(e => e.status === 'pending').length;

    return { 
      activeMembers, 
      totalRevenue, 
      totalExpenses, 
      netProfit, 
      totalInitialBalance,
      currentTotalBalance,
      todayAttendance, 
      pendingPayments,
      pendingEvaluations
    };
  }, [members, payments, attendance, expenses, globalFilters, localLists, config]);

  // --- Render Helpers ---

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-zinc-200 border-t-zinc-900 rounded-full"
        />
      </div>
    );
  }

  if (isPublicInfo) {
    const info = config?.publicInfo;

    if (isFullGallery) {
      const images = galleryImages.filter(img => img.type !== 'video');
      return (
        <div className={`min-h-screen bg-white py-24 px-6 selection:bg-zinc-900 selection:text-white ${publicLang === 'ar' ? 'font-arabic' : ''}`} dir={publicLang === 'ar' ? 'rtl' : 'ltr'}>
          <div className="max-w-7xl mx-auto space-y-24">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
              <div className="space-y-8">
                <button 
                  onClick={() => {
                    setIsFullGallery(false);
                    if (!publicAdminUid) setIsPublicInfo(false);
                  }}
                  className="group flex items-center gap-3 text-sm font-bold text-zinc-400 hover:text-zinc-900 transition-all"
                >
                  <div className="p-2 rounded-full bg-zinc-50 group-hover:bg-zinc-100 transition-colors">
                    <ArrowLeft size={16} className={publicLang === 'ar' ? 'rotate-180' : ''} />
                  </div>
                  {publicLang === 'ar' ? 'العودة لصفحة النادي' : 'Back to Club Page'}
                </button>
                <div className="space-y-2">
                  <h1 className="text-8xl font-light tracking-tighter text-zinc-900 serif italic leading-none">
                    {publicLang === 'ar' ? (config?.publicInfo?.galleryTitleArabic || 'رحلة بصرية') : (config?.publicInfo?.galleryTitle || 'Visual Journey')}
                  </h1>
                  <p className="text-zinc-500 serif text-2xl max-w-2xl">
                    {publicLang === 'ar' ? (config?.publicInfo?.gallerySubtitleArabic || 'مجموعة منسقة من اللحظات الملتقطة والإرث.') : (config?.publicInfo?.gallerySubtitle || 'A curated collection of captured moments and legacy.')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-zinc-300 text-sm font-bold uppercase tracking-widest">
                <span className="w-12 h-px bg-zinc-100" />
                {images.length} {publicLang === 'ar' ? 'لحظة ملتقطة' : 'Captured Moments'}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12">
              {images.map((img, i) => (
                <motion.div 
                  key={img.id}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05, duration: 1, ease: [0.21, 0.45, 0.32, 0.9] }}
                  onClick={() => setZoomedImage(img.url)}
                  className="group relative aspect-[3/4] rounded-[3rem] overflow-hidden shadow-2xl cursor-zoom-in bg-zinc-50"
                >
                  <img 
                    src={img.url} 
                    alt={img.caption || `Gallery ${i}`} 
                    className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-110" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute inset-0 bg-zinc-900/0 group-hover:bg-zinc-900/20 transition-colors duration-700" />
                  {img.caption && (
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-10 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-700 ease-out">
                      <p className="text-white text-xl font-light serif italic leading-relaxed">{img.caption}</p>
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
          <AnimatePresence>
            {zoomedImage && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setZoomedImage(null)}
                className="fixed inset-0 z-[200] bg-zinc-950/98 flex items-center justify-center p-8 cursor-zoom-out backdrop-blur-xl"
              >
                <motion.img
                  initial={{ scale: 0.9, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.9, opacity: 0, y: 20 }}
                  transition={{ type: "spring", damping: 25, stiffness: 200 }}
                  src={zoomedImage}
                  className="max-w-full max-h-full rounded-3xl shadow-[0_0_100px_rgba(0,0,0,0.5)]"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setZoomedImage(null)}
                  className="absolute top-12 right-12 p-4 bg-white/5 hover:bg-white/10 text-white rounded-full transition-all hover:rotate-90 duration-300"
                >
                  <X size={32} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      );
    }

    if (isFullVideos) {
      const videos = galleryImages.filter(img => img.type === 'video');
      return (
        <div className={`min-h-screen bg-zinc-950 py-24 px-6 text-white selection:bg-white selection:text-black ${publicLang === 'ar' ? 'font-arabic' : ''}`} dir={publicLang === 'ar' ? 'rtl' : 'ltr'}>
          <div className="max-w-7xl mx-auto space-y-16">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
              <div className="space-y-6">
                <button 
                  onClick={() => {
                    setIsFullVideos(false);
                    if (!publicAdminUid) setIsPublicInfo(false);
                  }}
                  className="group flex items-center gap-3 text-sm font-bold text-zinc-500 hover:text-white transition-all"
                >
                  <div className="p-2 rounded-full bg-white/5 group-hover:bg-white/10 transition-colors">
                    <ArrowLeft size={16} className={publicLang === 'ar' ? 'rotate-180' : ''} />
                  </div>
                  {publicLang === 'ar' ? 'العودة لصفحة النادي' : 'Back to Club Page'}
                </button>
                <div className="space-y-2">
                  <h1 className="text-7xl font-light tracking-tighter serif italic leading-none">
                    {publicLang === 'ar' ? (config?.publicInfo?.videosTitleArabic || 'قصص متحركة') : (config?.publicInfo?.videosTitle || 'Motion Stories')}
                  </h1>
                  <p className="text-zinc-400 serif text-xl max-w-2xl">
                    {publicLang === 'ar' ? (config?.publicInfo?.videosSubtitleArabic || 'مجموعة منسقة من أكثر لحظاتنا التي لا تنسى في الحركة.') : (config?.publicInfo?.videosSubtitle || 'A curated collection of our most memorable moments in motion.')}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-zinc-500 text-sm font-bold uppercase tracking-widest">
                <span className="w-12 h-px bg-zinc-800" />
                {videos.length} {publicLang === 'ar' ? 'فيديو' : 'Videos'}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {videos.map((vid, i) => (
                <motion.div 
                  key={vid.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1, duration: 0.8, ease: [0.21, 0.45, 0.32, 0.9] }}
                  className="space-y-6 group"
                >
                  <div className="relative aspect-video rounded-[3rem] overflow-hidden shadow-2xl bg-zinc-900 border border-white/5 group-hover:border-white/10 transition-colors duration-500">
                    {getEmbedUrl(vid.url) ? (
                      <iframe 
                        src={getEmbedUrl(vid.url)} 
                        className="w-full h-full" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen 
                      />
                    ) : (
                      <video 
                        src={vid.url} 
                        controls 
                        className="w-full h-full object-cover"
                        poster={getYoutubeThumbnail(vid.url) || undefined}
                      />
                    )}
                  </div>
                  {vid.caption && (
                    <div className="px-4">
                      <h3 className="text-2xl font-light serif italic text-zinc-200 group-hover:text-white transition-colors">{vid.caption}</h3>
                      <div className="w-12 h-px bg-zinc-800 mt-4 group-hover:w-24 transition-all duration-500" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      );
    }

    const renderPublicSection = (section: string) => {
      switch (section) {
        case 'images':
          const images = galleryImages.filter(img => img.type !== 'video');
          if (images.length === 0) return null;
          return (
            <section key="images" id="gallery" className="py-24 space-y-12">
              <div className="max-w-6xl mx-auto px-4">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
                  <div className="space-y-4">
                    <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                      {publicLang === 'ar' ? (info?.gallerySubtitleArabic || 'رحلة بصرية') : (info?.gallerySubtitle || 'Visual Journey')}
                    </span>
                    <h2 className="text-5xl font-light tracking-tight text-zinc-900 serif italic">
                      {publicLang === 'ar' ? (info?.galleryTitleArabic || 'معرضنا') : (info?.galleryTitle || 'Our Gallery')}
                    </h2>
                  </div>
                  {images.length > 3 && (
                    <button
                      onClick={() => setIsFullGallery(true)}
                      className="group flex items-center gap-2 text-sm font-bold text-zinc-500 hover:text-zinc-900 transition-colors"
                    >
                      {publicLang === 'ar' ? 'عرض جميع الصور' : 'View All Images'}
                      <ChevronRight size={16} className={`group-hover:translate-x-1 transition-transform ${publicLang === 'ar' ? 'rotate-180' : ''}`} />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {images
                    .slice(0, showAllImages ? undefined : 3)
                    .map((img, i) => (
                      <motion.div 
                        key={img.id}
                        layoutId={img.id}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.1 }}
                        onClick={() => setZoomedImage(img.url)}
                        className="group relative aspect-[4/5] rounded-[2rem] overflow-hidden shadow-2xl cursor-zoom-in bg-zinc-100"
                      >
                        <img src={img.url} alt={publicLang === 'ar' ? (img.captionArabic || img.caption || `Gallery ${i}`) : (img.caption || `Gallery ${i}`)} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" referrerPolicy="no-referrer" />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-500" />
                        {(img.caption || img.captionArabic) && (
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent p-8 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                            <p className="text-white text-lg font-medium serif italic">{publicLang === 'ar' ? (img.captionArabic || img.caption) : (img.caption)}</p>
                          </div>
                        )}
                      </motion.div>
                    ))}
                </div>
              </div>
            </section>
          );
        case 'videos':
          const videos = galleryImages.filter(img => img.type === 'video');
          if (videos.length === 0) return null;
          return (
            <section key="videos" id="videos" className="py-24 bg-zinc-900 text-white">
              <div className="max-w-6xl mx-auto px-4">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
                  <div className="space-y-4">
                    <span className="text-xs font-bold tracking-[0.2em] text-zinc-500 uppercase">
                      {publicLang === 'ar' ? (info?.videosSubtitleArabic || 'قصص متحركة') : (info?.videosSubtitle || 'Motion Stories')}
                    </span>
                    <h2 className="text-5xl font-light tracking-tight serif italic">
                      {publicLang === 'ar' ? (info?.videosTitleArabic || 'فيديوهات مميزة') : (info?.videosTitle || 'Featured Videos')}
                    </h2>
                  </div>
                  {videos.length > 2 && (
                    <button
                      onClick={() => setIsFullVideos(true)}
                      className="group flex items-center gap-2 text-sm font-bold text-zinc-400 hover:text-white transition-colors"
                    >
                      {publicLang === 'ar' ? 'عرض جميع الفيديوهات' : 'View All Videos'}
                      <ChevronRight size={16} className={`group-hover:translate-x-1 transition-transform ${publicLang === 'ar' ? 'rotate-180' : ''}`} />
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {videos
                    .slice(0, showAllVideos ? undefined : 2)
                    .map((vid, i) => (
                      <motion.div 
                        key={vid.id}
                        initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        className="group relative aspect-video rounded-[2.5rem] overflow-hidden shadow-2xl bg-zinc-800 border border-white/5"
                      >
                        <div className="absolute inset-0 flex items-center justify-center z-10">
                          <div className="w-20 h-20 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center group-hover:scale-110 group-hover:bg-white/20 transition-all duration-500">
                            <Play size={32} className="text-white fill-white ml-1" />
                          </div>
                        </div>
                        {(vid.caption || vid.captionArabic) && (
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-8 z-10">
                            <p className="text-white text-xl font-medium serif italic">{publicLang === 'ar' ? (vid.captionArabic || vid.caption) : (vid.caption)}</p>
                          </div>
                        )}
                        <a href={vid.url} target="_blank" rel="noopener noreferrer" className="absolute inset-0 z-20" />
                        <div className="absolute inset-0 bg-zinc-900/40 group-hover:bg-zinc-900/20 transition-colors duration-500" />
                      </motion.div>
                    ))}
                </div>
              </div>
            </section>
          );
        case 'about':
          return (info?.information || info?.informationArabic) && (
            <section key="about" id="about" className="py-24 bg-white">
              <div className="max-w-4xl mx-auto px-4 text-center space-y-12">
                <div className="space-y-4">
                  <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                    {publicLang === 'ar' ? (info?.aboutSubtitleArabic || 'الإرث والرؤية') : (info?.aboutSubtitle || 'Legacy & Vision')}
                  </span>
                  <h2 className="text-6xl font-light tracking-tight text-zinc-900 serif italic leading-tight">
                    {publicLang === 'ar' ? (info?.aboutTitleArabic || 'قصتنا') : (info?.aboutTitle || 'Our Story')}
                  </h2>
                </div>
                <div className="prose prose-zinc prose-lg max-w-none text-zinc-600 leading-relaxed serif">
                  <Markdown>{publicLang === 'ar' ? (info.informationArabic || info.information) : (info.information)}</Markdown>
                </div>
                <div className="pt-8">
                  <div className="w-24 h-px bg-zinc-200 mx-auto" />
                </div>
              </div>
            </section>
          );
        case 'activities':
          return (info?.activities || info?.activitiesArabic) && (
            <section key="activities" id="activities" className="py-24 bg-zinc-50">
              <div className="max-w-6xl mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                  <div className="space-y-8">
                    <div className="space-y-4">
                      <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                        {publicLang === 'ar' ? (info?.activitiesSubtitleArabic || 'ماذا نفعل') : (info?.activitiesSubtitle || 'What We Do')}
                      </span>
                      <h2 className="text-5xl font-light tracking-tight text-zinc-900 serif italic">
                        {publicLang === 'ar' ? (info?.activitiesTitleArabic || 'الأنشطة') : (info?.activitiesTitle || 'Activities')}
                      </h2>
                    </div>
                    <div className="prose prose-zinc max-w-none text-zinc-600 serif">
                      <Markdown>{publicLang === 'ar' ? (info.activitiesArabic || info.activities) : (info.activities)}</Markdown>
                    </div>
                  </div>
                  <div className="relative aspect-square rounded-[3rem] overflow-hidden shadow-2xl">
                    <img 
                      src={info?.activitiesImageUrl || "https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=1000"} 
                      alt="Activities" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-zinc-900/10" />
                  </div>
                </div>
              </div>
            </section>
          );
        case 'programs':
          return (info?.programs || info?.programsArabic) && (
            <section key="programs" id="programs" className="py-24 bg-white">
              <div className="max-w-6xl mx-auto px-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
                  <div className="order-2 md:order-1 relative aspect-square rounded-[3rem] overflow-hidden shadow-2xl">
                    <img 
                      src={info?.programsImageUrl || "https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&q=80&w=1000"} 
                      alt="Programs" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-zinc-900/10" />
                  </div>
                  <div className="order-1 md:order-2 space-y-8">
                    <div className="space-y-4">
                      <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                        {publicLang === 'ar' ? (info?.programsSubtitleArabic || 'مسار التعلم') : (info?.programsSubtitle || 'Learning Path')}
                      </span>
                      <h2 className="text-5xl font-light tracking-tight text-zinc-900 serif italic">
                        {publicLang === 'ar' ? (info?.programsTitleArabic || 'برامجنا') : (info?.programsTitle || 'Our Programs')}
                      </h2>
                    </div>
                    <div className="prose prose-zinc max-w-none text-zinc-600 serif">
                      <Markdown>{publicLang === 'ar' ? (info.programsArabic || info.programs) : (info.programs)}</Markdown>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          );
        case 'locations':
          return (info?.locations || info?.locationsArabic) && (
            <section key="locations" id="locations" className="py-24 bg-zinc-50">
              <div className="max-w-6xl mx-auto px-4">
                <div className="space-y-16">
                  <div className="text-center space-y-4">
                    <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                      {publicLang === 'ar' ? (info?.locationsSubtitleArabic || 'تجدنا هنا') : (info?.locationsSubtitle || 'Find Us')}
                    </span>
                    <h2 className="text-5xl font-light tracking-tight text-zinc-900 serif italic">
                      {publicLang === 'ar' ? (info?.locationsTitleArabic || 'مواقعنا') : (info?.locationsTitle || 'Our Locations')}
                    </h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                    <div className="bg-white p-12 rounded-[3.5rem] shadow-2xl border border-zinc-100 relative overflow-hidden group">
                      <div className={`absolute top-0 ${publicLang === 'ar' ? 'left-0 rounded-br-[4rem]' : 'right-0 rounded-bl-[4rem]'} w-32 h-32 bg-zinc-50 flex items-center justify-center group-hover:bg-zinc-100 transition-colors`}>
                        <MapPin size={32} className="text-zinc-400" />
                      </div>
                      <div className="prose prose-zinc max-w-none text-zinc-600 serif relative z-10">
                        <Markdown>{publicLang === 'ar' ? (info.locationsArabic || info.locations) : (info.locations)}</Markdown>
                      </div>
                    </div>
                    <div className="aspect-[4/3] rounded-[3.5rem] overflow-hidden shadow-2xl bg-zinc-200">
                      <img 
                        src={info?.locationsImageUrl || "https://images.unsplash.com/photo-1526232759583-d6f44a154bbf?auto=format&fit=crop&q=80&w=1000"} 
                        alt="Location" 
                        className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          );
        case 'calendar':
          return (info?.calendar || info?.calendarArabic) && (
            <section key="calendar" id="calendar" className="py-24 bg-white">
              <div className="max-w-6xl mx-auto px-4">
                <div className="space-y-16">
                  <div className="text-center space-y-4">
                    <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                      {publicLang === 'ar' ? (info?.calendarSubtitleArabic || 'ابق على اطلاع') : (info?.calendarSubtitle || 'Stay Updated')}
                    </span>
                    <h2 className="text-5xl font-light tracking-tight text-zinc-900 serif italic">
                      {publicLang === 'ar' ? (info?.calendarTitleArabic || 'تقويم النادي') : (info?.calendarTitle || 'Club Calendar')}
                    </h2>
                  </div>
                  <div className="relative">
                    <div className="absolute -inset-4 bg-zinc-50 rounded-[4rem] -z-10" />
                    <div className="bg-white p-12 rounded-[3.5rem] shadow-xl border border-zinc-100 relative overflow-hidden">
                      <div className={`absolute top-0 ${publicLang === 'ar' ? 'right-0' : 'left-0'} w-2 h-full bg-zinc-900`} />
                      <div className="prose prose-zinc max-w-none text-zinc-600 serif">
                        <Markdown>{publicLang === 'ar' ? (info.calendarArabic || info.calendar) : (info.calendar)}</Markdown>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          );
        case 'contact':
          return (info?.contact || info?.contactArabic) && (
            <>
              <section key="join" className="py-32 bg-zinc-50 relative overflow-hidden">
                <div className="absolute inset-0 z-0 opacity-10">
                  <div className={`absolute top-0 ${publicLang === 'ar' ? 'left-0' : 'right-0'} w-96 h-96 bg-zinc-900 blur-[100px] rounded-full`} />
                </div>
                <div className="max-w-4xl mx-auto px-4 text-center relative z-10 space-y-12">
                  <div className="space-y-4">
                    <span className="text-xs font-bold tracking-[0.2em] text-zinc-400 uppercase">
                      {publicLang === 'ar' ? (info?.joinSubtitleArabic || 'ابدأ رحلتك') : (info?.joinSubtitle || 'Start Your Journey')}
                    </span>
                    <h2 className="text-6xl md:text-7xl font-light tracking-tight text-zinc-900 serif italic">
                      {publicLang === 'ar' ? (info?.joinTitleArabic || 'هل أنت مستعد للانضمام؟') : (info?.joinTitle || 'Ready to Join?')}
                    </h2>
                    <p className="text-xl text-zinc-500 serif max-w-2xl mx-auto">
                      {publicLang === 'ar' ? (info?.joinDescriptionArabic || 'كن جزءاً من مجتمعنا المتنامي واختبر التميز في كل جانب من جوانب حياة النادي.') : (info?.joinDescription || 'Become part of our growing community and experience excellence in every aspect of club life.')}
                    </p>
                  </div>
                  <div className="flex flex-wrap justify-center gap-6">
                    <button 
                      onClick={() => setIsPublicTrial(true)}
                      className="px-12 py-6 bg-white text-zinc-900 border border-zinc-200 rounded-full font-bold hover:bg-zinc-50 transition-all flex items-center gap-3"
                    >
                      {publicLang === 'ar' ? 'حجز جلسة تجريبية' : 'Book Trial Session'}
                      <Calendar size={20} />
                    </button>
                    <button 
                      onClick={() => setIsPublicRegistration(true)}
                      className="px-12 py-6 bg-zinc-900 text-white rounded-full font-bold hover:scale-105 transition-all shadow-2xl flex items-center gap-3"
                    >
                      {publicLang === 'ar' ? 'سجل الآن' : 'Register Now'}
                      <UserPlus size={20} />
                    </button>
                    <button 
                      onClick={() => {
                        setIsPublicInfo(false);
                        setIsPublicRegistration(false);
                      }}
                      className="px-12 py-6 bg-white text-zinc-900 border border-zinc-200 rounded-full font-bold hover:bg-zinc-50 transition-all flex items-center gap-3"
                    >
                      {publicLang === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
                      <LogIn size={20} />
                    </button>
                  </div>
                </div>
              </section>

              <section key="contact" id="contact" className="py-24 bg-zinc-900 text-white">
              <div className="max-w-4xl mx-auto px-4 text-center space-y-12">
                <div className="space-y-4">
                  <span className="text-xs font-bold tracking-[0.2em] text-zinc-500 uppercase">
                    {publicLang === 'ar' ? (info?.contactSubtitleArabic || 'تواصل معنا') : (info?.contactSubtitle || 'Get In Touch')}
                  </span>
                  <h2 className="text-5xl font-light tracking-tight serif italic">
                    {publicLang === 'ar' ? (info?.contactTitleArabic || 'معلومات الاتصال') : (info?.contactTitle || 'Contact Information')}
                  </h2>
                </div>
                <div className="prose prose-invert prose-lg max-w-none text-zinc-400 serif">
                  <Markdown>{publicLang === 'ar' ? (info.contactArabic || info.contact) : (info.contact)}</Markdown>
                </div>
              </div>
            </section>
          </>
        );
        default:
          return null;
      }
    };

    return (
      <div className={`fixed inset-0 bg-white overflow-y-auto z-[100] selection:bg-zinc-900 selection:text-white ${publicLang === 'ar' ? 'font-arabic' : ''}`} dir={publicLang === 'ar' ? 'rtl' : 'ltr'}>
        {/* Modern Sticky Navbar */}
        <nav className="fixed top-0 inset-x-0 z-[110] bg-white/80 backdrop-blur-xl border-bottom border-zinc-100">
          <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
            <div className="flex items-center gap-4">
              {config?.logoUrl ? (
                <img src={config.logoUrl} alt="Logo" className="h-10 w-auto object-contain" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-10 h-10 bg-zinc-900 rounded-xl flex items-center justify-center">
                  <Users size={20} className="text-white" />
                </div>
              )}
              <span className="font-bold text-zinc-900 tracking-tight text-lg hidden sm:block">{config?.clubName}</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <a href="#about" className="text-sm font-medium text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'عن النادي' : 'About'}</a>
              <a href="#activities" className="text-sm font-medium text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'الأنشطة' : 'Activities'}</a>
              <a href="#gallery" className="text-sm font-medium text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'المعرض' : 'Gallery'}</a>
              <a href="#contact" className="text-sm font-medium text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'اتصل بنا' : 'Contact'}</a>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center bg-zinc-100 rounded-full p-1 mr-2">
                <button
                  onClick={() => setPublicLang('en')}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${publicLang === 'en' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
                >
                  EN
                </button>
                <button
                  onClick={() => setPublicLang('ar')}
                  className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${publicLang === 'ar' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
                >
                  AR
                </button>
              </div>
              <button 
                onClick={() => {
                  setIsPublicInfo(false);
                  setIsPublicRegistration(false);
                }}
                className="text-sm font-bold text-zinc-500 hover:text-zinc-900 transition-colors px-4 py-2"
              >
                {publicLang === 'ar' ? 'تسجيل الدخول' : 'Sign In'}
              </button>
              <button 
                onClick={() => setIsPublicRegistration(true)}
                className="px-6 py-2.5 bg-zinc-900 text-white rounded-full text-sm font-bold hover:scale-105 transition-all shadow-lg shadow-zinc-200"
              >
                {publicLang === 'ar' ? 'تسجيل' : 'Register'}
              </button>
            </div>
          </div>
        </nav>

        {/* Hero Section - Editorial Style */}
        <div className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-zinc-50">
          <div className="absolute inset-0 z-0 opacity-20">
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-zinc-400 blur-[120px] rounded-full" />
            <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-zinc-300 blur-[120px] rounded-full" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-10"
            >
              <div className="space-y-6">
                <motion.span 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="inline-block text-xs font-bold tracking-[0.3em] text-zinc-400 uppercase"
                >
                  {publicLang === 'ar' ? `مرحباً بك في ${config?.clubName || 'نادينا'}` : `Welcome to ${config?.clubName || 'Our Club'}`}
                </motion.span>
                <motion.h1 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="text-7xl md:text-9xl font-light tracking-tighter text-zinc-900 leading-[0.85] serif italic"
                >
                  {publicLang === 'ar' ? (config?.publicInfo?.heroTitleArabic || 'التميز') : (config?.publicInfo?.heroTitle || 'Excellence')} <br />
                  <span className="text-zinc-300 not-italic font-medium">{publicLang === 'ar' ? (config?.publicInfo?.heroSubtitleArabic || 'برؤية جديدة.') : (config?.publicInfo?.heroSubtitle || 'Redefined.')}</span>
                </motion.h1>
                <motion.p 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-xl text-zinc-500 max-w-lg leading-relaxed serif"
                >
                  {publicLang === 'ar' ? (config?.publicInfo?.heroDescriptionArabic || 'اكتشف مجتمعاً مخصصاً للنمو والشغف والإدارة الاحترافية. انضم إلينا اليوم وابدأ رحلتك.') : (config?.publicInfo?.heroDescription || 'Discover a community dedicated to growth, passion, and professional management. Join us today and start your journey.')}
                </motion.p>
              </div>

                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="flex flex-wrap gap-4"
                >
                  <button 
                    onClick={() => setIsPublicRegistration(true)}
                    className="group px-10 py-6 bg-zinc-900 text-white rounded-full font-bold hover:scale-105 transition-all shadow-2xl flex items-center gap-3"
                  >
                    {publicLang === 'ar' ? 'انضم للنادي' : 'Join the Club'}
                    <ArrowRight size={20} className={`group-hover:translate-x-1 transition-transform ${publicLang === 'ar' ? 'rotate-180' : ''}`} />
                  </button>
                  <button 
                    onClick={() => setIsPublicTrial(true)}
                    className="px-10 py-6 bg-white text-zinc-900 border border-zinc-200 rounded-full font-bold hover:bg-zinc-50 transition-all flex items-center gap-3"
                  >
                    {publicLang === 'ar' ? 'احجز تجربة' : 'Book Trial'}
                    <Calendar size={20} />
                  </button>
                  <button 
                    onClick={() => {
                      setIsPublicInfo(false);
                      setIsPublicRegistration(false);
                    }}
                    className="px-10 py-6 bg-white text-zinc-900 border border-zinc-200 rounded-full font-bold hover:bg-zinc-50 transition-all flex items-center gap-3"
                  >
                    {publicLang === 'ar' ? 'بوابة الأعضاء' : 'Member Portal'}
                    <LogIn size={20} />
                  </button>
                <a 
                  href="#about"
                  className="px-10 py-6 bg-white text-zinc-900 border border-zinc-200 rounded-full font-bold hover:bg-zinc-50 transition-all flex items-center gap-3"
                >
                  {publicLang === 'ar' ? 'استكشف المزيد' : 'Explore More'}
                  <ChevronDown size={20} />
                </a>
              </motion.div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9, rotate: 2 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="relative hidden lg:block"
            >
              <div className="relative aspect-[4/5] rounded-[4rem] overflow-hidden shadow-2xl">
                <img 
                  src={config?.publicInfo?.heroImageUrl || "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1000"} 
                  alt="Hero" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/40 to-transparent" />
              </div>
              {/* Floating Badge */}
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-10 -left-10 bg-white p-8 rounded-[2.5rem] shadow-2xl border border-zinc-100 max-w-[240px]"
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <CheckCircle2 size={24} />
                  </div>
                  <span className="font-bold text-zinc-900">Certified Excellence</span>
                </div>
                <p className="text-sm text-zinc-500 serif italic">Recognized as the leading club in the region for professional development.</p>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Dynamic Content Sections */}
        <div className="space-y-0">
          {(info?.sectionOrder || ['images', 'videos', 'about', 'activities', 'programs', 'locations', 'calendar', 'contact']).map(section => (
            renderPublicSection(section)
          ))}
        </div>

        {/* Modern Footer */}
        <footer className="bg-white border-t border-zinc-100 py-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
              <div className="col-span-1 md:col-span-2 space-y-6">
                <div className="flex items-center gap-4">
                  {config?.logoUrl ? (
                    <img src={config.logoUrl} alt="Logo" className="h-12 w-auto object-contain" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="w-12 h-12 bg-zinc-900 rounded-2xl flex items-center justify-center">
                      <Users size={24} className="text-white" />
                    </div>
                  )}
                  <span className="font-bold text-2xl tracking-tight">{config?.clubName}</span>
                </div>
                <p className="text-zinc-500 max-w-sm serif italic text-lg leading-relaxed">
                  {publicLang === 'ar' 
                    ? 'تمكين الأفراد من خلال التميز والمجتمع والتوجيه المهني.' 
                    : 'Empowering individuals through excellence, community, and professional guidance.'}
                </p>
              </div>
              
              <div className="space-y-6">
                <h4 className="font-bold text-zinc-900 uppercase tracking-widest text-xs">
                  {publicLang === 'ar' ? 'روابط سريعة' : 'Quick Links'}
                </h4>
                <ul className="space-y-4">
                  <li><a href="#about" className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'عن النادي' : 'About Us'}</a></li>
                  <li><a href="#activities" className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'الأنشطة' : 'Activities'}</a></li>
                  <li><a href="#gallery" className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'المعرض' : 'Gallery'}</a></li>
                  <li><a href="#contact" className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'اتصل بنا' : 'Contact'}</a></li>
                </ul>
              </div>

              <div className="space-y-6">
                <h4 className="font-bold text-zinc-900 uppercase tracking-widest text-xs">
                  {publicLang === 'ar' ? 'البوابة' : 'Portal'}
                </h4>
                <ul className="space-y-4">
                  <li><button onClick={() => setIsPublicRegistration(true)} className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'تسجيل الأعضاء' : 'Member Registration'}</button></li>
                  <li><button onClick={() => { setIsPublicInfo(false); setIsPublicRegistration(false); }} className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'دخول الأعضاء' : 'Member Sign In'}</button></li>
                  <li><button onClick={() => { setIsPublicInfo(false); setIsPublicRegistration(false); }} className="text-zinc-500 hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'دخول المسؤولين' : 'Admin Access'}</button></li>
                </ul>
              </div>
            </div>
            
            <div className="pt-12 border-t border-zinc-100 flex flex-col md:flex-row justify-between items-center gap-6">
              <p className="text-zinc-400 text-sm serif italic">
                &copy; {new Date().getFullYear()} {config?.clubName}. {publicLang === 'ar' ? 'جميع الحقوق محفوظة.' : 'All rights reserved.'}
              </p>
              <div className="flex items-center gap-8 text-zinc-400 text-sm">
                <button onClick={() => setIsViewingTerms(true)} className="hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'سياسة الخصوصية' : 'Privacy Policy'}</button>
                <button onClick={() => setIsViewingTerms(true)} className="hover:text-zinc-900 transition-colors">{publicLang === 'ar' ? 'شروط الخدمة' : 'Terms of Service'}</button>
              </div>
            </div>
          </div>
        </footer>

        {/* Zoomed Image Modal */}
        <AnimatePresence>
          {zoomedImage && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setZoomedImage(null)}
              className="fixed inset-0 z-[200] bg-black/95 flex items-center justify-center p-4 cursor-zoom-out backdrop-blur-sm"
            >
              <motion.img
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                src={zoomedImage}
                className="max-w-full max-h-full rounded-2xl shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => setZoomedImage(null)}
                className="absolute top-8 right-8 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors"
              >
                <X size={24} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Registration Modal */}
        <AnimatePresence>
          {isPublicRegistration && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[150] bg-zinc-900/60 backdrop-blur-sm overflow-y-auto p-4 py-12"
            >
              <motion.div 
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.95 }}
                className="max-w-2xl w-full bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-zinc-100 mx-auto"
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    {config?.logoUrl ? (
                      <img 
                        src={config.logoUrl} 
                        alt="Logo" 
                        className="h-12 w-auto object-contain"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-zinc-900 rounded-2xl flex items-center justify-center shadow-lg">
                        <Users size={24} className="text-white" />
                      </div>
                    )}
                    <div>
                      <h1 className="text-2xl font-bold text-zinc-900">Member Registration</h1>
                      <p className="text-zinc-500 text-sm">Join our club by filling out the form below</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsPublicRegistration(false)}
                    className="p-3 hover:bg-zinc-100 rounded-2xl transition-colors text-zinc-400"
                  >
                    <X size={24} />
                  </button>
                </div>

                {config && !config.registrationEnabled ? (
                  <div className="text-center py-12 bg-rose-50 rounded-3xl border border-rose-100">
                    <XCircle className="mx-auto text-rose-500 mb-4" size={48} />
                    <h2 className="text-xl font-bold text-rose-900 mb-2">Registration Disabled</h2>
                    <p className="text-rose-600">The administrator has disabled new registrations at this time.</p>
                  </div>
                ) : !publicAdminUid ? (
                  <div className="text-center py-12 bg-rose-50 rounded-3xl border border-rose-100">
                    <XCircle className="mx-auto text-rose-500 mb-4" size={48} />
                    <h2 className="text-xl font-bold text-rose-900 mb-2">Invalid Registration Link</h2>
                    <p className="text-rose-600">Please contact the club administrator for a valid link.</p>
                  </div>
                ) : (
                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    if (isSubmitting) return;
                    setIsSubmitting(true);
                    const formData = new FormData(e.currentTarget);
                    const data = {
                      name: (formData.get('name') as string) || '',
                      nameArabic: (formData.get('nameArabic') as string) || '',
                      email: (formData.get('email') as string) || '',
                      phone: (formData.get('phone') as string) || '',
                      whatsapp: (formData.get('whatsapp') as string) || '',
                      birthday: (formData.get('birthday') as string) || '',
                      nationality: (formData.get('nationality') as string) || '',
                      location: (formData.get('location') as string) || '',
                      ageGroup: (formData.get('ageGroup') as string) || '',
                      activity: (formData.get('activity') as string) || '',
                      parentsInformation: (formData.get('parentsInformation') as string) || '',
                      profileImage: regProfileImage || undefined,
                      idImage: regIdImage || undefined,
                      status: 'pending' as const,
                      requestedAt: new Date().toISOString(),
                      adminUid: publicAdminUid
                    };

                    try {
                      if (config?.termsAndConditions && !agreedToTerms) {
                        alert("Please agree to the terms and conditions to continue.");
                        setIsSubmitting(false);
                        return;
                      }
                      await addDoc(collection(db, 'registration_requests'), data);
                      alert("Registration request submitted successfully! We will contact you soon.");
                      setIsPublicRegistration(false);
                      setRegProfileImage(null);
                      setRegIdImage(null);
                    } catch (error: any) {
                      console.error("Error submitting registration:", error);
                      alert(error.message || "Failed to submit registration request. Please try again.");
                      handleFirestoreError(error, OperationType.CREATE, 'registration_requests');
                    } finally {
                      setIsSubmitting(false);
                    }
                  }} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Full Name (English) *</label>
                        <input name="name" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="John Doe" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Full Name (Arabic)</label>
                        <input name="nameArabic" dir="rtl" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 text-right" placeholder="جون دو" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Email Address *</label>
                        <input name="email" type="email" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="john@example.com" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Phone Number</label>
                        <input name="phone" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="+971 50 000 0000" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">WhatsApp Number</label>
                        <input name="whatsapp" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="+971 50 000 0000" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Birthday</label>
                        <input name="birthday" type="date" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Nationality</label>
                        <input name="nationality" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="Emirati" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Location / Branch</label>
                        <select name="location" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                          <option value="">Select Location</option>
                          {(config?.lists?.locations || DEFAULT_LISTS.locations).map(l => (
                            <option key={l} value={l}>{l}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Age Group / Team</label>
                        <select name="ageGroup" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                          <option value="">Select Age Group</option>
                          {(config?.lists?.ageGroups || DEFAULT_LISTS.ageGroups).map(a => (
                            <option key={a} value={a}>{a}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Activity</label>
                        <select name="activity" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                          <option value="">Select Activity</option>
                          {(config?.lists?.activities || DEFAULT_LISTS.activities).map(a => (
                            <option key={a} value={a}>{a}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Profile Image</label>
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-zinc-50 border-2 border-dashed border-zinc-200 rounded-2xl flex items-center justify-center overflow-hidden">
                            {regProfileImage ? (
                              <img src={regProfileImage} alt="Profile" className="w-full h-full object-cover" />
                            ) : (
                              <Camera className="text-zinc-300" size={24} />
                            )}
                          </div>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const compressed = await compressImage(file);
                                setRegProfileImage(compressed);
                              }
                            }}
                            className="text-xs text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-zinc-100 file:text-zinc-900 hover:file:bg-zinc-200 cursor-pointer"
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">ID Image (Emirates ID / Passport)</label>
                        <div className="flex items-center gap-4">
                          <div className="w-16 h-16 bg-zinc-50 border-2 border-dashed border-zinc-200 rounded-2xl flex items-center justify-center overflow-hidden">
                            {regIdImage ? (
                              <img src={regIdImage} alt="ID" className="w-full h-full object-cover" />
                            ) : (
                              <FileText className="text-zinc-300" size={24} />
                            )}
                          </div>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const compressed = await compressImage(file);
                                setRegIdImage(compressed);
                              }
                            }}
                            className="text-xs text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-zinc-100 file:text-zinc-900 hover:file:bg-zinc-200 cursor-pointer"
                          />
                        </div>
                      </div>
                    </div>

                    {config?.termsAndConditions && (
                      <div className="flex items-start gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                        <input 
                          type="checkbox" 
                          id="reg-terms" 
                          required 
                          checked={agreedToTerms}
                          onChange={(e) => setAgreedToTerms(e.target.checked)}
                          className="mt-1 w-4 h-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900" 
                        />
                        <label htmlFor="reg-terms" className="text-sm text-zinc-600 leading-relaxed">
                          I agree to the <button type="button" onClick={() => setIsViewingTerms(true)} className="text-zinc-900 font-bold hover:underline">Terms & Conditions</button> for the registration.
                        </label>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200 disabled:opacity-50 mt-8"
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Registration Request'}
                    </button>
                  </form>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Trial Session Modal */}
        <AnimatePresence>
          {isPublicTrial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[150] bg-zinc-900/60 backdrop-blur-sm overflow-y-auto p-4 py-12"
            >
              <motion.div 
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.95 }}
                className="max-w-2xl w-full bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-zinc-100 mx-auto"
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-zinc-900 rounded-2xl flex items-center justify-center shadow-lg">
                      <Calendar size={24} className="text-white" />
                    </div>
                    <div>
                      <h1 className="text-2xl font-bold text-zinc-900">Book Trial Session</h1>
                      <p className="text-zinc-500 text-sm">Experience our club with a free trial session</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsPublicTrial(false)}
                    className="p-3 hover:bg-zinc-100 rounded-2xl transition-colors text-zinc-400"
                  >
                    <X size={24} />
                  </button>
                </div>

                {!publicAdminUid ? (
                  <div className="text-center py-12 bg-rose-50 rounded-3xl border border-rose-100">
                    <XCircle className="mx-auto text-rose-500 mb-4" size={48} />
                    <h2 className="text-xl font-bold text-rose-900 mb-2">Invalid Link</h2>
                    <p className="text-rose-600">Please contact the club administrator for a valid link.</p>
                  </div>
                ) : (
                  <form onSubmit={async (e) => {
                    e.preventDefault();
                    if (isSubmitting) return;
                    setIsSubmitting(true);
                    const formData = new FormData(e.currentTarget);
                    const data: any = {
                      name: (formData.get('name') as string) || '',
                      email: (formData.get('email') as string) || '',
                      phone: (formData.get('phone') as string) || '',
                      activity: (formData.get('activity') as string) || '',
                      location: (formData.get('location') as string) || '',
                      preferredDate: (formData.get('preferredDate') as string) || '',
                      notes: (formData.get('notes') as string) || '',
                      status: 'pending' as const,
                      requestedAt: new Date().toISOString(),
                      adminUid: publicAdminUid
                    };

                    if (trialProfileImage) data.profileImage = trialProfileImage;
                    if (trialIdImage) data.idImage = trialIdImage;

                    try {
                      await addDoc(collection(db, 'trial_requests'), data);
                      alert("Trial session request submitted successfully! We will contact you soon.");
                      setIsPublicTrial(false);
                      setTrialProfileImage(null);
                      setTrialIdImage(null);
                      setAgreedToTrialTerms(false);
                    } catch (error: any) {
                      console.error("Error submitting trial request:", error);
                      alert(error.message || "Failed to submit trial request. Please try again.");
                      handleFirestoreError(error, OperationType.CREATE, 'trial_requests');
                    } finally {
                      setIsSubmitting(false);
                    }
                  }} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Full Name *</label>
                        <input name="name" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="John Doe" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Email Address *</label>
                        <input name="email" type="email" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="john@example.com" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Phone Number *</label>
                        <input name="phone" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" placeholder="+971 50 000 0000" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Activity *</label>
                        <select name="activity" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                          <option value="">Select Activity</option>
                          {(config?.lists?.activities || DEFAULT_LISTS.activities).map(act => (
                            <option key={act} value={act}>{act}</option>
                          ))}
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Preferred Date *</label>
                        <input name="preferredDate" type="date" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Location / Branch *</label>
                        <select name="location" required className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                          <option value="">Select Location</option>
                          {(config?.lists?.locations || DEFAULT_LISTS.locations).map(loc => (
                            <option key={loc} value={loc}>{loc}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Profile Image</label>
                        <div className="flex flex-col gap-3 p-4 bg-zinc-50 border border-zinc-100 rounded-xl">
                          <div className="flex items-center gap-4">
                            {trialProfileImage ? (
                              <img src={trialProfileImage} className="w-12 h-12 rounded-lg object-cover" />
                            ) : (
                              <div className="w-12 h-12 bg-zinc-200 rounded-lg flex items-center justify-center text-zinc-400">
                                <Camera size={20} />
                              </div>
                            )}
                            <div className="flex-1">
                              <input type="file" id="trial-profile-upload" accept="image/*" className="hidden" onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) setTrialProfileImage(await compressImage(file, 400, 400, 0.7));
                              }} />
                              <label htmlFor="trial-profile-upload" className="px-3 py-1.5 bg-white border border-zinc-200 rounded-lg text-[10px] font-bold uppercase tracking-wider cursor-pointer hover:bg-zinc-50 transition-colors">
                                {trialProfileImage ? 'Change Image' : 'Upload Image'}
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Emirates ID / Passport</label>
                        <div className="flex flex-col gap-3 p-4 bg-zinc-50 border border-zinc-100 rounded-xl">
                          <div className="flex items-center gap-4">
                            {trialIdImage ? (
                              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-lg flex items-center justify-center">
                                <Check size={20} />
                              </div>
                            ) : (
                              <div className="w-12 h-12 bg-zinc-200 rounded-lg flex items-center justify-center text-zinc-400">
                                <FileText size={20} />
                              </div>
                            )}
                            <div className="flex-1">
                              <input type="file" id="trial-id-upload" accept="image/*,application/pdf" className="hidden" onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  if (file.type === 'application/pdf') setTrialIdImage(await fileToBase64(file));
                                  else setTrialIdImage(await compressImage(file, 800, 800, 0.7));
                                }
                              }} />
                              <label htmlFor="trial-id-upload" className="px-3 py-1.5 bg-white border border-zinc-200 rounded-lg text-[10px] font-bold uppercase tracking-wider cursor-pointer hover:bg-zinc-50 transition-colors">
                                {trialIdImage ? 'Change Document' : 'Upload Document'}
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Additional Notes</label>
                      <textarea name="notes" className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 min-h-[100px]" placeholder="Any special requirements or questions..." />
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                      <input 
                        type="checkbox" 
                        id="trial-terms" 
                        required 
                        checked={agreedToTrialTerms}
                        onChange={(e) => setAgreedToTrialTerms(e.target.checked)}
                        className="mt-1 w-4 h-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900" 
                      />
                      <label htmlFor="trial-terms" className="text-sm text-zinc-600 leading-relaxed">
                        I agree to the <button type="button" onClick={() => setIsViewingTerms(true)} className="text-zinc-900 font-bold hover:underline">Terms & Conditions</button> for the trial session.
                      </label>
                    </div>

                    <button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="w-full py-5 bg-zinc-900 text-white rounded-2xl font-bold hover:scale-[1.02] transition-all shadow-xl disabled:opacity-50 flex items-center justify-center gap-3"
                    >
                      {isSubmitting ? 'Submitting...' : 'Submit Trial Request'}
                      <ArrowRight size={20} />
                    </button>
                  </form>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Terms & Conditions Modal */}
        <AnimatePresence>
          {isViewingTerms && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[160] bg-zinc-900/60 backdrop-blur-sm overflow-y-auto p-4 py-12"
            >
              <motion.div 
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.95 }}
                className="max-w-2xl w-full bg-white p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-zinc-100 mx-auto"
              >
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-2xl font-bold text-zinc-900">Terms & Conditions</h2>
                  <button 
                    onClick={() => setIsViewingTerms(false)}
                    className="p-3 hover:bg-zinc-100 rounded-2xl transition-colors text-zinc-400"
                  >
                    <X size={24} />
                  </button>
                </div>
                <div className="prose prose-zinc prose-lg max-w-none text-zinc-600 leading-relaxed serif">
                  {isPublicTrial ? (
                    config?.trialTermsAndConditions ? <Markdown>{config.trialTermsAndConditions}</Markdown> : <p className="italic text-zinc-400">No trial terms and conditions have been configured yet.</p>
                  ) : config?.termsAndConditions ? (
                    <Markdown>{config.termsAndConditions}</Markdown>
                  ) : (
                    <p className="italic text-zinc-400">No terms and conditions have been configured yet.</p>
                  )}
                </div>
                <div className="mt-12 pt-8 border-t border-zinc-100 flex justify-center">
                  <button
                    onClick={() => setIsViewingTerms(false)}
                    className="px-12 py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  if (!user) {
    // Automatically show Public Info if adminUid is present in URL
    if (publicAdminUid && !isPublicInfo) {
      setIsPublicInfo(true);
    }

    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50 p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full bg-white p-10 rounded-[2.5rem] shadow-xl border border-zinc-100 text-center"
        >
          {config?.logoUrl ? (
            <div className="mb-8">
              <img 
                src={config.logoUrl} 
                alt="Logo" 
                className="h-20 w-auto mx-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
          ) : (
            <div className="w-20 h-20 bg-zinc-900 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-lg shadow-zinc-200">
              <Users size={40} className="text-white" />
            </div>
          )}
          <h1 className="text-3xl font-bold text-zinc-900 mb-2 tracking-tight">{config?.clubName || 'Club Manager'}</h1>
          <p className="text-zinc-500 mb-10 leading-relaxed">Manage your club members, track attendance, and handle payments with ease.</p>
          
          <div className="space-y-4">
            <button
              onClick={login}
              className="w-full flex items-center justify-center gap-3 bg-zinc-900 text-white py-4 rounded-2xl font-semibold hover:bg-zinc-800 transition-all active:scale-[0.98] shadow-lg shadow-zinc-200"
            >
              <LogIn size={20} />
              Sign in with Google
            </button>
            
            {publicAdminUid && (
              <button
                onClick={() => setIsPublicInfo(true)}
                className="w-full flex items-center justify-center gap-3 bg-white text-zinc-900 border border-zinc-200 py-4 rounded-2xl font-semibold hover:bg-zinc-50 transition-all active:scale-[0.98]"
              >
                <Globe size={20} />
                View Club Information
              </button>
            )}
          </div>

          <div className="mt-8 pt-8 border-t border-zinc-100">
            {publicAdminUid ? (
              config && !config.registrationEnabled ? (
                <p className="text-sm text-rose-500 font-medium italic">
                  New member registration is currently disabled by the administrator.
                </p>
              ) : (
                <>
                  <p className="text-sm text-zinc-500 mb-4">Are you a new member?</p>
                  <button
                    onClick={() => setIsPublicRegistration(true)}
                    className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100 flex items-center justify-center gap-2"
                  >
                    <UserPlus size={20} />
                    Request Registration
                  </button>
                </>
              )
            ) : (
              <p className="text-xs text-zinc-400 italic leading-relaxed">
                To request registration or view club info, please use the link provided by your club administrator.
              </p>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  if (!isManagement && !memberRecord) {
    return (
      <div className="min-h-screen bg-zinc-50 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white p-12 rounded-[3rem] shadow-2xl border border-zinc-100 text-center"
        >
          <div className="w-20 h-20 bg-amber-50 rounded-3xl flex items-center justify-center mx-auto mb-6">
            <UserIcon size={40} className="text-amber-600" />
          </div>
          <h1 className="text-2xl font-bold text-zinc-900 mb-4">Access Restricted</h1>
          <p className="text-zinc-500 mb-8 leading-relaxed">
            Your account (<span className="font-semibold text-zinc-900">{user.email}</span>) does not have access to this system. 
            Please contact the administrator to be added as a user or member.
          </p>
          <div className="space-y-4">
            <button
              onClick={logout}
              className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
            >
              Sign Out
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  function renderEvaluationModal() {
    if (!selectedMember) return null;

    const memberEvals = evaluations.filter(e => e.memberId === selectedMember.id);

    const handleSaveEvaluation = async () => {
      if (!user || !selectedMember) return;
      try {
        const isAdmin = currentUserAccount?.role === 'admin';
        const evaluationData: Omit<Evaluation, 'id'> = {
          memberId: selectedMember.id,
          coachId: user.uid,
          uid: currentAdminUid!,
          date: newEvaluation.date!,
          scores: newEvaluation.scores as Record<string, number>,
          notes: newEvaluation.notes || '',
          status: isAdmin ? (newEvaluation.status || 'approved') : 'pending',
          createdAt: new Date().toISOString()
        };

        if (editingEvaluationId) {
          await updateDoc(doc(db, 'evaluations', editingEvaluationId), evaluationData);
        } else {
          await addDoc(collection(db, 'evaluations'), evaluationData);
        }

        // Send email notification if approved and enabled
        if (evaluationData.status === 'approved' && config?.emailNotifications?.evaluation && config?.templates?.evaluation && selectedMember.email) {
          let scoresText = '';
          config.evaluationSettings?.categories
            .filter(cat => !cat.activity || cat.activity === selectedMember.activity)
            .forEach(cat => {
              scoresText += `\n${cat.name}:\n`;
              cat.skills.forEach(skill => {
                const score = evaluationData.scores[skill.id] || 0;
                scoresText += `- ${skill.name}: ${score}/5\n`;
              });
            });

          const body = config.templates.evaluation.body
            .replace(/{name}/g, selectedMember.name)
            .replace(/{date}/g, format(new Date(evaluationData.date), 'MMMM d, yyyy'))
            .replace(/{scores}/g, scoresText)
            .replace(/{notes}/g, evaluationData.notes);

          await sendEmail(
            selectedMember.email,
            config.templates.evaluation.subject,
            body,
            'evaluation',
            currentAdminUid!,
            body.replace(/\n/g, '<br>'),
            config.smtp
          );
        }

        setIsAddingEvaluation(false);
        setEditingEvaluationId(null);
        setNewEvaluation({ date: new Date().toISOString(), scores: {}, notes: '', status: 'approved' });
        alert(evaluationData.status === 'approved' ? "Evaluation saved and member notified!" : "Evaluation submitted for admin approval.");
      } catch (error) {
        console.error("Error saving evaluation:", error);
        handleFirestoreError(error, editingEvaluationId ? OperationType.UPDATE : OperationType.CREATE, 'evaluations');
      }
    };

    return (
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-zinc-50 border border-zinc-100 overflow-hidden">
              {selectedMember.profileImage ? (
                <img src={selectedMember.profileImage} alt={selectedMember.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-zinc-300">
                  <UserIcon size={32} />
                </div>
              )}
            </div>
            <div>
              <h3 className="text-xl font-bold text-zinc-900">{selectedMember.name}</h3>
              <p className="text-sm text-zinc-500">{selectedMember.activity} • {selectedMember.ageGroup}</p>
            </div>
          </div>
          {!isAddingEvaluation && (
            <button
              onClick={() => setIsAddingEvaluation(true)}
              className="px-6 py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all flex items-center gap-2"
            >
              <Plus size={18} />
              New Evaluation
            </button>
          )}
        </div>

        {isAddingEvaluation ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-zinc-50 p-8 rounded-[2.5rem] border border-zinc-100 space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Evaluation Date</label>
                <input
                  type="date"
                  value={newEvaluation.date?.split('T')[0]}
                  onChange={(e) => setNewEvaluation({ ...newEvaluation, date: new Date(e.target.value).toISOString() })}
                  className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10"
                />
              </div>
              {currentUserAccount?.role === 'admin' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</label>
                  <select
                    value={newEvaluation.status || 'approved'}
                    onChange={(e) => setNewEvaluation({ ...newEvaluation, status: e.target.value as 'pending' | 'approved' })}
                    className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10"
                  >
                    <option value="approved">Approved (Notify Member)</option>
                    <option value="pending">Pending Approval</option>
                  </select>
                </div>
              )}
            </div>

            <div className="space-y-8">
              {config?.evaluationSettings?.categories
                .filter(category => !category.activity || category.activity === selectedMember.activity)
                .map(category => (
                <div key={category.id} className="space-y-4">
                  <h4 className="font-bold text-zinc-900 flex items-center gap-2">
                    <div className="w-1.5 h-6 bg-zinc-900 rounded-full" />
                    {category.name}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {category.skills.map(skill => (
                      <div key={skill.id} className="bg-white p-4 rounded-2xl border border-zinc-100 flex items-center justify-between">
                        <span className="text-sm font-medium text-zinc-700">{skill.name}</span>
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5].map(score => (
                            <button
                              key={score}
                              onClick={() => {
                                const scores = { ...(newEvaluation.scores || {}) };
                                scores[skill.id] = score;
                                setNewEvaluation({ ...newEvaluation, scores });
                              }}
                              className={cn(
                                "w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold transition-all",
                                (newEvaluation.scores?.[skill.id] || 0) >= score
                                  ? "bg-zinc-900 text-white"
                                  : "bg-zinc-100 text-zinc-400 hover:bg-zinc-200"
                              )}
                            >
                              {score}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              {config?.evaluationSettings?.categories.filter(category => !category.activity || category.activity === selectedMember.activity).length === 0 && (
                <div className="text-center py-12 bg-zinc-50 rounded-3xl border border-dashed border-zinc-200">
                  <p className="text-zinc-500 text-sm">No evaluation categories configured for {selectedMember.activity}.</p>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Notes & Observations</label>
              <textarea
                value={newEvaluation.notes}
                onChange={(e) => setNewEvaluation({ ...newEvaluation, notes: e.target.value })}
                placeholder="Enter any additional feedback or observations..."
                className="w-full px-4 py-3 bg-white border border-zinc-200 rounded-xl focus:ring-2 focus:ring-zinc-900/10 h-32 resize-none"
              />
            </div>

            <div className="flex items-center gap-4 pt-4">
              <button
                onClick={handleSaveEvaluation}
                className="flex-1 py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200"
              >
                Save Evaluation
              </button>
              <button
                onClick={() => setIsAddingEvaluation(false)}
                className="px-8 py-4 bg-white text-zinc-500 border border-zinc-200 rounded-2xl font-bold hover:bg-zinc-50 transition-all"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {memberEvals.length === 0 ? (
              <div className="text-center py-20 bg-zinc-50 rounded-[2.5rem] border border-dashed border-zinc-200">
                <ClipboardList className="mx-auto text-zinc-300 mb-4" size={48} />
                <h4 className="text-lg font-bold text-zinc-900 mb-1">No Evaluations Yet</h4>
                <p className="text-zinc-500">Start tracking this member's progress by creating their first evaluation.</p>
              </div>
            ) : (
              memberEvals.map(evaluation => (
                <div key={evaluation.id} className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Calendar size={18} className="text-zinc-400" />
                      <span className="font-bold text-zinc-900">{format(new Date(evaluation.date), 'MMMM d, yyyy')}</span>
                      {evaluation.status === 'pending' && (
                        <span className="px-3 py-1 bg-amber-50 text-amber-600 text-[10px] font-bold uppercase tracking-wider rounded-full border border-amber-100 flex items-center gap-1">
                          <Clock size={10} />
                          Pending Approval
                        </span>
                      )}
                      {evaluation.status === 'approved' && (
                        <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-bold uppercase tracking-wider rounded-full border border-emerald-100 flex items-center gap-1">
                          <CheckCircle2 size={10} />
                          Approved
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      {currentUserAccount?.role === 'admin' && evaluation.status === 'pending' && (
                        <button
                          onClick={async () => {
                            try {
                              await updateDoc(doc(db, 'evaluations', evaluation.id), { status: 'approved' });
                              
                              // Send email notification upon approval
                              if (config?.emailNotifications?.evaluation && config?.templates?.evaluation && selectedMember.email) {
                                let scoresText = '';
                                config.evaluationSettings?.categories
                                  .filter(cat => !cat.activity || cat.activity === selectedMember.activity)
                                  .forEach(cat => {
                                    scoresText += `\n${cat.name}:\n`;
                                    cat.skills.forEach(skill => {
                                      const score = evaluation.scores[skill.id] || 0;
                                      scoresText += `- ${skill.name}: ${score}/5\n`;
                                    });
                                  });

                                const body = config.templates.evaluation.body
                                  .replace(/{name}/g, selectedMember.name)
                                  .replace(/{date}/g, format(new Date(evaluation.date), 'MMMM d, yyyy'))
                                  .replace(/{scores}/g, scoresText)
                                  .replace(/{notes}/g, evaluation.notes || '');

                                await sendEmail(
                                  selectedMember.email,
                                  config.templates.evaluation.subject,
                                  body,
                                  'evaluation',
                                  currentAdminUid!,
                                  body.replace(/\n/g, '<br>'),
                                  config.smtp
                                );
                              }
                              alert("Evaluation approved and member notified!");
                            } catch (err: any) {
                              handleFirestoreError(err, OperationType.UPDATE, 'evaluations');
                            }
                          }}
                          className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-lg hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 flex items-center gap-2"
                        >
                          <CheckCircle2 size={14} />
                          Approve
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setNewEvaluation({
                            date: evaluation.date,
                            scores: evaluation.scores,
                            notes: evaluation.notes,
                            status: evaluation.status
                          });
                          setEditingEvaluationId(evaluation.id);
                          setIsAddingEvaluation(true);
                        }}
                        className="p-2 text-zinc-400 hover:text-zinc-900 transition-colors"
                      >
                        <Edit2 size={18} />
                      </button>
                      <button
                        onClick={() => setDeleteConfirm({
                          type: 'evaluations',
                          id: evaluation.id,
                          label: `Evaluation from ${format(new Date(evaluation.date), 'MMMM d, yyyy')}`
                        })}
                        className="p-2 text-zinc-400 hover:text-rose-500 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {config?.evaluationSettings?.categories
                      .filter(category => !category.activity || category.activity === selectedMember.activity)
                      .map(category => (
                      <div key={category.id} className="space-y-3">
                        <h5 className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{category.name}</h5>
                        <div className="space-y-2">
                          {category.skills.map(skill => (
                            <div key={skill.id} className="flex items-center justify-between">
                              <span className="text-sm text-zinc-600">{skill.name}</span>
                              <div className="flex items-center gap-1">
                                {[1, 2, 3, 4, 5].map(star => (
                                  <Star
                                    key={star}
                                    size={12}
                                    className={cn(
                                      star <= (evaluation.scores[skill.id] || 0) ? "text-amber-400 fill-amber-400" : "text-zinc-200"
                                    )}
                                  />
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  {evaluation.notes && (
                    <div className="pt-4 border-t border-zinc-50">
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-2">Notes</p>
                      <p className="text-sm text-zinc-600 italic leading-relaxed">"{evaluation.notes}"</p>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    );
  }

  function renderEvaluations() {
    const filteredMembers = members.filter(m => {
      const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                           m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
      const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
      const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
      const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
      const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
      
      return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
    });

    return (
      <div className="space-y-8 pb-20">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-2xl font-bold text-zinc-900">Member Evaluations</h3>
              <p className="text-zinc-500">Track and manage skill assessments for all members</p>
            </div>
          </div>

          <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMembers.map(member => {
            const memberEvals = evaluations.filter(e => e.memberId === member.id);
            const lastEval = memberEvals[0];

            return (
              <motion.div
                key={member.id}
                layoutId={member.id}
                onClick={() => {
                  setSelectedMember(member);
                  setModalType('evaluation');
                  setIsModalOpen(true);
                }}
                className="group bg-white p-6 rounded-[2.5rem] border border-zinc-100 shadow-sm hover:shadow-xl hover:shadow-zinc-200/50 transition-all cursor-pointer relative overflow-hidden"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-2xl bg-zinc-50 border border-zinc-100 overflow-hidden flex-shrink-0">
                    {member.profileImage ? (
                      <img src={member.profileImage} alt={member.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-zinc-300">
                        <UserIcon size={32} />
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-bold text-zinc-900 truncate">{member.name}</h4>
                    <p className="text-xs text-zinc-500 truncate">{member.activity} • {member.ageGroup}</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-zinc-500 font-medium">Total Evaluations</span>
                    <span className="px-2.5 py-1 bg-zinc-100 text-zinc-900 rounded-lg font-bold">{memberEvals.length}</span>
                  </div>
                  {lastEval && (
                    <div className="pt-4 border-t border-zinc-50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Last Assessment</span>
                        <span className="text-[10px] font-bold text-zinc-900">{format(new Date(lastEval.date), 'MMM d, yyyy')}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map(star => {
                          const scores = Object.values(lastEval.scores);
                          const avg = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
                          return (
                            <Star
                              key={star}
                              size={14}
                              className={cn(
                                star <= Math.round(avg) ? "text-amber-400 fill-amber-400" : "text-zinc-200"
                              )}
                            />
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="p-2 bg-zinc-900 text-white rounded-xl shadow-lg">
                    <Plus size={16} />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="h-screen bg-zinc-50 flex overflow-hidden">
        {/* Sidebar */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-40 w-72 bg-white border-r border-zinc-100 flex flex-col transition-transform duration-300 lg:translate-x-0 lg:static no-print",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <div className="flex-1 flex flex-col min-h-0 p-6">
            <div className="flex items-center gap-3 mb-10 px-2 shrink-0">
              {config?.logoUrl ? (
                <img 
                  src={config.logoUrl} 
                  alt="Logo" 
                  className="h-10 w-auto object-contain"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-10 h-10 bg-zinc-900 rounded-xl flex items-center justify-center shadow-md">
                  <Users size={20} className="text-white" />
                </div>
              )}
              <span className="text-xl font-bold text-zinc-900 tracking-tight">{config?.clubName || 'Club Manager'}</span>
            </div>

            <nav className="space-y-2 overflow-y-auto flex-1 pr-2 -mr-2 scrollbar-thin">
              {isManagement ? (
                <>
                  {AVAILABLE_PAGES.map(page => {
                    if (!hasPermission(page.id)) return null;
                    
                    // Special case for badge on requests
                    const badge = page.id === 'requests' 
                      ? ((registrationRequests.filter(r => r.status === 'pending').length + trialRequests.filter(r => r.status === 'pending').length) || undefined)
                      : undefined;

                    return (
                      <SidebarItem 
                        key={page.id}
                        icon={page.icon} 
                        label={page.label} 
                        active={activeTab === page.id} 
                        onClick={() => { setActiveTab(page.id as any); setSidebarOpen(false); }}
                        badge={badge}
                      />
                    );
                  })}
                </>
              ) : (
                <>
                  <SidebarItem icon={UserIcon} label="My Profile" active={activeTab === 'dashboard'} onClick={() => { setActiveTab('dashboard'); setSidebarOpen(false); }} />
                  <SidebarItem icon={Calendar} label="My Attendance" active={activeTab === 'attendance'} onClick={() => { setActiveTab('attendance'); setSidebarOpen(false); }} />
                  <SidebarItem icon={CreditCard} label="My Payments" active={activeTab === 'payments'} onClick={() => { setActiveTab('payments'); setSidebarOpen(false); }} />
                </>
              )}
            </nav>
          </div>

          <div className="p-6 border-t border-zinc-50 shrink-0">
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-zinc-500 hover:bg-rose-50 hover:text-rose-600 transition-all group"
            >
              <LogOut size={20} className="group-hover:translate-x-1 transition-transform" />
              <span className="font-medium text-sm">Sign Out</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
          {/* Header */}
          <header className="h-20 bg-white border-b border-zinc-100 px-6 flex items-center justify-between lg:px-10 no-print">
            <div className="flex items-center gap-4">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 hover:bg-zinc-100 rounded-lg">
                <Menu size={24} className="text-zinc-600" />
              </button>
              {config?.logoUrl && (
                <img 
                  src={config.logoUrl} 
                  alt="Logo" 
                  className="h-10 w-auto object-contain"
                  referrerPolicy="no-referrer"
                />
              )}
              <h2 className="text-xl font-bold text-zinc-900 capitalize">{activeTab}</h2>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-sm font-semibold text-zinc-900">{user.displayName}</span>
                <span className="text-xs text-zinc-500">{user.email}</span>
              </div>
              <img src={user.photoURL || ''} alt="Avatar" className="w-10 h-10 rounded-full border-2 border-zinc-100" referrerPolicy="no-referrer" />
            </div>
          </header>

          {/* Scrollable Area */}
          <div className="flex-1 overflow-y-auto p-6 lg:p-10">
            <AnimatePresence mode="wait">
              {activeTab === 'dashboard' && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  {isAdmin ? (
                    <>
                      <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <StatCard label="Active Members" value={stats.activeMembers} icon={Users} color="bg-zinc-900" />
                        <StatCard label="Total Revenue" value={`${stats.totalRevenue.toLocaleString()} AED`} icon={CreditCard} color="bg-emerald-600" />
                        <StatCard label="Total Expenses" value={`${stats.totalExpenses.toLocaleString()} AED`} icon={Wallet} color="bg-rose-600" />
                        <StatCard label="Net Profit" value={`${stats.netProfit.toLocaleString()} AED`} icon={TrendingUp} color="bg-indigo-600" />
                        <StatCard label="Total Balance" value={`${stats.currentTotalBalance.toLocaleString()} AED`} icon={CreditCard} color="bg-emerald-600 shadow-emerald-200" />
                        <StatCard label="Today's Attendance" value={stats.todayAttendance} icon={Calendar} color="bg-zinc-900" />
                        <StatCard label="Pending Payments" value={stats.pendingPayments} icon={Clock} color="bg-amber-600" />
                        {stats.pendingEvaluations > 0 && (
                          <StatCard 
                            label="Pending Evaluations" 
                            value={stats.pendingEvaluations} 
                            icon={Trophy} 
                            color="bg-amber-600" 
                            onClick={() => setActiveTab('evaluations')}
                          />
                        )}
                      </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    {/* Recent Members */}
                    <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-zinc-50 flex justify-between items-center">
                        <h3 className="font-bold text-zinc-900">Recent Members</h3>
                        <button onClick={() => setActiveTab('members')} className="text-sm font-medium text-zinc-500 hover:text-zinc-900 flex items-center gap-1">
                          View All <ChevronRight size={16} />
                        </button>
                      </div>
                      <div className="divide-y divide-zinc-50">
                        {members
                          .filter(m => {
                            const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                 m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                            const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
                            const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
                            const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
                            const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
                            return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                          })
                          .slice(0, 5).map(member => (
                          <div key={member.id} className="p-4 flex items-center justify-between hover:bg-zinc-50 transition-colors">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600 font-bold">
                                {member.name.charAt(0)}
                              </div>
                              <div>
                                <p className="text-sm font-semibold text-zinc-900">{member.name}</p>
                                <p className="text-xs text-zinc-500">{member.email}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className={cn(
                                "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                member.status === 'active' ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-500"
                              )}>
                                {member.status}
                              </span>
                              <button 
                                onClick={() => setDeleteConfirm({ type: 'members', id: member.id, label: member.name })}
                                className="p-2 text-zinc-300 hover:text-rose-500 transition-colors"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Recent Payments */}
                    <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-zinc-50 flex justify-between items-center">
                        <h3 className="font-bold text-zinc-900">Recent Payments</h3>
                        <button onClick={() => setActiveTab('payments')} className="text-sm font-medium text-zinc-500 hover:text-zinc-900 flex items-center gap-1">
                          View All <ChevronRight size={16} />
                        </button>
                      </div>
                      <div className="divide-y divide-zinc-50">
                        {payments
                          .filter(p => {
                            const member = members.find(m => m.id === p.memberId);
                            if (!member) return false;
                            const matchesSearch = member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                 member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                            const matchesCoach = !globalFilters.coach || member.coach === globalFilters.coach;
                            const matchesLocation = !globalFilters.location || member.location === globalFilters.location;
                            const matchesAgeGroup = !globalFilters.ageGroup || member.ageGroup === globalFilters.ageGroup;
                            const matchesStatus = !globalFilters.status || p.status === globalFilters.status;
                            return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                          })
                          .slice(0, 5).map(payment => {
                          const member = members.find(m => m.id === payment.memberId);
                          return (
                            <div key={payment.id} className="p-4 flex items-center justify-between hover:bg-zinc-50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600">
                                  <CreditCard size={18} />
                                </div>
                                <div>
                                  <p className="text-sm font-semibold text-zinc-900">{member?.name || 'Unknown'}</p>
                                  <p className="text-xs text-zinc-500">
                                    {payment.date}
                                    {payment.startDate && payment.endDate && (
                                      <span className="ml-2 opacity-60">({payment.startDate} - {payment.endDate})</span>
                                    )}
                                  </p>
                                </div>
                              </div>
                              <div className="text-right flex items-center gap-3">
                                <div>
                                  <p className="text-sm font-bold text-zinc-900">${payment.amount}</p>
                                  <p className={cn(
                                    "text-[10px] font-bold uppercase tracking-wider",
                                    payment.status === (localLists.paymentStatuses?.[0] || 'paid') ? "text-emerald-600" : "text-amber-600"
                                  )}>
                                    {payment.status}
                                  </p>
                                </div>
                                <button 
                                  onClick={() => setDeleteConfirm({ type: 'payments', id: payment.id, label: `Payment of ${payment.amount}` })}
                                  className="p-2 text-zinc-300 hover:text-rose-500 transition-colors"
                                >
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>

                  {/* Recent Attendance */}
                  <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-zinc-50 flex justify-between items-center">
                      <h3 className="font-bold text-zinc-900">Recent Attendance</h3>
                      <button onClick={() => setActiveTab('attendance')} className="text-sm font-medium text-zinc-500 hover:text-zinc-900 flex items-center gap-1">
                        View All <ChevronRight size={16} />
                      </button>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-zinc-50/50">
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-wider text-zinc-400">Member</th>
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-wider text-zinc-400">Date</th>
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-wider text-zinc-400 text-right">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-50">
                          {attendance.slice(0, 10).map(record => {
                            const member = members.find(m => m.id === record.memberId);
                            return (
                              <tr key={record.id} className="hover:bg-zinc-50 transition-colors">
                                <td className="px-6 py-4">
                                  <p className="text-sm font-semibold text-zinc-900">{member?.name || 'Unknown'}</p>
                                </td>
                                <td className="px-6 py-4">
                                  <p className="text-sm text-zinc-500">{record.date}</p>
                                </td>
                                <td className="px-6 py-4 text-right">
                                  <span className={cn(
                                    "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                    record.status === 'present' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                                  )}>
                                    {record.status}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
                  ) : (
                    <div className="max-w-4xl space-y-8">
                      {/* Member Profile Card */}
                      <div className="bg-white p-8 rounded-[3rem] border border-zinc-100 shadow-sm">
                        <div className="flex flex-col md:flex-row gap-8 items-start">
                          <div className="w-32 h-32 bg-zinc-100 rounded-[2rem] flex items-center justify-center text-4xl font-bold text-zinc-400 overflow-hidden border-4 border-white shadow-xl">
                            {memberRecord?.profileImage ? (
                              <img src={memberRecord.profileImage} alt={memberRecord.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              memberRecord?.name.charAt(0)
                            )}
                          </div>
                          <div className="flex-1 space-y-4">
                            <div>
                              <div className="flex items-center gap-3 mb-1">
                                <h2 className="text-3xl font-bold text-zinc-900">{memberRecord?.name}</h2>
                                <span className={cn(
                                  "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                  memberRecord?.status === 'active' ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-500"
                                )}>
                                  {memberRecord?.status}
                                </span>
                              </div>
                              {memberRecord?.nameArabic && <p className="text-xl text-zinc-400 font-arabic">{memberRecord.nameArabic}</p>}
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
                              <div>
                                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Category</p>
                                <p className="text-sm font-semibold text-zinc-900">{memberRecord?.category || '-'}</p>
                              </div>
                              <div>
                                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Age Group</p>
                                <p className="text-sm font-semibold text-zinc-900">{memberRecord?.ageGroup || '-'}</p>
                              </div>
                              <div>
                                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Joined At</p>
                                <p className="text-sm font-semibold text-zinc-900">{memberRecord?.joinedAt || '-'}</p>
                              </div>
                              <div>
                                <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Onboarding</p>
                                <div className="flex gap-2 mt-1">
                                  <span className={cn(
                                    "text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded",
                                    memberRecord?.receivedKit ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-400"
                                  )}>Kit</span>
                                  <span className={cn(
                                    "text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded",
                                    memberRecord?.joinedWhatsApp ? "bg-indigo-50 text-indigo-600" : "bg-zinc-100 text-zinc-400"
                                  )}>WA</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Stats for Member */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                         <StatCard label="Total Attendance" value={attendance.filter(a => a.status === 'present').length} icon={Calendar} color="bg-zinc-900" />
                         <StatCard label="Last Payment" value={payments.length > 0 ? `$${payments[0].amount}` : 'None'} icon={CreditCard} color="bg-zinc-900" />
                         <StatCard label="Current Level" value={memberRecord?.level || 'N/A'} icon={Trophy} color="bg-zinc-900" />
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'members' && (
                <motion.div
                  key="members"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="flex-1 w-full">
                      <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />
                    </div>
                    <button
                      onClick={() => { setModalType('member'); setEditingItem(null); setIsModalOpen(true); }}
                      className="flex items-center gap-2 bg-zinc-900 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 h-fit"
                    >
                      <Plus size={20} />
                      Add Member
                    </button>
                  </div>

                  <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-zinc-50/50 border-b border-zinc-100">
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Member</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Category</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Location</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Age Group</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Level</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Coach</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Onboarding</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-50">
                          {members
                            .filter(m => {
                              const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                   m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                              const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
                              const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
                              const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
                              const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
                              return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                            })
                            .map(member => (
                            <tr key={member.id} className="hover:bg-zinc-50/50 transition-colors">
                              <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                  {member.profileImage ? (
                                    <img 
                                      src={member.profileImage} 
                                      alt={member.name} 
                                      className="w-10 h-10 rounded-full object-cover border border-zinc-200 cursor-pointer hover:scale-110 transition-transform" 
                                      referrerPolicy="no-referrer" 
                                      onClick={() => setPreviewImage(member.profileImage)}
                                    />
                                  ) : (
                                    <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600 font-bold">
                                      {member.name.charAt(0)}
                                    </div>
                                  )}
                                  <div>
                                    <span className="font-semibold text-zinc-900 block">{member.name}</span>
                                    {member.birthday && <span className="text-[10px] text-zinc-400">BD: {member.birthday}</span>}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <span className="text-sm text-zinc-600 bg-zinc-100 px-2 py-1 rounded-md">
                                  {member.category || 'General'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-sm text-zinc-500">
                                {member.location || '-'}
                              </td>
                              <td className="px-6 py-4 text-sm text-zinc-500">
                                {member.ageGroup || '-'}
                              </td>
                              <td className="px-6 py-4 text-sm text-zinc-500">
                                {member.level || '-'}
                              </td>
                              <td className="px-6 py-4 text-sm text-zinc-500">
                                {member.coach || '-'}
                              </td>
                              <td className="px-6 py-4">
                                <span className={cn(
                                  "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                  member.status === (localLists.memberStatuses?.[0] || 'active') ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-500"
                                )}>
                                  {member.status}
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex gap-1.5">
                                  <div 
                                    className={cn(
                                      "w-2 h-2 rounded-full",
                                      member.receivedKit ? "bg-emerald-500" : "bg-zinc-200"
                                    )} 
                                    title={member.receivedKit ? "Kit Received" : "Kit Not Received"}
                                  />
                                  <div 
                                    className={cn(
                                      "w-2 h-2 rounded-full",
                                      member.joinedWhatsApp ? "bg-emerald-500" : "bg-zinc-200"
                                    )} 
                                    title={member.joinedWhatsApp ? "Joined WhatsApp" : "WhatsApp Not Joined"}
                                  />
                                </div>
                              </td>
                              <td className="px-6 py-4 text-right">
                                <div className="flex justify-end gap-2">
                                  {member.idImage && (
                                    <button 
                                      onClick={() => {
                                        if (member.idImage.startsWith('data:application/pdf')) {
                                          const win = window.open();
                                          win?.document.write(`<iframe src="${member.idImage}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
                                        } else {
                                          setPreviewImage(member.idImage);
                                        }
                                      }}
                                      className="p-2 text-zinc-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                                      title="View ID"
                                    >
                                      <FileText size={18} />
                                    </button>
                                  )}
                                  <button 
                                    onClick={() => { setModalType('member'); setEditingItem(member); setIsModalOpen(true); }}
                                    className="p-2 text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg transition-all"
                                  >
                                    <Edit2 size={18} />
                                  </button>
                                  <button 
                                    onClick={() => setDeleteConfirm({ type: 'members', id: member.id, label: member.name })}
                                    className="p-2 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </motion.div>
              )}

               {activeTab === 'attendance' && (
                <motion.div
                  key="attendance"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  {isAdmin ? (
                    <>
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div>
                          <h3 className="text-2xl font-bold text-zinc-900">
                            {format(new Date(selectedAttendanceDate), 'EEEE, MMMM d, yyyy')}
                          </h3>
                          <p className="text-zinc-500">Mark attendance for members</p>
                        </div>
                        <div className="flex items-center gap-3 bg-white p-2 rounded-2xl border border-zinc-100 shadow-sm">
                          <Calendar size={18} className="text-zinc-400 ml-2" />
                          <input
                            type="date"
                            value={selectedAttendanceDate}
                            onChange={(e) => setSelectedAttendanceDate(e.target.value)}
                            className="bg-transparent border-none focus:ring-0 text-sm font-bold text-zinc-900 pr-2"
                          />
                        </div>
                      </div>

                      <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />

                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {members
                          .filter(m => {
                            const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                 m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                            const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
                            const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
                            const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
                            const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
                            return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                          })
                          .map(member => {
                          const record = attendance.find(a => a.memberId === member.id && a.date === selectedAttendanceDate);
                          
                          return (
                            <div key={member.id} className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-600 font-bold text-lg">
                                  {member.name.charAt(0)}
                                </div>
                                <div>
                                  <p className="font-bold text-zinc-900">{member.name}</p>
                                  <p className="text-xs text-zinc-500">Active Member</p>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handleRecordAttendance(member.id, 'present')}
                                  className={cn(
                                    "p-3 rounded-xl transition-all",
                                    record?.status === 'present' 
                                      ? "bg-emerald-500 text-white shadow-lg shadow-emerald-200" 
                                      : "bg-zinc-50 text-zinc-400 hover:bg-zinc-100"
                                  )}
                                >
                                  <CheckCircle2 size={20} />
                                </button>
                                <button
                                  onClick={() => handleRecordAttendance(member.id, 'absent')}
                                  className={cn(
                                    "p-3 rounded-xl transition-all",
                                    record?.status === 'absent' 
                                      ? "bg-rose-500 text-white shadow-lg shadow-rose-200" 
                                      : "bg-zinc-50 text-zinc-400 hover:bg-zinc-100"
                                  )}
                                >
                                  <XCircle size={20} />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      <div className="flex justify-end">
                        <button
                          onClick={handleSaveAttendance}
                          disabled={isAttendanceSaving}
                          className="flex items-center gap-2 bg-zinc-900 text-white px-8 py-4 rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 disabled:opacity-50"
                        >
                          {isAttendanceSaving ? (
                            <>
                              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              Saving...
                            </>
                          ) : (
                            <>
                              <Save size={20} />
                              Save Attendance & Notify
                            </>
                          )}
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-zinc-50">
                        <h3 className="font-bold text-zinc-900">Attendance History</h3>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-zinc-50/50">
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Date</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest text-center">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-50">
                            {attendance.sort((a, b) => b.date.localeCompare(a.date)).map(record => (
                              <tr key={record.id} className="hover:bg-zinc-50 transition-colors">
                                <td className="px-6 py-4">
                                  <p className="text-sm font-semibold text-zinc-900">{format(new Date(record.date), 'MMMM d, yyyy')}</p>
                                </td>
                                <td className="px-6 py-4 text-center">
                                  <span className={cn(
                                    "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                    record.status === 'present' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                                  )}>
                                    {record.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                            {attendance.length === 0 && (
                              <tr>
                                <td colSpan={2} className="px-6 py-12 text-center text-zinc-500">No attendance records found.</td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'payments' && (
                <motion.div
                  key="payments"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  {isAdmin ? (
                    <>
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                        <div className="flex-1 w-full">
                          <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />
                        </div>
                        <button
                          onClick={() => { setModalType('payment'); setEditingItem(null); setIsModalOpen(true); }}
                          className="flex items-center gap-2 bg-zinc-900 text-white px-6 py-3 rounded-2xl font-semibold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 h-fit"
                        >
                          <Plus size={20} />
                          Add Payment
                        </button>
                      </div>

                      <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="w-full text-left">
                            <thead>
                              <tr className="bg-zinc-50/50 border-b border-zinc-100">
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Member</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Amount</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Date</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Period</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Type</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                                <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider text-right">Actions</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-zinc-50">
                              {payments
                                .filter(p => {
                                  const member = members.find(m => m.id === p.memberId);
                                  if (!member) return false;
                                  
                                  const matchesSearch = member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                       member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                                  const matchesCoach = !globalFilters.coach || member.coach === globalFilters.coach;
                                  const matchesLocation = !globalFilters.location || member.location === globalFilters.location;
                                  const matchesAgeGroup = !globalFilters.ageGroup || member.ageGroup === globalFilters.ageGroup;
                                  const matchesStatus = !globalFilters.status || p.status === globalFilters.status;
                                  return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                                })
                                .map(payment => {
                                  const member = members.find(m => m.id === payment.memberId);
                            return (
                              <tr key={payment.id} className="hover:bg-zinc-50/50 transition-colors">
                                <td className="px-6 py-4">
                                  <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600">
                                      <CreditCard size={18} />
                                    </div>
                                    <span className="font-semibold text-zinc-900">{member?.name || 'Unknown'}</span>
                                  </div>
                                </td>
                                <td className="px-6 py-4 font-bold text-zinc-900">
                                  ${payment.amount}
                                </td>
                                <td className="px-6 py-4 text-sm text-zinc-500">
                                  {payment.date}
                                </td>
                                <td className="px-6 py-4 text-xs text-zinc-500">
                                  {payment.startDate && payment.endDate ? (
                                    <div className="flex flex-col">
                                      <span>{payment.startDate}</span>
                                      <span className="text-[10px] opacity-50">to</span>
                                      <span>{payment.endDate}</span>
                                    </div>
                                  ) : '-'}
                                </td>
                                <td className="px-6 py-4">
                                  <span className="text-xs font-medium text-zinc-600 bg-zinc-100 px-2 py-1 rounded-full capitalize">
                                    {payment.type}
                                  </span>
                                </td>
                                <td className="px-6 py-4">
                                  <span className={cn(
                                    "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                    payment.status === (localLists.paymentStatuses?.[0] || 'paid') ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                                  )}>
                                    {payment.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-right">
                                  <div className="flex justify-end gap-2">
                                    {payment.status === (localLists.paymentStatuses?.[1] || 'pending') && (
                                      <button 
                                        onClick={async () => {
                                          if (member && member.email && config) {
                                            const template = config.templates?.reminder || {
                                              subject: "Payment Reminder",
                                              body: `Hello ${member.name},\n\nThis is a friendly reminder that your payment of ${payment.amount} for ${payment.type} subscription is pending.\n\nPlease renew your subscription at your earliest convenience.\n\nBest regards,\nManagement`
                                            };
                                            const subject = template.subject;
                                            const body = template.body
                                              .replace('{name}', member.name)
                                              .replace('{amount}', String(payment.amount))
                                              .replace('{type}', payment.type);

                                            const res = await sendEmail(
                                              member.email,
                                              subject,
                                              body,
                                              'reminder',
                                              currentAdminUid || user.uid,
                                              `<div style="font-family: sans-serif;">${body.replace(/\n/g, '<br>')}</div>`,
                                              config.smtp
                                            );
                                            if (res.success) alert("Reminder sent successfully!");
                                            else alert("Failed to send reminder.");
                                          }
                                        }}
                                        title="Send Reminder"
                                        className="p-2 text-zinc-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                                      >
                                        <Mail size={18} />
                                      </button>
                                    )}
                                    <button 
                                      onClick={() => { setModalType('payment'); setEditingItem(payment); setIsModalOpen(true); }}
                                      className="p-2 text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg transition-all"
                                    >
                                      <Edit2 size={18} />
                                    </button>
                                    <button 
                                      onClick={() => setDeleteConfirm({ type: 'payments', id: payment.id, label: `Payment of ${payment.amount}` })}
                                      className="p-2 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                    >
                                      <Trash2 size={18} />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
                  ) : (
                    <div className="bg-white rounded-3xl border border-zinc-100 shadow-sm overflow-hidden">
                      <div className="p-6 border-b border-zinc-50">
                        <h3 className="font-bold text-zinc-900">Payment History</h3>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="bg-zinc-50/50">
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Date</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Amount</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Type</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Status</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-zinc-50">
                            {payments.sort((a, b) => b.date.localeCompare(a.date)).map(payment => (
                              <tr key={payment.id} className="hover:bg-zinc-50 transition-colors">
                                <td className="px-6 py-4">
                                  <p className="text-sm font-semibold text-zinc-900">{payment.date}</p>
                                </td>
                                <td className="px-6 py-4 font-bold text-zinc-900">
                                  ${payment.amount}
                                </td>
                                <td className="px-6 py-4">
                                  <span className="text-xs font-medium text-zinc-600 bg-zinc-100 px-2 py-1 rounded-full capitalize">
                                    {payment.type}
                                  </span>
                                </td>
                                <td className="px-6 py-4">
                                  <span className={cn(
                                    "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                    payment.status === 'paid' ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                                  )}>
                                    {payment.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                            {payments.length === 0 && (
                              <tr>
                                <td colSpan={4} className="px-6 py-12 text-center text-zinc-500">No payment records found.</td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </motion.div>
              )}

              {activeTab === 'evaluations' && (
                <motion.div
                  key="evaluations"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-6"
                >
                  {renderEvaluations()}
                </motion.div>
              )}

              {activeTab === 'expenses' && (
                <div className="space-y-8">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-3xl font-bold text-zinc-900">Finance</h2>
                      <p className="text-zinc-500">Track all club payables, expenditures, and bank balance.</p>
                    </div>
                    <div className="flex items-center gap-2 bg-white p-1.5 rounded-2xl border border-zinc-100 shadow-sm">
                      <button
                        onClick={() => setExpenseTab('list')}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all",
                          expenseTab === 'list' 
                            ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" 
                            : "text-zinc-500 hover:bg-zinc-50"
                        )}
                      >
                        <Wallet size={16} />
                        Expenses
                      </button>
                      <button
                        onClick={() => setExpenseTab('bank')}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all",
                          expenseTab === 'bank' 
                            ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" 
                            : "text-zinc-500 hover:bg-zinc-50"
                        )}
                      >
                        <CreditCard size={16} />
                        Bank Balance
                      </button>
                    </div>
                    {expenseTab === 'list' && (
                      <button
                        onClick={() => {
                          setModalType('expense');
                          setEditingItem(null);
                          setIsModalOpen(true);
                        }}
                        className="flex items-center justify-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
                      >
                        <Plus size={20} />
                        Add Expense
                      </button>
                    )}
                  </div>

                  {expenseTab === 'list' ? (
                    <>
                      <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} showStatus={false} />

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <StatCard 
                      label="Total Balance" 
                      value={`${stats.currentTotalBalance.toLocaleString()} AED`} 
                      icon={CreditCard} 
                      color="bg-emerald-600" 
                    />
                    <StatCard 
                      label="Total Expenses" 
                      value={`${expenses.reduce((sum, e) => sum + e.amount, 0).toLocaleString()} AED`} 
                      icon={Wallet} 
                      color="bg-rose-500" 
                    />
                    {localLists.expenseCategories.slice(0, 3).map((cat, idx) => (
                      <StatCard 
                        key={cat}
                        label={cat} 
                        value={`${expenses.filter(e => e.category === cat).reduce((sum, e) => sum + e.amount, 0).toLocaleString()} AED`} 
                        icon={[Users, Calendar, CreditCard][idx % 3]} 
                        color={["bg-indigo-500", "bg-amber-500", "bg-emerald-500"][idx % 3]} 
                      />
                    ))}
                  </div>

                  <div className="bg-white rounded-[2.5rem] border border-zinc-100 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-zinc-50/50 border-b border-zinc-100">
                            <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-wider">Date</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-wider">Title</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-wider">Category</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-wider">Amount</th>
                            <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-wider text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-100">
                          {expenses
                            .filter(e => {
                              const matchesSearch = e.title.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                   (e.description?.toLowerCase() || '').includes(globalFilters.search.toLowerCase());
                              const matchesCategory = !globalFilters.status || e.category === globalFilters.status;
                              
                              return matchesSearch && matchesCategory;
                            })
                            .length === 0 ? (
                            <tr>
                              <td colSpan={5} className="px-6 py-12 text-center text-zinc-500">
                                No expenses found matching your filters.
                              </td>
                            </tr>
                          ) : (
                            expenses
                              .filter(e => {
                                const matchesSearch = e.title.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                     (e.description?.toLowerCase() || '').includes(globalFilters.search.toLowerCase());
                                const matchesCategory = !globalFilters.status || e.category === globalFilters.status;
                                return matchesSearch && matchesCategory;
                              })
                              .map((expense) => (
                              <tr key={expense.id} className="hover:bg-zinc-50/50 transition-colors group">
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-zinc-600">
                                  {format(parseISO(expense.date), 'MMM dd, yyyy')}
                                </td>
                                <td className="px-6 py-4">
                                  <div className="text-sm font-bold text-zinc-900">{expense.title}</div>
                                  {expense.description && <div className="text-xs text-zinc-500">{expense.description}</div>}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={cn(
                                    "px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                                    expense.category === 'Coach Salary' ? "bg-indigo-100 text-indigo-700" :
                                    expense.category === 'Purchasing' ? "bg-emerald-100 text-emerald-700" :
                                    expense.category === 'Court Rent' ? "bg-amber-100 text-amber-700" :
                                    "bg-zinc-100 text-zinc-700"
                                  )}>
                                    {expense.category}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-zinc-900">
                                  {expense.amount.toLocaleString()} AED
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right">
                                  <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button
                                      onClick={() => {
                                        setModalType('expense');
                                        setEditingItem(expense);
                                        setIsModalOpen(true);
                                      }}
                                      className="p-2 text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg transition-all"
                                    >
                                      <Edit2 size={16} />
                                    </button>
                                    <button
                                      onClick={() => setDeleteConfirm({ type: 'expenses', id: expense.id, label: expense.title })}
                                      className="p-2 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                    >
                                      <Trash2 size={16} />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              ) : (
                <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm max-w-2xl">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="p-4 bg-emerald-50 rounded-2xl">
                      <CreditCard size={32} className="text-emerald-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-zinc-900">Starting Balances</h3>
                      <p className="text-sm text-zinc-500">Enter your initial bank and cash balances. These will be combined with payments and expenses to show your current balance.</p>
                    </div>
                  </div>

                  <form 
                    onSubmit={async (e) => {
                      e.preventDefault();
                      if (!config?.id) return;
                      setIsSubmitting(true);
                      const formData = new FormData(e.currentTarget);
                      const bankBalance = Number(formData.get('bankBalance'));
                      const cashBalance = Number(formData.get('cashBalance'));
                      
                      try {
                        await updateDoc(doc(db, 'configs', config.id), { 
                          bankBalance,
                          cashBalance
                        });
                        alert("Balances updated successfully!");
                      } catch (err: any) {
                        handleFirestoreError(err, OperationType.UPDATE, 'configs');
                      } finally {
                        setIsSubmitting(false);
                      }
                    }}
                    className="space-y-6"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Initial Bank Balance (AED)</label>
                        <input
                          type="number"
                          name="bankBalance"
                          defaultValue={config?.bankBalance || 0}
                          step="0.01"
                          className="w-full px-6 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 outline-none font-bold text-lg"
                          placeholder="0.00"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Initial Cash Balance (AED)</label>
                        <input
                          type="number"
                          name="cashBalance"
                          defaultValue={config?.cashBalance || 0}
                          step="0.01"
                          className="w-full px-6 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 outline-none font-bold text-lg"
                          placeholder="0.00"
                        />
                      </div>
                    </div>

                    <div className="p-6 bg-zinc-50 rounded-2xl border border-zinc-100 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-zinc-500">Total Initial Balance:</span>
                        <span className="font-bold text-zinc-900">{stats.totalInitialBalance.toLocaleString()} AED</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-zinc-500">Total Revenue (Paid):</span>
                        <span className="font-bold text-emerald-600">+{stats.totalRevenue.toLocaleString()} AED</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-zinc-500">Total Expenses:</span>
                        <span className="font-bold text-rose-600">-{stats.totalExpenses.toLocaleString()} AED</span>
                      </div>
                      <div className="pt-4 border-t border-zinc-200 flex justify-between items-center">
                        <span className="font-bold text-zinc-900">Current Calculated Balance:</span>
                        <span className="text-xl font-black text-zinc-900">{stats.currentTotalBalance.toLocaleString()} AED</span>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 disabled:opacity-50"
                    >
                      {isSubmitting ? "Updating..." : "Update Balances"}
                    </button>
                  </form>
                </div>
              )}
            </div>
          )}

              {activeTab === 'users' && isAdmin && (
                <motion.div
                  key="users"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-bold text-zinc-900">User Management</h3>
                      <p className="text-zinc-500">Manage access for coaches and staff</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                        <input
                          type="text"
                          placeholder="Search users..."
                          value={userSearch}
                          onChange={(e) => setUserSearch(e.target.value)}
                          className="pl-11 pr-4 py-3 bg-white border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 w-64 shadow-sm"
                        />
                      </div>
                      <select
                        value={userRoleFilter}
                        onChange={(e) => setUserRoleFilter(e.target.value)}
                        className="px-4 py-3 bg-white border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 text-sm font-medium shadow-sm"
                      >
                        <option value="">All Roles</option>
                        <option value="admin">Admin</option>
                        <option value="coach">Coach</option>
                        <option value="staff">Staff</option>
                      </select>
                      <select
                        value={userStatusFilter}
                        onChange={(e) => setUserStatusFilter(e.target.value)}
                        className="px-4 py-3 bg-white border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 text-sm font-medium shadow-sm"
                      >
                        <option value="">All Statuses</option>
                        <option value="active">Active</option>
                        <option value="disabled">Disabled</option>
                      </select>
                      <button
                        onClick={() => { setModalType('user'); setEditingItem(null); setIsModalOpen(true); }}
                        className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
                      >
                        <Plus size={20} />
                        Add User
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider mb-1">Total Users</p>
                      <p className="text-2xl font-bold text-zinc-900">{users.length}</p>
                    </div>
                    <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider mb-1">Active</p>
                      <p className="text-2xl font-bold text-emerald-600">{users.filter(u => u.status !== 'disabled').length}</p>
                    </div>
                    <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider mb-1">Admins</p>
                      <p className="text-2xl font-bold text-indigo-600">{users.filter(u => u.role === 'admin').length}</p>
                    </div>
                    <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
                      <p className="text-zinc-500 text-xs font-bold uppercase tracking-wider mb-1">Coaches</p>
                      <p className="text-2xl font-bold text-amber-600">{users.filter(u => u.role === 'coach').length}</p>
                    </div>
                  </div>

                  <div className="bg-white rounded-[2.5rem] border border-zinc-100 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-zinc-50/50">
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">User</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">Contact</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">Role</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">Permissions</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider">Last Login</th>
                            <th className="px-6 py-5 text-xs font-bold text-zinc-500 uppercase tracking-wider text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-zinc-50">
                          {users
                            .filter(u => {
                              const matchesSearch = u.name.toLowerCase().includes(userSearch.toLowerCase()) || 
                                                   u.email.toLowerCase().includes(userSearch.toLowerCase());
                              const matchesRole = !userRoleFilter || u.role === userRoleFilter;
                              const matchesStatus = !userStatusFilter || u.status === userStatusFilter;
                              return matchesSearch && matchesRole && matchesStatus;
                            })
                            .map((u) => (
                            <tr key={u.id} className="hover:bg-zinc-50/50 transition-colors">
                              <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600 font-bold">
                                    {u.name.charAt(0)}
                                  </div>
                                  <div>
                                    <p className="text-sm font-semibold text-zinc-900">{u.name}</p>
                                    <p className="text-xs text-zinc-500">{u.email}</p>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <p className="text-sm text-zinc-900">{u.phone || '—'}</p>
                              </td>
                              <td className="px-6 py-4">
                                <span className={cn(
                                  "px-3 py-1 rounded-full text-xs font-bold capitalize",
                                  u.role === 'admin' ? "bg-indigo-50 text-indigo-600" :
                                  u.role === 'coach' ? "bg-emerald-50 text-emerald-600" :
                                  "bg-zinc-100 text-zinc-600"
                                )}>
                                  {u.role}
                                </span>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex flex-wrap gap-1">
                                  {u.role === 'admin' ? (
                                    <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded uppercase">Full Access</span>
                                  ) : u.permissions && u.permissions.length > 0 ? (
                                    u.permissions.slice(0, 3).map(pId => {
                                      const page = AVAILABLE_PAGES.find(p => p.id === pId);
                                      return page ? (
                                        <div key={pId} title={page.label} className="p-1 bg-zinc-100 rounded text-zinc-500">
                                          <page.icon size={12} />
                                        </div>
                                      ) : null;
                                    }).concat(u.permissions.length > 3 ? [<span key="more" className="text-[10px] font-bold text-zinc-400">+{u.permissions.length - 3}</span>] : [])
                                  ) : (
                                    <span className="text-[10px] font-bold text-zinc-400 bg-zinc-50 px-1.5 py-0.5 rounded uppercase">Role Default</span>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <button
                                  onClick={async () => {
                                    if (u.id === user?.uid) return;
                                    try {
                                      await updateDoc(doc(db, 'users', u.id), {
                                        status: u.status === 'active' ? 'disabled' : 'active'
                                      });
                                    } catch (err) {
                                      console.error("Error toggling status:", err);
                                    }
                                  }}
                                  disabled={u.id === user?.uid}
                                  className={cn(
                                    "px-3 py-1 rounded-full text-xs font-bold capitalize transition-all",
                                    u.status === 'active' 
                                      ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-100" 
                                      : "bg-rose-50 text-rose-600 hover:bg-rose-100",
                                    u.id === user?.uid && "cursor-default opacity-80"
                                  )}
                                >
                                  {u.status || 'active'}
                                </button>
                              </td>
                              <td className="px-6 py-4 text-sm text-zinc-500">
                                {u.lastLogin ? format(parseISO(u.lastLogin), 'MMM d, HH:mm') : 'Never'}
                              </td>
                              <td className="px-6 py-4 text-right">
                                <div className="flex justify-end gap-2">
                                  <button
                                    onClick={() => handleResetPassword(u.email)}
                                    title="Send Password Reset Email"
                                    className="p-2 text-zinc-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  >
                                    <Key size={18} />
                                  </button>
                                  <button
                                    onClick={() => { setEditingItem(u); setModalType('user'); setIsModalOpen(true); }}
                                    className="p-2 text-zinc-400 hover:text-zinc-900 hover:bg-zinc-100 rounded-lg transition-all"
                                  >
                                    <Edit2 size={18} />
                                  </button>
                                  {u.id !== user.uid && (
                                    <button
                                      onClick={() => setDeleteConfirm({ type: 'users', id: u.id, label: u.name })}
                                      className="p-2 text-zinc-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                    >
                                      <Trash2 size={18} />
                                    </button>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'reports' && (
                <motion.div
                  key="reports"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm no-print">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                      <div>
                        <h3 className="text-2xl font-bold text-zinc-900">Reports Center</h3>
                        <p className="text-zinc-500">Generate and export detailed reports</p>
                      </div>
                      <div className="flex flex-wrap gap-2 items-center">
                        {(['members', 'attendance', 'payments', 'expenses', 'evaluations'] as const).map((type) => (
                          <button
                            key={type}
                            onClick={() => setReportType(type)}
                            className={cn(
                              "px-6 py-2.5 rounded-xl font-semibold transition-all capitalize",
                              reportType === type 
                                ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" 
                                : "bg-zinc-50 text-zinc-500 hover:bg-zinc-100"
                            )}
                          >
                            {type}
                          </button>
                        ))}
                        <div className="w-px h-8 bg-zinc-100 mx-2 hidden md:block" />
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => window.print()}
                            className="flex items-center gap-2 px-6 py-2.5 bg-zinc-900 text-white rounded-xl font-semibold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
                          >
                            <Printer size={18} />
                            Print / PDF
                          </button>
                          <button
                            onClick={handleExportExcel}
                            className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                          >
                            <Download size={18} />
                            Excel
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="bg-zinc-50/50 p-6 rounded-3xl border border-zinc-100 mb-8 no-print">
                      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {reportType === 'members' && (
                          <>
                            <div className="md:col-span-2 lg:col-span-2">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Search Member</label>
                              <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                                <input
                                  type="text"
                                  placeholder="Search by name or email..."
                                  value={globalFilters.search}
                                  onChange={(e) => setGlobalFilters({ ...globalFilters, search: e.target.value })}
                                  className="w-full pl-12 pr-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Status</label>
                              <select
                                value={reportMemberStatus}
                                onChange={(e) => setReportMemberStatus(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Statuses</option>
                                {localLists.memberStatuses.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Age Group</label>
                              <select
                                value={reportAgeGroup}
                                onChange={(e) => setReportAgeGroup(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Age Groups</option>
                                {localLists.ageGroups.map(ag => <option key={ag} value={ag}>{ag}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Location</label>
                              <select
                                value={reportLocation}
                                onChange={(e) => setReportLocation(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Locations</option>
                                {localLists.locations.map(l => <option key={l} value={l}>{l}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Level</label>
                              <select
                                value={reportLevel}
                                onChange={(e) => setReportLevel(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Levels</option>
                                {localLists.levels.map(l => <option key={l} value={l}>{l}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Coach</label>
                              <select
                                value={reportCoach}
                                onChange={(e) => setReportCoach(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Coaches</option>
                                {localLists.coaches.map(c => <option key={c} value={c}>{c}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Category</label>
                              <select
                                value={reportMemberCategory}
                                onChange={(e) => setReportMemberCategory(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Categories</option>
                                {localLists.memberCategories.map(c => <option key={c} value={c}>{c}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Birthday</label>
                              <input
                                type="date"
                                value={reportBirthday}
                                onChange={(e) => setReportBirthday(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Year of Birthday</label>
                              <input
                                type="number"
                                placeholder="e.g. 2010"
                                value={reportBirthdayYear}
                                onChange={(e) => setReportBirthdayYear(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Nationality</label>
                              <input
                                type="text"
                                placeholder="Filter by nationality"
                                value={reportNationality}
                                onChange={(e) => setReportNationality(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                          </>
                        )}
                        {reportType === 'attendance' && (
                          <>
                            <div className="md:col-span-2 lg:col-span-2">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Search Member</label>
                              <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                                <input
                                  type="text"
                                  placeholder="Search by name or email..."
                                  value={globalFilters.search}
                                  onChange={(e) => setGlobalFilters({ ...globalFilters, search: e.target.value })}
                                  className="w-full pl-12 pr-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Select Date</label>
                              <input
                                type="date"
                                value={reportDate}
                                onChange={(e) => setReportDate(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Status</label>
                              <select
                                value={reportAttendanceStatus}
                                onChange={(e) => setReportAttendanceStatus(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Statuses</option>
                                <option value="present">Present</option>
                                <option value="absent">Absent</option>
                              </select>
                            </div>
                          </>
                        )}
                        {reportType === 'payments' && (
                          <>
                            <div className="md:col-span-2 lg:col-span-2">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Search Member</label>
                              <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                                <input
                                  type="text"
                                  placeholder="Search by name or email..."
                                  value={globalFilters.search}
                                  onChange={(e) => setGlobalFilters({ ...globalFilters, search: e.target.value })}
                                  className="w-full pl-12 pr-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Filter by Member</label>
                              <select
                                value={reportMemberId}
                                onChange={(e) => setReportMemberId(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Members</option>
                                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Filter by Status</label>
                              <select
                                value={reportPaymentStatus}
                                onChange={(e) => setReportPaymentStatus(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Statuses</option>
                                {localLists.paymentStatuses.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                              </select>
                            </div>
                          </>
                        )}
                        {reportType === 'expenses' && (
                          <>
                            <div className="md:col-span-full">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Search Expenses</label>
                              <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                                <input
                                  type="text"
                                  placeholder="Search by title or description..."
                                  value={globalFilters.search}
                                  onChange={(e) => setGlobalFilters({ ...globalFilters, search: e.target.value })}
                                  className="w-full pl-12 pr-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Start Date</label>
                              <input
                                type="date"
                                value={reportDateRange.start}
                                onChange={(e) => setReportDateRange(prev => ({ ...prev, start: e.target.value }))}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">End Date</label>
                              <input
                                type="date"
                                value={reportDateRange.end}
                                onChange={(e) => setReportDateRange(prev => ({ ...prev, end: e.target.value }))}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Category</label>
                              <select
                                value={reportCategory}
                                onChange={(e) => setReportCategory(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="all">All Categories</option>
                                {localLists.expenseCategories.map(cat => (
                                  <option key={cat} value={cat}>{cat}</option>
                                ))}
                              </select>
                            </div>
                          </>
                        )}
                        {reportType === 'evaluations' && (
                          <>
                            <div className="md:col-span-2 lg:col-span-2">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Search Member</label>
                              <div className="relative">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                                <input
                                  type="text"
                                  placeholder="Search by name or email..."
                                  value={globalFilters.search}
                                  onChange={(e) => setGlobalFilters({ ...globalFilters, search: e.target.value })}
                                  className="w-full pl-12 pr-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Filter by Member</label>
                              <select
                                value={reportMemberId}
                                onChange={(e) => setReportMemberId(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Members</option>
                                {members.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                              </select>
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Start Date</label>
                              <input
                                type="date"
                                value={reportDateRange.start}
                                onChange={(e) => setReportDateRange(prev => ({ ...prev, start: e.target.value }))}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">End Date</label>
                              <input
                                type="date"
                                value={reportDateRange.end}
                                onChange={(e) => setReportDateRange(prev => ({ ...prev, end: e.target.value }))}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Status</label>
                              <select
                                value={reportEvaluationStatus}
                                onChange={(e) => setReportEvaluationStatus(e.target.value)}
                                className="w-full px-4 py-3 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              >
                                <option value="">All Statuses</option>
                                <option value="pending">Pending</option>
                                <option value="approved">Approved</option>
                              </select>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                    <div id="printable-report" className="bg-white rounded-[2.5rem] overflow-hidden border border-zinc-100 shadow-sm">
                      <div className="hidden print:block text-center py-10 border-b border-zinc-100 mb-8">
                        <h1 className="text-4xl font-bold text-zinc-900 tracking-tight">Club Manager Report</h1>
                        <p className="text-zinc-500 mt-2">Professional Directory & Management System</p>
                      </div>
                      {reportType === 'members' && (
                        <div className="p-6 space-y-8">
                          <div className="text-center pb-8 border-b border-zinc-100">
                            <h2 className="text-3xl font-bold text-zinc-900">Members Directory Report</h2>
                            <p className="text-zinc-500">Generated on {format(new Date(), 'PPP')}</p>
                          </div>
                          <div className="grid grid-cols-1 gap-8">
                            {members
                              .filter(member => {
                                const matchesSearch = !globalFilters.search || 
                                                     member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                     member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                                if (!matchesSearch) return false;
                                if (reportMemberStatus && member.status !== reportMemberStatus) return false;
                                if (reportAgeGroup && member.ageGroup !== reportAgeGroup) return false;
                                if (reportLocation && member.location !== reportLocation) return false;
                                if (reportLevel && member.level !== reportLevel) return false;
                                if (reportCoach && member.coach !== reportCoach) return false;
                                if (reportMemberCategory && member.category !== reportMemberCategory) return false;
                                if (reportBirthday && member.birthday !== reportBirthday) return false;
                                if (reportBirthdayYear && member.birthday && !member.birthday.startsWith(reportBirthdayYear)) return false;
                                if (reportNationality && member.nationality && !member.nationality.toLowerCase().includes(reportNationality.toLowerCase())) return false;
                                return true;
                              })
                              .map(member => (
                              <div key={member.id} className="p-6 border border-zinc-100 rounded-3xl flex flex-col md:flex-row gap-8 break-inside-avoid">
                                <div className="flex-shrink-0 space-y-4">
                                  <div className="w-40 h-40 bg-zinc-100 rounded-3xl overflow-hidden border border-zinc-100">
                                    {member.profileImage ? (
                                      <img src={member.profileImage} alt={member.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center text-zinc-400">
                                        <UserIcon size={64} />
                                      </div>
                                    )}
                                  </div>
                                  <div className="w-40 h-24 bg-zinc-100 rounded-2xl overflow-hidden border border-zinc-100">
                                    {member.idImage ? (
                                      <img src={member.idImage} alt="ID" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center text-zinc-400 text-[10px] font-bold uppercase">
                                        No ID Image
                                      </div>
                                    )}
                                  </div>
                                </div>
                                <div className="flex-grow grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                  <div className="col-span-full">
                                    <h4 className="text-xl font-bold text-zinc-900">{member.name}</h4>
                                    {member.nameArabic && <p className="text-lg text-zinc-500 font-arabic">{member.nameArabic}</p>}
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Email</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.email}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Phone</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.phone || '-'}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Nationality</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.nationality || '-'}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Birthday</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.birthday || '-'}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Emirates ID</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.emiratesId || '-'}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Category</p>
                                    <p className="text-sm font-medium text-zinc-900">{member.category}</p>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Status</p>
                                    <span className={cn(
                                      "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                      member.status === (localLists.memberStatuses?.[0] || 'active') ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-500"
                                    )}>
                                      {member.status}
                                    </span>
                                  </div>
                                  <div>
                                    <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Joined At</p>
                                    <p className="text-sm font-medium text-zinc-900">{format(new Date(member.joinedAt), 'PP')}</p>
                                  </div>
                                  {member.location && (
                                    <div>
                                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Location</p>
                                      <p className="text-sm font-medium text-zinc-900">{member.location}</p>
                                    </div>
                                  )}
                                  {member.ageGroup && (
                                    <div>
                                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Age Group</p>
                                      <p className="text-sm font-medium text-zinc-900">{member.ageGroup}</p>
                                    </div>
                                  )}
                                  {member.level && (
                                    <div>
                                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Level</p>
                                      <p className="text-sm font-medium text-zinc-900">{member.level}</p>
                                    </div>
                                  )}
                                  {member.coach && (
                                    <div>
                                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Coach</p>
                                      <p className="text-sm font-medium text-zinc-900">{member.coach}</p>
                                    </div>
                                  )}
                                  {member.activity && (
                                    <div>
                                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Activity</p>
                                      <p className="text-sm font-medium text-zinc-900">{member.activity}</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {reportType === 'attendance' && (
                        <div className="p-6 space-y-8">
                          <div className="text-center pb-8 border-b border-zinc-100">
                            <h2 className="text-3xl font-bold text-zinc-900">Attendance Report</h2>
                            <p className="text-zinc-500">Date: {format(new Date(reportDate), 'PPPP')}</p>
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="bg-zinc-50 border-b border-zinc-100">
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Member</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Time Recorded</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-50">
                                {members
                                  .filter(member => {
                                    const matchesSearch = !globalFilters.search || 
                                                         member.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                         member.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                                    if (!matchesSearch) return false;
                                    const record = attendance.find(a => a.memberId === member.id && a.date === reportDate);
                                    if (reportAttendanceStatus) {
                                      if (reportAttendanceStatus === 'present') return record?.status === 'present';
                                      if (reportAttendanceStatus === 'absent') return record?.status === 'absent';
                                    }
                                    return true;
                                  })
                                  .map(member => {
                                    const record = attendance.find(a => a.memberId === member.id && a.date === reportDate);
                                    return (
                                    <tr key={member.id} className="hover:bg-zinc-50/50 transition-colors">
                                      <td className="px-6 py-4">
                                        <div className="flex items-center gap-3">
                                          <div className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-600 text-xs font-bold">
                                            {member.name.charAt(0)}
                                          </div>
                                          <span className="font-semibold text-zinc-900">{member.name}</span>
                                        </div>
                                      </td>
                                      <td className="px-6 py-4">
                                        {record ? (
                                          <span className={cn(
                                            "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                            record.status === 'present' ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
                                          )}>
                                            {record.status}
                                          </span>
                                        ) : (
                                          <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full bg-zinc-100 text-zinc-400">
                                            Not Recorded
                                          </span>
                                        )}
                                      </td>
                                      <td className="px-6 py-4 text-sm text-zinc-500">
                                        {record ? "Recorded" : "-"}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}

                      {reportType === 'payments' && (
                        <div className="p-6 space-y-8">
                          <div className="text-center pb-8 border-b border-zinc-100">
                            <h2 className="text-3xl font-bold text-zinc-900">Payments Report</h2>
                            <p className="text-zinc-500">
                              {reportMemberId ? `Member: ${members.find(m => m.id === reportMemberId)?.name}` : 'All Members'}
                              {reportPaymentStatus ? ` | Status: ${reportPaymentStatus}` : ''}
                            </p>
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="bg-zinc-50 border-b border-zinc-100">
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Member</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Amount</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Date</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Period</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Type</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-50">
                                {payments
                                  .filter(p => {
                                    const member = members.find(m => m.id === p.memberId);
                                    const matchesSearch = !globalFilters.search || 
                                                         (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                                                         (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
                                    return matchesSearch && (!reportMemberId || p.memberId === reportMemberId) && (!reportPaymentStatus || p.status === reportPaymentStatus);
                                  })
                                  .map(payment => {
                                    const member = members.find(m => m.id === payment.memberId);
                                    return (
                                      <tr key={payment.id} className="hover:bg-zinc-50/50 transition-colors">
                                        <td className="px-6 py-4">
                                          <span className="font-semibold text-zinc-900">{member?.name || 'Unknown'}</span>
                                        </td>
                                        <td className="px-6 py-4 font-bold text-zinc-900">
                                          ${payment.amount}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-zinc-500">
                                          {payment.date}
                                        </td>
                                        <td className="px-6 py-4 text-xs text-zinc-500">
                                          {payment.startDate && payment.endDate ? `${payment.startDate} to ${payment.endDate}` : '-'}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-zinc-500 capitalize">
                                          {payment.type}
                                        </td>
                                        <td className="px-6 py-4">
                                          <span className={cn(
                                            "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                            payment.status === (localLists.paymentStatuses?.[0] || 'paid') ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                                          )}>
                                            {payment.status}
                                          </span>
                                        </td>
                                      </tr>
                                    );
                                  })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                      {reportType === 'expenses' && (
                        <div className="p-6 space-y-8">
                          <div className="text-center pb-8 border-b border-zinc-100">
                            <h2 className="text-3xl font-bold text-zinc-900">Expenses Report</h2>
                            <p className="text-zinc-500">
                              Period: {reportDateRange.start} to {reportDateRange.end}
                              {reportCategory !== 'all' ? ` | Category: ${reportCategory}` : ''}
                            </p>
                            <div className="mt-4 inline-block px-6 py-2 bg-rose-50 rounded-2xl border border-rose-100">
                              <span className="text-xs font-bold text-rose-400 uppercase tracking-widest block mb-1">Total Expenses</span>
                              <span className="text-2xl font-black text-rose-600">
                                {expenses
                                  .filter(e => {
                                    const date = e.date;
                                    const inRange = date >= reportDateRange.start && date <= reportDateRange.end;
                                    const matchesSearch = !globalFilters.search || 
                                                         e.title.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                         (e.description?.toLowerCase() || '').includes(globalFilters.search.toLowerCase());
                                    const categoryMatch = reportCategory === 'all' || e.category === reportCategory;
                                    return inRange && categoryMatch && matchesSearch;
                                  })
                                  .reduce((sum, e) => sum + e.amount, 0)
                                  .toLocaleString()} AED
                              </span>
                            </div>
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-left">
                              <thead>
                                <tr className="bg-zinc-50 border-b border-zinc-100">
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Date</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Title</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Category</th>
                                  <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Amount</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-zinc-50">
                                {expenses
                                  .filter(e => {
                                    const date = e.date;
                                    const inRange = date >= reportDateRange.start && date <= reportDateRange.end;
                                    const matchesSearch = !globalFilters.search || 
                                                         e.title.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                         (e.description?.toLowerCase() || '').includes(globalFilters.search.toLowerCase());
                                    const categoryMatch = reportCategory === 'all' || e.category === reportCategory;
                                    return inRange && categoryMatch && matchesSearch;
                                  })
                                  .sort((a, b) => b.date.localeCompare(a.date))
                                  .map(expense => (
                                    <tr key={expense.id} className="hover:bg-zinc-50/50 transition-colors">
                                      <td className="px-6 py-4 text-sm text-zinc-600">
                                        {format(parseISO(expense.date), 'MMM dd, yyyy')}
                                      </td>
                                      <td className="px-6 py-4">
                                        <div className="text-sm font-bold text-zinc-900">{expense.title}</div>
                                        {expense.description && <div className="text-xs text-zinc-500">{expense.description}</div>}
                                      </td>
                                      <td className="px-6 py-4">
                                        <span className="text-xs font-medium text-zinc-500">{expense.category}</span>
                                      </td>
                                      <td className="px-6 py-4 font-bold text-zinc-900">
                                        {expense.amount.toLocaleString()} AED
                                      </td>
                                    </tr>
                                  ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                        {reportType === 'evaluations' && (
                          <div className="p-6 space-y-8">
                            <div className="text-center pb-8 border-b border-zinc-100">
                              <h2 className="text-3xl font-bold text-zinc-900">Evaluations Report</h2>
                              <p className="text-zinc-500">
                                Period: {reportDateRange.start} to {reportDateRange.end}
                                {reportEvaluationStatus ? ` | Status: ${reportEvaluationStatus}` : ''}
                              </p>
                              <div className="mt-4 flex justify-center gap-4">
                                <div className="px-6 py-2 bg-zinc-50 rounded-2xl border border-zinc-100">
                                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-1">Total Evaluations</span>
                                  <span className="text-2xl font-black text-zinc-900">
                                    {evaluations
                                      .filter(e => {
                                        const member = members.find(m => m.id === e.memberId);
                                        const matchesSearch = !globalFilters.search || 
                                                             (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                                                             (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
                                        const inRange = e.date >= reportDateRange.start && e.date <= reportDateRange.end;
                                        const statusMatch = !reportEvaluationStatus || e.status === reportEvaluationStatus;
                                        const memberMatch = !reportMemberId || e.memberId === reportMemberId;
                                        return matchesSearch && inRange && statusMatch && memberMatch;
                                      }).length}
                                  </span>
                                </div>
                                <div className="px-6 py-2 bg-emerald-50 rounded-2xl border border-emerald-100">
                                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest block mb-1">Approved</span>
                                  <span className="text-2xl font-black text-emerald-600">
                                    {evaluations
                                      .filter(e => {
                                        const member = members.find(m => m.id === e.memberId);
                                        const matchesSearch = !globalFilters.search || 
                                                             (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                                                             (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
                                        const inRange = e.date >= reportDateRange.start && e.date <= reportDateRange.end;
                                        const statusMatch = !reportEvaluationStatus || e.status === reportEvaluationStatus;
                                        const memberMatch = !reportMemberId || e.memberId === reportMemberId;
                                        return matchesSearch && inRange && statusMatch && memberMatch && e.status === 'approved';
                                      }).length}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="overflow-x-auto">
                              <table className="w-full text-left">
                                <thead>
                                  <tr className="bg-zinc-50 border-b border-zinc-100">
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Date</th>
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Member</th>
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Coach</th>
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Status</th>
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Scores</th>
                                    <th className="px-6 py-4 text-xs font-bold text-zinc-500 uppercase tracking-wider">Notes</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-zinc-50">
                                  {evaluations
                                    .filter(e => {
                                      const member = members.find(m => m.id === e.memberId);
                                      const matchesSearch = !globalFilters.search || 
                                                           (member?.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || false) ||
                                                           (member?.email.toLowerCase().includes(globalFilters.search.toLowerCase()) || false);
                                      const inRange = e.date >= reportDateRange.start && e.date <= reportDateRange.end;
                                      const statusMatch = !reportEvaluationStatus || e.status === reportEvaluationStatus;
                                      const memberMatch = !reportMemberId || e.memberId === reportMemberId;
                                      return matchesSearch && inRange && statusMatch && memberMatch;
                                    })
                                    .sort((a, b) => b.date.localeCompare(a.date))
                                    .map(evaluation => {
                                      const member = members.find(m => m.id === evaluation.memberId);
                                      const coach = users.find(u => u.id === evaluation.coachId);
                                      return (
                                        <tr key={evaluation.id} className="hover:bg-zinc-50/50 transition-colors">
                                          <td className="px-6 py-4 text-sm text-zinc-600">
                                            {format(parseISO(evaluation.date), 'MMM dd, yyyy')}
                                          </td>
                                          <td className="px-6 py-4">
                                            <div className="text-sm font-bold text-zinc-900">{member?.name || 'Unknown'}</div>
                                            <div className="text-xs text-zinc-500">{member?.email}</div>
                                          </td>
                                          <td className="px-6 py-4 text-sm text-zinc-600">
                                            {coach?.name || 'Unknown'}
                                          </td>
                                          <td className="px-6 py-4">
                                            <span className={cn(
                                              "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                                              evaluation.status === 'approved' ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"
                                            )}>
                                              {evaluation.status}
                                            </span>
                                          </td>
                                          <td className="px-6 py-4">
                                            <div className="flex flex-wrap gap-1">
                                              {Object.entries(evaluation.scores).map(([skillId, score]) => {
                                                const skill = config?.evaluationSettings?.categories
                                                  .flatMap(c => c.skills)
                                                  .find(s => s.id === skillId);
                                                return (
                                                  <span key={skillId} className="px-1.5 py-0.5 bg-zinc-100 text-zinc-600 rounded text-[10px] font-medium">
                                                    {skill?.name || skillId}: {score}
                                                  </span>
                                                );
                                              })}
                                            </div>
                                          </td>
                                          <td className="px-6 py-4 text-xs text-zinc-500 max-w-xs truncate">
                                            {evaluation.notes}
                                          </td>
                                        </tr>
                                      );
                                    })}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      <div className="hidden print:block text-center py-8 border-t border-zinc-100 mt-12">
                        <p className="text-xs text-zinc-400 uppercase tracking-widest">End of Report | Club Manager System</p>
                      </div>
                    </div>
                </motion.div>
              )}

              {activeTab === 'requests' && (
                <motion.div
                  key="requests"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col gap-6 bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex flex-col gap-4">
                        <div>
                          <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">Requests Management</h2>
                          <p className="text-zinc-500 mt-1">Manage new member applications and trial session bookings</p>
                        </div>
                        <div className="flex p-1 bg-zinc-100 rounded-2xl w-fit">
                          <button
                            onClick={() => setRequestTab('registration')}
                            className={cn(
                              "px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all",
                              requestTab === 'registration' ? "bg-white text-zinc-900 shadow-sm" : "text-zinc-500 hover:text-zinc-700"
                            )}
                          >
                            Registration
                          </button>
                          <button
                            onClick={() => setRequestTab('trial')}
                            className={cn(
                              "px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all",
                              requestTab === 'trial' ? "bg-white text-zinc-900 shadow-sm" : "text-zinc-500 hover:text-zinc-700"
                            )}
                          >
                            Trial Sessions
                          </button>
                        </div>
                      </div>
                      {requestTab === 'registration' && (
                        <div className="flex gap-3">
                          <button
                            onClick={async () => {
                            try {
                              const baseUrl = window.location.origin + window.location.pathname;
                              const cleanUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
                              const url = `${cleanUrl}?register=true&admin=${user?.uid}`;
                              await navigator.clipboard.writeText(url);
                              alert("Registration link copied to clipboard!");
                            } catch (err) {
                              // Fallback
                              const baseUrl = window.location.origin + window.location.pathname;
                              const cleanUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
                              const url = `${cleanUrl}?register=true&admin=${user?.uid}`;
                              const textArea = document.createElement("textarea");
                              textArea.value = url;
                              document.body.appendChild(textArea);
                              textArea.select();
                              try {
                                document.execCommand('copy');
                                alert("Registration link copied to clipboard!");
                              } catch (copyErr) {
                                console.error('Fallback copy failed', copyErr);
                                prompt("Copy the registration link below:", url);
                              }
                              document.body.removeChild(textArea);
                            }
                          }}
                            className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200"
                          >
                            <Share2 size={20} />
                            Share Link
                          </button>
                        </div>
                      )}
                    </div>

                    <FilterBar filters={globalFilters} setFilters={setGlobalFilters} config={config} activeTab={activeTab} />
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                    {requestTab === 'registration' ? (
                      registrationRequests.length === 0 ? (
                        <div className="bg-white p-12 rounded-[2.5rem] border border-zinc-100 text-center">
                          <PlusCircle className="mx-auto text-zinc-200 mb-4" size={64} />
                          <h3 className="text-xl font-bold text-zinc-900 mb-2">No Registration Requests</h3>
                          <p className="text-zinc-500">Share your registration link to start receiving applications.</p>
                        </div>
                      ) : (
                        registrationRequests
                          .filter(r => {
                            const matchesSearch = r.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                                 r.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                            const matchesCoach = !globalFilters.coach || r.coach === globalFilters.coach;
                            const matchesLocation = !globalFilters.location || r.location === globalFilters.location;
                            const matchesAgeGroup = !globalFilters.ageGroup || r.ageGroup === globalFilters.ageGroup;
                            const matchesStatus = !globalFilters.status || r.status === globalFilters.status;
                            return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                          })
                          .map(request => (
                        <motion.div
                          key={request.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm hover:shadow-md transition-all group"
                        >
                          <div className="flex flex-col md:flex-row justify-between gap-6">
                            <div className="space-y-4 flex-grow">
                              <div className="flex items-center gap-4">
                                {request.profileImage ? (
                                  <img 
                                    src={request.profileImage} 
                                    alt={request.name} 
                                    className="w-16 h-16 rounded-2xl object-cover border-2 border-zinc-100 shadow-sm cursor-pointer hover:scale-105 transition-transform"
                                    onClick={() => setPreviewImage(request.profileImage)}
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400">
                                    <UserIcon size={32} />
                                  </div>
                                )}
                                <div>
                                  <div className="flex items-center gap-3">
                                    <h3 className="text-xl font-bold text-zinc-900">{request.name}</h3>
                                    {request.nameArabic && <span className="text-lg text-zinc-400 font-arabic">{request.nameArabic}</span>}
                                    <span className={cn(
                                      "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                      request.status === 'pending' ? "bg-amber-50 text-amber-600" :
                                      request.status === 'approved' ? "bg-emerald-50 text-emerald-600" :
                                      "bg-rose-50 text-rose-600"
                                    )}>
                                      {request.status}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2 mt-1">
                                    {request.idImage && (
                                      <button
                                        onClick={() => {
                                          if (request.idImage?.startsWith('data:application/pdf')) {
                                            const win = window.open();
                                            win?.document.write(`<iframe src="${request.idImage}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
                                          } else {
                                            setPreviewImage(request.idImage);
                                          }
                                        }}
                                        className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-blue-100 transition-colors"
                                      >
                                        <FileText size={12} />
                                        View ID Document
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-12 gap-y-4">
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Email</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.email}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Phone / WhatsApp</p>
                                  <p className="text-sm font-medium text-zinc-900">
                                    {request.phone || '-'}
                                    {request.whatsapp && <span className="text-emerald-500 ml-2">(WA: {request.whatsapp})</span>}
                                  </p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Birthday</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.birthday || '-'}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Requested At</p>
                                  <p className="text-sm font-medium text-zinc-900">{format(new Date(request.requestedAt), 'PPp')}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Location</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.location || '-'}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Age Group</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.ageGroup || '-'}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Activity</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.activity || '-'}</p>
                                </div>
                              </div>
                              {request.parentsInformation && (
                                <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100">
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Parents Information</p>
                                  <p className="text-sm text-zinc-600">{request.parentsInformation}</p>
                                </div>
                              )}
                              {request.notes && (
                                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
                                  <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest mb-1">Admin Notes</p>
                                  <p className="text-sm text-amber-700">{request.notes}</p>
                                </div>
                              )}
                            </div>
                              <div className="flex flex-col gap-3 justify-center min-w-[140px]">
                                <button
                                  onClick={() => {
                                    setModalType('registration_request' as any);
                                    setEditingItem(request);
                                    setIsModalOpen(true);
                                  }}
                                  className="flex items-center justify-center gap-2 px-6 py-3 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                                >
                                  <Edit2 size={20} />
                                  Edit
                                </button>
                                {request.status === 'pending' && (
                                  <>
                                    <button
                                      onClick={() => handleApproveRequest(request)}
                                      className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                                    >
                                      <Check size={20} />
                                      Approve
                                    </button>
                                    <button
                                      onClick={() => handleRejectRequest(request.id)}
                                      className="flex items-center justify-center gap-2 px-6 py-3 bg-rose-50 text-rose-600 rounded-2xl font-bold hover:bg-rose-100 transition-all"
                                    >
                                      <X size={20} />
                                      Reject
                                    </button>
                                  </>
                                )}
                                <button
                                  onClick={() => setDeleteConfirm({ type: 'registration_requests', id: request.id, label: `Request from ${request.name}` })}
                                  className="flex items-center justify-center gap-2 px-6 py-2 text-zinc-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all text-xs font-bold uppercase tracking-wider"
                                >
                                  <Trash2 size={16} />
                                  Delete
                                </button>
                              </div>
                            </div>
                          </motion.div>
                      ))
                    )
                  ) : (
                    trialRequests.length === 0 ? (
                      <div className="bg-white p-12 rounded-[2.5rem] border border-zinc-100 text-center">
                        <PlusCircle className="mx-auto text-zinc-200 mb-4" size={64} />
                        <h3 className="text-xl font-bold text-zinc-900 mb-2">No Trial Requests Yet</h3>
                        <p className="text-zinc-500">Trial requests from the public page will appear here.</p>
                      </div>
                    ) : (
                      trialRequests
                        .filter(r => {
                          const matchesSearch = r.name.toLowerCase().includes(globalFilters.search.toLowerCase()) ||
                                               r.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                          const matchesLocation = !globalFilters.location || r.location === globalFilters.location;
                          const matchesStatus = !globalFilters.status || r.status === globalFilters.status;
                          return matchesSearch && matchesLocation && matchesStatus;
                        })
                        .map(request => (
                        <motion.div
                          key={request.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm hover:shadow-md transition-all group"
                        >
                          <div className="flex flex-col md:flex-row justify-between gap-6">
                            <div className="space-y-4 flex-grow">
                              <div className="flex items-center gap-4">
                                {request.profileImage ? (
                                  <img 
                                    src={request.profileImage} 
                                    alt={request.name} 
                                    className="w-16 h-16 rounded-2xl object-cover border-2 border-zinc-100 shadow-sm cursor-pointer hover:scale-105 transition-transform"
                                    onClick={() => setPreviewImage(request.profileImage)}
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <div className="w-16 h-16 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400">
                                    <UserIcon size={32} />
                                  </div>
                                )}
                                <div>
                                  <div className="flex items-center gap-3">
                                    <h3 className="text-xl font-bold text-zinc-900">{request.name}</h3>
                                    <span className={cn(
                                      "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full",
                                      request.status === 'pending' ? "bg-amber-50 text-amber-600" :
                                      request.status === 'approved' ? "bg-emerald-50 text-emerald-600" :
                                      "bg-rose-50 text-rose-600"
                                    )}>
                                      {request.status}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2 mt-1">
                                    {request.idImage && (
                                      <button
                                        onClick={() => {
                                          if (request.idImage?.startsWith('data:application/pdf')) {
                                            const win = window.open();
                                            win?.document.write(`<iframe src="${request.idImage}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
                                          } else {
                                            setPreviewImage(request.idImage);
                                          }
                                        }}
                                        className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-blue-100 transition-colors"
                                      >
                                        <FileText size={12} />
                                        View ID Document
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-12 gap-y-4">
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Email</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.email}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Phone</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.phone}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Activity</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.activity}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Location</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.location || '-'}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Preferred Date</p>
                                  <p className="text-sm font-medium text-zinc-900">{request.preferredDate}</p>
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Requested At</p>
                                  <p className="text-sm font-medium text-zinc-900">{format(new Date(request.requestedAt), 'PPp')}</p>
                                </div>
                              </div>
                              {request.notes && (
                                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100">
                                  <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest mb-1">Admin Notes</p>
                                  <p className="text-sm text-amber-700">{request.notes}</p>
                                </div>
                              )}
                            </div>
                            <div className="flex flex-col gap-3 justify-center min-w-[140px]">
                              <button
                                onClick={() => {
                                  setModalType('trial_request' as any);
                                  setEditingItem(request);
                                  setIsModalOpen(true);
                                }}
                                className="flex items-center justify-center gap-2 px-6 py-3 bg-zinc-100 text-zinc-600 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                              >
                                <Edit2 size={20} />
                                Edit
                              </button>
                              {request.status === 'pending' && (
                                <>
                                  <button
                                    onClick={() => handleApproveTrialRequest(request)}
                                    className="flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
                                  >
                                    <Check size={20} />
                                    Approve
                                  </button>
                                  <button
                                    onClick={() => handleRejectTrialRequest(request)}
                                    className="flex items-center justify-center gap-2 px-6 py-3 bg-rose-50 text-rose-600 rounded-2xl font-bold hover:bg-rose-100 transition-all"
                                  >
                                    <X size={20} />
                                    Reject
                                  </button>
                                </>
                              )}
                              <button
                                onClick={() => setDeleteConfirm({ type: 'trial_requests', id: request.id, label: `Trial from ${request.name}` })}
                                className="flex items-center justify-center gap-2 px-6 py-2 text-zinc-400 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all text-xs font-bold uppercase tracking-wider"
                              >
                                <Trash2 size={16} />
                                Delete
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))
                    )
                  )}
                </div>
              </motion.div>
            )}

              {activeTab === 'bulk_email' && (
                <motion.div
                  key="bulk_email"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col gap-6 bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm">
                    <div>
                      <h2 className="text-3xl font-bold text-zinc-900 tracking-tight">Bulk Email</h2>
                      <p className="text-zinc-500 mt-1">Send customized emails to selected members</p>
                    </div>

                    <FilterBar 
                      filters={globalFilters} 
                      setFilters={setGlobalFilters} 
                      config={config} 
                      activeTab="members" 
                    />

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      {/* Member Selection */}
                      <div className="lg:col-span-1 space-y-4">
                        <div className="flex items-center justify-between">
                          <h3 className="text-lg font-bold text-zinc-900">Select Members</h3>
                          <div className="flex gap-2">
                            <button 
                              onClick={() => {
                                const filtered = members.filter(m => {
                                  const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || 
                                                       m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                                  const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
                                  const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
                                  const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
                                  const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
                                  return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                                });
                                setSelectedBulkMemberIds(new Set(filtered.map(m => m.id)));
                              }}
                              className="text-xs font-bold text-zinc-900 hover:underline"
                            >
                              Select All Filtered
                            </button>
                            <button 
                              onClick={() => setSelectedBulkMemberIds(new Set())}
                              className="text-xs font-bold text-rose-600 hover:underline"
                            >
                              Clear
                            </button>
                          </div>
                        </div>
                        <div className="bg-zinc-50 rounded-2xl border border-zinc-100 overflow-hidden max-h-[500px] overflow-y-auto custom-scrollbar">
                          {members
                            .filter(m => {
                              const matchesSearch = m.name.toLowerCase().includes(globalFilters.search.toLowerCase()) || 
                                                   m.email.toLowerCase().includes(globalFilters.search.toLowerCase());
                              const matchesCoach = !globalFilters.coach || m.coach === globalFilters.coach;
                              const matchesLocation = !globalFilters.location || m.location === globalFilters.location;
                              const matchesAgeGroup = !globalFilters.ageGroup || m.ageGroup === globalFilters.ageGroup;
                              const matchesStatus = !globalFilters.status || m.status === globalFilters.status;
                              return matchesSearch && matchesCoach && matchesLocation && matchesAgeGroup && matchesStatus;
                            })
                            .map(member => (
                              <label 
                                key={member.id} 
                                className="flex items-center gap-3 p-4 hover:bg-white transition-colors cursor-pointer border-b border-zinc-100 last:border-0"
                              >
                                <input 
                                  type="checkbox"
                                  checked={selectedBulkMemberIds.has(member.id)}
                                  onChange={(e) => {
                                    const next = new Set(selectedBulkMemberIds);
                                    if (e.target.checked) next.add(member.id);
                                    else next.delete(member.id);
                                    setSelectedBulkMemberIds(next);
                                  }}
                                  className="w-5 h-5 rounded-lg border-zinc-200 text-zinc-900 focus:ring-zinc-900/10"
                                />
                                <div className="min-w-0">
                                  <p className="text-sm font-bold text-zinc-900 truncate">{member.name}</p>
                                  <p className="text-xs text-zinc-500 truncate">{member.email}</p>
                                </div>
                              </label>
                            ))}
                        </div>
                        <p className="text-xs text-zinc-500">
                          {selectedBulkMemberIds.size} members selected
                        </p>
                      </div>

                      {/* Email Composition */}
                      <div className="lg:col-span-2 space-y-6">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-bold text-zinc-900">Compose Email</h3>
                            <select 
                              onChange={(e) => {
                                const templateKey = e.target.value;
                                if (templateKey && config?.templates?.[templateKey as keyof typeof config.templates]) {
                                  const t = config.templates[templateKey as keyof typeof config.templates];
                                  setBulkEmailSubject(t.subject);
                                  setBulkEmailBody(t.body);
                                }
                              }}
                              className="text-sm bg-zinc-50 border-zinc-100 rounded-xl px-3 py-1.5 outline-none focus:ring-2 focus:ring-zinc-900/10"
                            >
                              <option value="">Load Template...</option>
                              {config?.templates && Object.entries(config.templates).map(([key, t]) => (
                                <option key={key} value={key}>{key.charAt(0).toUpperCase() + key.slice(1)}</option>
                              ))}
                            </select>
                          </div>

                          <div className="space-y-2">
                            <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Subject</label>
                            <input 
                              type="text"
                              value={bulkEmailSubject}
                              onChange={(e) => setBulkEmailSubject(e.target.value)}
                              placeholder="Enter email subject"
                              className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 outline-none"
                            />
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Message Body</label>
                              <div className="flex gap-2">
                                {['{{name}}', '{{email}}', '{{location}}', '{{ageGroup}}'].map(tag => (
                                  <button 
                                    key={tag}
                                    onClick={() => setBulkEmailBody(prev => prev + tag)}
                                    className="text-[10px] font-bold bg-zinc-100 text-zinc-600 px-2 py-1 rounded-lg hover:bg-zinc-200"
                                  >
                                    {tag}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <textarea 
                              value={bulkEmailBody}
                              onChange={(e) => setBulkEmailBody(e.target.value)}
                              rows={12}
                              placeholder="Type your message here... Use tags like {{name}} for personalization."
                              className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900/10 outline-none resize-none custom-scrollbar"
                            />
                          </div>

                          <button 
                            onClick={handleSendBulkEmail}
                            disabled={isSendingBulk || selectedBulkMemberIds.size === 0}
                            className={cn(
                              "w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-zinc-900/10",
                              isSendingBulk || selectedBulkMemberIds.size === 0
                                ? "bg-zinc-100 text-zinc-400 cursor-not-allowed"
                                : "bg-zinc-900 text-white hover:bg-zinc-800 active:scale-[0.98]"
                            )}
                          >
                            {isSendingBulk ? (
                              <>
                                <Loader2 className="animate-spin" size={20} />
                                Sending ({bulkSendProgress.current}/{bulkSendProgress.total})...
                              </>
                            ) : (
                              <>
                                <Send size={20} />
                                Send to {selectedBulkMemberIds.size} Members
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'whatsapp' && (
                <motion.div
                  key="whatsapp"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-bold text-zinc-900">WhatsApp Messaging</h3>
                      <p className="text-zinc-500">Send direct WhatsApp messages to your members</p>
                    </div>
                    {!config?.whatsapp?.enabled && (
                      <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 text-amber-700 rounded-xl border border-amber-100 text-sm font-medium">
                        <AlertCircle size={16} />
                        WhatsApp is not enabled. Go to Configuration to set it up.
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Member Selection */}
                    <div className="lg:col-span-2 space-y-6">
                      <div className="bg-white rounded-[2.5rem] border border-zinc-100 shadow-sm overflow-hidden">
                        <div className="p-6 border-b border-zinc-50 flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
                              <Users size={18} />
                            </div>
                            <h4 className="font-bold text-zinc-900">Select Members</h4>
                          </div>
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => {
                                const allIds = members.filter(m => m.whatsapp || m.phone).map(m => m.id);
                                setSelectedWhatsappMemberIds(new Set(allIds));
                              }}
                              className="text-xs font-bold text-zinc-500 hover:text-zinc-900 uppercase tracking-wider"
                            >
                              Select All
                            </button>
                            <span className="text-zinc-200">|</span>
                            <button 
                              onClick={() => setSelectedWhatsappMemberIds(new Set())}
                              className="text-xs font-bold text-zinc-500 hover:text-zinc-900 uppercase tracking-wider"
                            >
                              Clear
                            </button>
                          </div>
                        </div>
                        
                        <div className="p-6">
                          <div className="relative mb-6">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                            <input
                              type="text"
                              placeholder="Search members by name or phone..."
                              className="w-full pl-12 pr-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 outline-none transition-all"
                              onChange={(e) => setMemberSearch(e.target.value)}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin">
                            {members
                              .filter(m => {
                                const search = memberSearch.toLowerCase();
                                return m.name.toLowerCase().includes(search) || 
                                       (m.phone || '').includes(search) || 
                                       (m.whatsapp || '').includes(search);
                              })
                              .map(member => {
                                const hasPhone = member.phone || member.whatsapp;
                                return (
                                  <button
                                    key={member.id}
                                    disabled={!hasPhone}
                                    onClick={() => {
                                      const newSet = new Set(selectedWhatsappMemberIds);
                                      if (newSet.has(member.id)) newSet.delete(member.id);
                                      else newSet.add(member.id);
                                      setSelectedWhatsappMemberIds(newSet);
                                    }}
                                    className={cn(
                                      "flex items-center gap-3 p-4 rounded-2xl border transition-all text-left group",
                                      selectedWhatsappMemberIds.has(member.id)
                                        ? "bg-emerald-50 border-emerald-200 shadow-sm"
                                        : hasPhone 
                                          ? "bg-white border-zinc-100 hover:border-zinc-300"
                                          : "bg-zinc-50 border-zinc-100 opacity-50 cursor-not-allowed"
                                    )}
                                  >
                                    <div className={cn(
                                      "w-10 h-10 rounded-full flex items-center justify-center font-bold shrink-0",
                                      selectedWhatsappMemberIds.has(member.id) ? "bg-emerald-500 text-white" : "bg-zinc-100 text-zinc-500"
                                    )}>
                                      {member.name.charAt(0)}
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <p className="text-sm font-bold text-zinc-900 truncate">{member.name}</p>
                                      <p className="text-xs text-zinc-500 truncate">{member.whatsapp || member.phone || 'No phone'}</p>
                                    </div>
                                    {selectedWhatsappMemberIds.has(member.id) && (
                                      <CheckCircle2 size={18} className="text-emerald-500 shrink-0" />
                                    )}
                                  </button>
                                );
                              })}
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Message Composer */}
                    <div className="space-y-6">
                      <div className="bg-white rounded-[2.5rem] border border-zinc-100 shadow-sm p-8 sticky top-8">
                        <div className="flex items-center gap-3 mb-8">
                          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
                            <MessageCircle size={18} />
                          </div>
                          <h4 className="font-bold text-zinc-900">Compose Message</h4>
                        </div>

                        <div className="space-y-6">
                          <div className="space-y-2">
                            <label className="text-sm font-bold text-zinc-700 ml-1">Message Content</label>
                            <textarea
                              value={whatsappMessage}
                              onChange={(e) => setWhatsappMessage(e.target.value)}
                              placeholder="Type your message here..."
                              rows={8}
                              className="w-full px-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 outline-none transition-all resize-none"
                            />
                            <div className="flex flex-wrap gap-2 mt-2">
                              {['{{name}}', '{{email}}', '{{location}}', '{{ageGroup}}'].map(tag => (
                                <button
                                  key={tag}
                                  onClick={() => setWhatsappMessage(prev => prev + tag)}
                                  className="px-2 py-1 bg-zinc-100 hover:bg-zinc-200 text-zinc-600 rounded-lg text-[10px] font-bold transition-colors"
                                >
                                  {tag}
                                </button>
                              ))}
                            </div>
                          </div>

                          <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                            <div className="flex justify-between items-center mb-2">
                              <span className="text-xs font-bold text-zinc-500">Recipients</span>
                              <span className="text-xs font-bold text-zinc-900">{selectedWhatsappMemberIds.size} selected</span>
                            </div>
                            <div className="w-full bg-zinc-200 rounded-full h-1.5">
                              <div 
                                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500" 
                                style={{ width: `${(selectedWhatsappMemberIds.size / members.length) * 100}%` }}
                              />
                            </div>
                          </div>

                          <button 
                            onClick={handleSendWhatsappBulk}
                            disabled={isSendingWhatsapp || selectedWhatsappMemberIds.size === 0 || !config?.whatsapp?.enabled}
                            className={cn(
                              "w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-zinc-900/10",
                              isSendingWhatsapp || selectedWhatsappMemberIds.size === 0 || !config?.whatsapp?.enabled
                                ? "bg-zinc-100 text-zinc-400 cursor-not-allowed"
                                : "bg-emerald-500 text-white hover:bg-emerald-600 active:scale-[0.98]"
                            )}
                          >
                            {isSendingWhatsapp ? (
                              <>
                                <Loader2 className="animate-spin" size={20} />
                                Sending ({whatsappSendProgress.current}/{whatsappSendProgress.total})...
                              </>
                            ) : (
                              <>
                                <Send size={20} />
                                Send to {selectedWhatsappMemberIds.size} Members
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activeTab === 'config' && (
                <motion.div
                  key="config"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="space-y-8"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-2xl font-bold text-zinc-900">Configuration</h3>
                      <p className="text-zinc-500">Manage your application settings and preferences</p>
                    </div>
                    <div className="flex flex-wrap gap-2 bg-white p-1.5 rounded-2xl border border-zinc-100 shadow-sm">
                      {[
                        { id: 'notifications', label: 'Notifications', icon: Mail },
                        { id: 'branding', label: 'Branding', icon: ImageIcon },
                        { id: 'public_info', label: 'Public Info', icon: Globe },
                        { id: 'backup', label: 'Backup', icon: Database },
                        { id: 'whatsapp_config', label: 'WhatsApp Config', icon: MessageCircle },
                        { id: 'registration', label: 'Registration', icon: Users },
                        { id: 'evaluations', label: 'Evaluations', icon: Trophy },
                        { id: 'logs', label: 'Email Log', icon: History },
                        { id: 'lists', label: 'Lists', icon: Settings },
                        ...(user?.email === "anafj246@gmail.com" ? [
                          { id: 'smtp', label: 'SMTP', icon: Server },
                          { id: 'templates', label: 'Templates', icon: FileText },
                          { id: 'data', label: 'Data', icon: Trash2 }
                        ] : [])
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setConfigTab(tab.id as any)}
                          className={cn(
                            "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all",
                            configTab === tab.id 
                              ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" 
                              : "text-zinc-500 hover:bg-zinc-50"
                          )}
                        >
                          <tab.icon size={16} />
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <AnimatePresence mode="wait">
                    {configTab === 'branding' && (
                      <motion.div
                        key="branding"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-2xl"
                      >
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <ImageIcon size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Branding</h3>
                                <p className="text-sm text-zinc-500">Customize your application logo and name</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig(localBrandingInfo, 'branding')}
                              disabled={isSaving === 'branding'}
                              className="px-6 py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all flex items-center gap-2 disabled:opacity-50"
                            >
                              {isSaving === 'branding' ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                              {justSaved === 'branding' ? 'Saved!' : 'Save Branding'}
                            </button>
                          </div>

                          <div className="space-y-8">
                            <div className="space-y-4">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">Club Name</label>
                              <input
                                type="text"
                                value={localBrandingInfo.clubName}
                                onChange={(e) => setLocalBrandingInfo({ ...localBrandingInfo, clubName: e.target.value })}
                                className="w-full px-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 focus:bg-white transition-all text-sm font-bold"
                                placeholder="Enter club name..."
                              />
                            </div>

                            <div className="space-y-4">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">Header Logo</label>
                              <div className="flex flex-col items-center gap-6 p-8 bg-zinc-50 rounded-[2rem] border border-dashed border-zinc-200">
                                {localBrandingInfo.logoUrl ? (
                                  <div className="relative group">
                                    <img 
                                      src={localBrandingInfo.logoUrl} 
                                      alt="App Logo" 
                                      className="max-h-32 object-contain rounded-xl"
                                      referrerPolicy="no-referrer"
                                    />
                                    <button 
                                      onClick={() => setLocalBrandingInfo({ ...localBrandingInfo, logoUrl: '' })}
                                      className="absolute -top-2 -right-2 p-2 bg-rose-500 text-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                      <X size={16} />
                                    </button>
                                  </div>
                                ) : (
                                  <div className="w-24 h-24 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400">
                                    <ImageIcon size={40} />
                                  </div>
                                )}
                                
                                <div className="text-center">
                                  <input
                                    type="file"
                                    id="logo-upload"
                                    className="hidden"
                                    accept="image/*"
                                    onChange={async (e) => {
                                      const file = e.target.files?.[0];
                                      if (file) {
                                        try {
                                          const compressed = await compressImage(file, 400, 400, 0.7);
                                          setLocalBrandingInfo({ ...localBrandingInfo, logoUrl: compressed });
                                        } catch (err) {
                                          console.error("Error compressing logo:", err);
                                          const base64 = await fileToBase64(file);
                                          setLocalBrandingInfo({ ...localBrandingInfo, logoUrl: base64 });
                                        }
                                      }
                                    }}
                                  />
                                  <label 
                                    htmlFor="logo-upload"
                                    className="px-6 py-3 bg-zinc-900 text-white rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all cursor-pointer inline-flex items-center gap-2"
                                  >
                                    <Camera size={18} />
                                    {localBrandingInfo.logoUrl ? 'Change Logo' : 'Upload Logo'}
                                  </label>
                                  <p className="text-[10px] text-zinc-400 mt-3">Recommended: PNG or SVG with transparent background (Max 500KB)</p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'public_info' && localPublicInfo && (
                      <motion.div
                        key="public_info"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="space-y-8"
                      >
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm">
                          <div className="flex flex-col gap-6 mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <Globe size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Public Information</h3>
                                <p className="text-sm text-zinc-500">Manage the content displayed on your public club page</p>
                              </div>
                            </div>
                            <div className="flex flex-wrap items-center gap-4">
                              <div className="flex bg-zinc-100 p-1 rounded-xl border border-zinc-200">
                                <button
                                  onClick={() => setConfigLang('en')}
                                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${configLang === 'en' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
                                >
                                  English
                                </button>
                                <button
                                  onClick={() => setConfigLang('ar')}
                                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${configLang === 'ar' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-500 hover:text-zinc-700'}`}
                                >
                                  Arabic
                                </button>
                              </div>
                              <button
                                onClick={() => setBilingualMode(!bilingualMode)}
                                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all border ${bilingualMode ? 'bg-zinc-900 text-white border-zinc-900 shadow-lg shadow-zinc-200' : 'bg-white text-zinc-600 border-zinc-200 hover:border-zinc-300'}`}
                              >
                                <Languages size={14} />
                                {bilingualMode ? 'Bilingual Mode: ON' : 'Bilingual Mode: OFF'}
                              </button>
                              <button
                                onClick={() => handleUpdateConfig({ publicInfo: localPublicInfo }, 'public_info')}
                              disabled={isSaving === 'public_info'}
                              className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all disabled:opacity-50 shadow-lg shadow-zinc-200"
                            >
                              {isSaving === 'public_info' ? <Clock className="animate-spin" size={18} /> : (justSaved === 'public_info' ? <Check size={18} /> : <Save size={18} />)}
                              {isSaving === 'public_info' ? 'Saving...' : (justSaved === 'public_info' ? 'Saved!' : 'Save Changes')}
                            </button>
                          </div>

                          <div className="space-y-10">
                            {/* Hero Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <LayoutDashboard size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">Hero Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Hero Title (Main)"
                                  enKey="heroTitle"
                                  arKey="heroTitleArabic"
                                  placeholderEn="e.g. Excellence"
                                  placeholderAr="مثال: التميز"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Hero Subtitle (Accent)"
                                  enKey="heroSubtitle"
                                  arKey="heroSubtitleArabic"
                                  placeholderEn="e.g. Redefined."
                                  placeholderAr="مثال: مفهوم جديد"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Hero Description"
                                    enKey="heroDescription"
                                    arKey="heroDescriptionArabic"
                                    placeholderEn="Enter a compelling description for the hero section..."
                                    placeholderAr="أدخل وصفاً جذاباً لقسم الهيرو..."
                                    rows={4}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                                <div className="space-y-4">
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Hero Image</label>
                                  <div className="flex flex-col items-start gap-4">
                                    <div className="w-24 h-32 bg-zinc-200 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                                      {localPublicInfo.heroImageUrl ? (
                                        <img src={localPublicInfo.heroImageUrl} alt="Hero Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      ) : (
                                        <ImageIcon size={24} className="text-zinc-400" />
                                      )}
                                    </div>
                                    <div className="space-y-3">
                                      <input
                                        type="file"
                                        id="hero-image-upload"
                                        className="hidden"
                                        accept="image/*"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            if (file.size > 500 * 1024) {
                                              alert("Image is too large. Max 500KB.");
                                              return;
                                            }
                                            const base64 = await fileToBase64(file);
                                            setLocalPublicInfo({ ...localPublicInfo, heroImageUrl: base64 });
                                          }
                                        }}
                                      />
                                      <label 
                                        htmlFor="hero-image-upload"
                                        className="px-4 py-2 bg-zinc-900 text-white rounded-lg text-xs font-bold hover:bg-zinc-800 transition-all cursor-pointer inline-flex items-center gap-2"
                                      >
                                        <Camera size={14} />
                                        {localPublicInfo.heroImageUrl ? 'Change Hero Image' : 'Upload Hero Image'}
                                      </label>
                                      <p className="text-[10px] text-zinc-400">High quality vertical image recommended (Max 500KB)</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                            {/* Section Order Management */}
                            <div className="space-y-4">
                              <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">Section Order</label>
                              <div className="grid grid-cols-1 gap-3">
                                {(localPublicInfo.sectionOrder || ['images', 'videos', 'about', 'activities', 'programs', 'locations', 'calendar', 'contact']).map((section, idx, arr) => (
                                  <div key={section} className="flex flex-col gap-3 p-4 bg-zinc-50 rounded-xl border border-zinc-100">
                                    <span className="text-sm font-bold text-zinc-700 capitalize">{section}</span>
                                    <div className="flex items-center gap-2">
                                      <button
                                        onClick={() => {
                                          const newOrder = [...arr];
                                          if (idx > 0) {
                                            [newOrder[idx], newOrder[idx - 1]] = [newOrder[idx - 1], newOrder[idx]];
                                            setLocalPublicInfo({ ...localPublicInfo, sectionOrder: newOrder });
                                          }
                                        }}
                                        disabled={idx === 0}
                                        className="p-1.5 hover:bg-zinc-200 rounded-lg disabled:opacity-30 transition-colors"
                                      >
                                        <ChevronUp size={16} />
                                      </button>
                                      <button
                                        onClick={() => {
                                          const newOrder = [...arr];
                                          if (idx < newOrder.length - 1) {
                                            [newOrder[idx], newOrder[idx + 1]] = [newOrder[idx + 1], newOrder[idx]];
                                            setLocalPublicInfo({ ...localPublicInfo, sectionOrder: newOrder });
                                          }
                                        }}
                                        disabled={idx === arr.length - 1}
                                        className="p-1.5 hover:bg-zinc-200 rounded-lg disabled:opacity-30 transition-colors"
                                      >
                                        <ChevronDown size={16} />
                                      </button>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {/* Gallery Management */}
                            <div className="space-y-4">
                              <div className="flex flex-col gap-4">
                                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider">Gallery (Images & Videos)</label>
                                <div className="flex flex-wrap items-center gap-2">
                                  <button
                                    onClick={() => {
                                      setIsPublicInfo(true);
                                      setIsFullGallery(true);
                                    }}
                                    className="flex items-center gap-2 px-3 py-1.5 bg-zinc-100 text-zinc-600 rounded-lg hover:bg-zinc-200 text-xs font-bold transition-all"
                                  >
                                    <Eye size={14} /> Preview Gallery
                                  </button>
                                  <button
                                    onClick={() => {
                                      setIsPublicInfo(true);
                                      setIsFullVideos(true);
                                    }}
                                    className="flex items-center gap-2 px-3 py-1.5 bg-zinc-100 text-zinc-600 rounded-lg hover:bg-zinc-200 text-xs font-bold transition-all"
                                  >
                                    <Play size={14} /> Preview Videos
                                  </button>
                                  <button
                                    onClick={() => setIsVideoInputOpen(!isVideoInputOpen)}
                                    className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 text-white rounded-lg hover:bg-zinc-800 text-xs font-bold transition-all"
                                  >
                                    <PlusCircle size={14} /> {isVideoInputOpen ? 'Cancel' : 'Add Video URL'}
                                  </button>
                                  <button
                                    onClick={() => {
                                      const input = document.createElement('input');
                                      input.type = 'file';
                                      input.accept = 'image/*';
                                      input.multiple = true;
                                      input.onchange = async (e) => {
                                        const files = (e.target as HTMLInputElement).files;
                                        if (files) {
                                          for (let i = 0; i < files.length; i++) {
                                            const reader = new FileReader();
                                            reader.onload = async (event) => {
                                              const base64 = event.target?.result as string;
                                              await handleAddGalleryImage(base64, 'image');
                                            };
                                            reader.readAsDataURL(files[i]);
                                          }
                                        }
                                      };
                                      input.click();
                                    }}
                                    className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 text-white rounded-lg hover:bg-zinc-800 text-xs font-bold transition-all"
                                  >
                                    <PlusCircle size={14} /> Add Images
                                  </button>
                                </div>
                              </div>

                              {isVideoInputOpen && (
                                <motion.div 
                                  initial={{ opacity: 0, y: -10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 space-y-3"
                                >
                                  <div className="flex gap-2">
                                    <input
                                      type="text"
                                      placeholder="Enter YouTube/Vimeo/Direct URL..."
                                      value={videoUrlInput}
                                      onChange={(e) => setVideoUrlInput(e.target.value)}
                                      className="flex-1 px-4 py-2 bg-white border border-zinc-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 text-sm"
                                    />
                                    <button
                                      onClick={() => {
                                        if (videoUrlInput) {
                                          handleAddGalleryImage(videoUrlInput, 'video');
                                          setVideoUrlInput('');
                                          setIsVideoInputOpen(false);
                                        }
                                      }}
                                      className="px-4 py-2 bg-zinc-900 text-white rounded-xl text-sm font-bold hover:bg-zinc-800 transition-all"
                                    >
                                      Add
                                    </button>
                                  </div>
                                  <p className="text-[10px] text-zinc-400">Supports YouTube, Vimeo, and direct links to .mp4 files.</p>
                                </motion.div>
                              )}

                              <div className="grid grid-cols-1 gap-4">
                                  {galleryImages.map((img, index) => (
                                    <div key={img.id} className="relative group rounded-2xl overflow-hidden border border-zinc-100 bg-zinc-50 max-w-sm">
                                      <div className="aspect-video relative">
                                        {img.type === 'video' ? (
                                          <div className="w-full h-full bg-zinc-900 flex items-center justify-center">
                                            <Play size={32} className="text-white/50" />
                                          </div>
                                        ) : (
                                          <img src={img.url} alt={`Gallery ${index}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                        )}
                                        <button
                                          onClick={() => handleRemoveGalleryImage(img.id)}
                                          className="absolute top-2 right-2 p-1.5 bg-rose-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity z-10"
                                        >
                                          <Trash2 size={14} />
                                        </button>
                                        <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/50 text-white text-[8px] font-bold rounded uppercase">
                                          {img.type || 'image'}
                                        </div>
                                      </div>
                                      <div className="p-2">
                                        <input
                                          type="text"
                                          value={configLang === 'ar' ? (img.captionArabic || '') : (img.caption || '')}
                                          onChange={(e) => handleUpdateGalleryImage(img.id, { [configLang === 'ar' ? 'captionArabic' : 'caption']: e.target.value })}
                                          placeholder={configLang === 'ar' ? "أضف وصفاً..." : "Add caption..."}
                                          className="w-full text-[10px] px-2 py-1 bg-white border border-zinc-100 rounded-xl focus:outline-none focus:ring-1 focus:ring-zinc-900/10 transition-all"
                                          dir={configLang === 'ar' ? 'rtl' : 'ltr'}
                                        />
                                      </div>
                                    </div>
                                  ))}
                                  <label className="aspect-video rounded-2xl border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-zinc-50 transition-all text-zinc-400 hover:text-zinc-600 relative overflow-hidden max-w-sm">
                                    {isUploadingGallery ? (
                                      <div className="flex flex-col items-center gap-2">
                                        <Clock className="animate-spin text-zinc-900" size={24} />
                                        <span className="text-[10px] font-bold text-zinc-900">Uploading...</span>
                                      </div>
                                    ) : (
                                      <>
                                        <Plus size={24} />
                                        <span className="text-xs font-bold">Add Image</span>
                                      </>
                                    )}
                                    <input
                                      type="file"
                                      className="hidden"
                                      accept="image/*"
                                      disabled={isUploadingGallery}
                                      onChange={async (e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                          if (file.size > 500 * 1024) {
                                            alert("Image is too large. Max 500KB.");
                                            return;
                                          }
                                          const base64 = await fileToBase64(file);
                                          handleAddGalleryImage(base64, 'image');
                                        }
                                      }}
                                    />
                                  </label>
                              </div>
                            </div>

                            {/* About Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <Info size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"About" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="About Title"
                                  enKey="aboutTitle"
                                  arKey="aboutTitleArabic"
                                  placeholderEn="e.g. Our Story"
                                  placeholderAr="مثال: قصتنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="About Subtitle"
                                  enKey="aboutSubtitle"
                                  arKey="aboutSubtitleArabic"
                                  placeholderEn="e.g. Legacy & Vision"
                                  placeholderAr="مثال: الرؤية والرسالة"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="About Content (Markdown)"
                                    enKey="information"
                                    arKey="informationArabic"
                                    placeholderEn="Tell your story..."
                                    placeholderAr="احكِ قصتك..."
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Activities Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <Activity size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Activities" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Activities Title"
                                  enKey="activitiesTitle"
                                  arKey="activitiesTitleArabic"
                                  placeholderEn="e.g. Activities"
                                  placeholderAr="مثال: الأنشطة"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Activities Subtitle"
                                  enKey="activitiesSubtitle"
                                  arKey="activitiesSubtitleArabic"
                                  placeholderEn="e.g. What We Do"
                                  placeholderAr="مثال: ما نقوم به"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Activities Content (Markdown)"
                                    enKey="activities"
                                    arKey="activitiesArabic"
                                    placeholderEn="Describe your activities..."
                                    placeholderAr="صف أنشطتك..."
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                                <div className="space-y-4">
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Activities Image</label>
                                  <div className="flex flex-col items-start gap-4">
                                    <div className="w-24 h-32 bg-zinc-200 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                                      {localPublicInfo.activitiesImageUrl ? (
                                        <img src={localPublicInfo.activitiesImageUrl} alt="Activities Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      ) : (
                                        <ImageIcon size={24} className="text-zinc-400" />
                                      )}
                                    </div>
                                    <div className="space-y-3">
                                      <input
                                        type="file"
                                        id="activities-image-upload"
                                        className="hidden"
                                        accept="image/*"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            if (file.size > 500 * 1024) {
                                              alert("Image is too large. Max 500KB.");
                                              return;
                                            }
                                            const base64 = await fileToBase64(file);
                                            setLocalPublicInfo({ ...localPublicInfo, activitiesImageUrl: base64 });
                                          }
                                        }}
                                      />
                                      <label 
                                        htmlFor="activities-image-upload"
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 rounded-xl text-xs font-bold text-zinc-900 hover:bg-zinc-50 transition-all cursor-pointer shadow-sm"
                                      >
                                        <Camera size={14} />
                                        {localPublicInfo.activitiesImageUrl ? 'Change Activities Image' : 'Upload Activities Image'}
                                      </label>
                                      <p className="text-[10px] text-zinc-400 leading-relaxed">
                                        Recommended: Portrait aspect ratio (3:4 or 4:5).<br />
                                        Max file size: 500KB.
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Programs Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <BookOpen size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Programs" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Programs Title"
                                  enKey="programsTitle"
                                  arKey="programsTitleArabic"
                                  placeholderEn="e.g. Our Programs"
                                  placeholderAr="مثال: برامجنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Programs Subtitle"
                                  enKey="programsSubtitle"
                                  arKey="programsSubtitleArabic"
                                  placeholderEn="e.g. Learning Path"
                                  placeholderAr="مثال: مسار التعلم"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Programs Content (Markdown)"
                                    enKey="programs"
                                    arKey="programsArabic"
                                    placeholderEn="Describe your programs..."
                                    placeholderAr="صف برامجك..."
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                                <div className="space-y-4">
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Programs Image</label>
                                  <div className="flex flex-col items-start gap-4">
                                    <div className="w-24 h-32 bg-zinc-200 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                                      {localPublicInfo.programsImageUrl ? (
                                        <img src={localPublicInfo.programsImageUrl} alt="Programs Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      ) : (
                                        <ImageIcon size={24} className="text-zinc-400" />
                                      )}
                                    </div>
                                    <div className="space-y-3">
                                      <input
                                        type="file"
                                        id="programs-image-upload"
                                        className="hidden"
                                        accept="image/*"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            if (file.size > 500 * 1024) {
                                              alert("Image is too large. Max 500KB.");
                                              return;
                                            }
                                            const base64 = await fileToBase64(file);
                                            setLocalPublicInfo({ ...localPublicInfo, programsImageUrl: base64 });
                                          }
                                        }}
                                      />
                                      <label 
                                        htmlFor="programs-image-upload"
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 rounded-xl text-xs font-bold text-zinc-900 hover:bg-zinc-50 transition-all cursor-pointer shadow-sm"
                                      >
                                        <Camera size={14} />
                                        {localPublicInfo.programsImageUrl ? 'Change Programs Image' : 'Upload Programs Image'}
                                      </label>
                                      <p className="text-[10px] text-zinc-400 leading-relaxed">
                                        Recommended: Portrait aspect ratio (3:4 or 4:5).<br />
                                        Max file size: 500KB.
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Locations Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <MapPin size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Locations" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Locations Title"
                                  enKey="locationsTitle"
                                  arKey="locationsTitleArabic"
                                  placeholderEn="e.g. Our Locations"
                                  placeholderAr="مثال: مواقعنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Locations Subtitle"
                                  enKey="locationsSubtitle"
                                  arKey="locationsSubtitleArabic"
                                  placeholderEn="e.g. Find Us"
                                  placeholderAr="مثال: تجدنا هنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Locations Content (Markdown)"
                                    enKey="locations"
                                    arKey="locationsArabic"
                                    placeholderEn="Describe your locations..."
                                    placeholderAr="صف مواقعك..."
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                                <div className="space-y-4">
                                  <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Locations Image</label>
                                  <div className="flex flex-col items-start gap-4">
                                    <div className="w-24 h-32 bg-zinc-200 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
                                      {localPublicInfo.locationsImageUrl ? (
                                        <img src={localPublicInfo.locationsImageUrl} alt="Locations Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                      ) : (
                                        <ImageIcon size={24} className="text-zinc-400" />
                                      )}
                                    </div>
                                    <div className="space-y-3">
                                      <input
                                        type="file"
                                        id="locations-image-upload"
                                        className="hidden"
                                        accept="image/*"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            if (file.size > 500 * 1024) {
                                              alert("Image is too large. Max 500KB.");
                                              return;
                                            }
                                            const base64 = await fileToBase64(file);
                                            setLocalPublicInfo({ ...localPublicInfo, locationsImageUrl: base64 });
                                          }
                                        }}
                                      />
                                      <label 
                                        htmlFor="locations-image-upload"
                                        className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-zinc-200 rounded-xl text-xs font-bold text-zinc-900 hover:bg-zinc-50 transition-all cursor-pointer shadow-sm"
                                      >
                                        <Camera size={14} />
                                        {localPublicInfo.locationsImageUrl ? 'Change Locations Image' : 'Upload Locations Image'}
                                      </label>
                                      <p className="text-[10px] text-zinc-400 leading-relaxed">
                                        Recommended: Portrait aspect ratio (3:4 or 4:5).<br />
                                        Max file size: 500KB.
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Calendar Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <Calendar size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Calendar" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Calendar Title"
                                  enKey="calendarTitle"
                                  arKey="calendarTitleArabic"
                                  placeholderEn="e.g. Club Calendar"
                                  placeholderAr="مثال: تقويم النادي"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Calendar Subtitle"
                                  enKey="calendarSubtitle"
                                  arKey="calendarSubtitleArabic"
                                  placeholderEn="e.g. Stay Updated"
                                  placeholderAr="مثال: ابقَ على اطلاع"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Calendar Content (Markdown)"
                                    enKey="calendar"
                                    arKey="calendarArabic"
                                    placeholderEn="Describe your calendar..."
                                    placeholderAr="صف تقويمك..."
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Contact Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <Phone size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Contact" Section</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Contact Title"
                                  enKey="contactTitle"
                                  arKey="contactTitleArabic"
                                  placeholderEn="e.g. Contact Information"
                                  placeholderAr="مثال: معلومات الاتصال"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Contact Subtitle"
                                  enKey="contactSubtitle"
                                  arKey="contactSubtitleArabic"
                                  placeholderEn="e.g. Get In Touch"
                                  placeholderAr="مثال: تواصل معنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Contact Content (Markdown)"
                                    enKey="contact"
                                    arKey="contactArabic"
                                    placeholderEn="How can people reach you?"
                                    placeholderAr="كيف يمكن للناس الوصول إليك؟"
                                    rows={6}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                              </div>
                            </div>

                            {/* Gallery & Videos Titles Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <Camera size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">Gallery & Videos Titles</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Gallery Title"
                                  enKey="galleryTitle"
                                  arKey="galleryTitleArabic"
                                  placeholderEn="e.g. Our Gallery"
                                  placeholderAr="مثال: معرضنا"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Gallery Subtitle"
                                  enKey="gallerySubtitle"
                                  arKey="gallerySubtitleArabic"
                                  placeholderEn="e.g. Visual Journey"
                                  placeholderAr="مثال: رحلة بصرية"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Videos Title"
                                  enKey="videosTitle"
                                  arKey="videosTitleArabic"
                                  placeholderEn="e.g. Featured Videos"
                                  placeholderAr="مثال: فيديوهات مختارة"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Videos Subtitle"
                                  enKey="videosSubtitle"
                                  arKey="videosSubtitleArabic"
                                  placeholderEn="e.g. Motion Stories"
                                  placeholderAr="مثال: قصص متحركة"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                              </div>
                            </div>

                            {/* Join Us Section Management */}
                            <div className="space-y-6 p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-center gap-3 mb-2">
                                <div className="p-2 bg-zinc-900 rounded-xl">
                                  <UserPlus size={18} className="text-white" />
                                </div>
                                <h4 className="font-bold text-zinc-900">"Join Us" Section (Bottom)</h4>
                              </div>
                              <div className="grid grid-cols-1 gap-6">
                                <BilingualInput
                                  label="Join Title"
                                  enKey="joinTitle"
                                  arKey="joinTitleArabic"
                                  placeholderEn="e.g. Ready to Join?"
                                  placeholderAr="مثال: جاهز للانضمام؟"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <BilingualInput
                                  label="Join Subtitle"
                                  enKey="joinSubtitle"
                                  arKey="joinSubtitleArabic"
                                  placeholderEn="e.g. Start Your Journey"
                                  placeholderAr="مثال: ابدأ رحلتك"
                                  localPublicInfo={localPublicInfo}
                                  setLocalPublicInfo={setLocalPublicInfo}
                                  configLang={configLang}
                                  bilingualMode={bilingualMode}
                                />
                                <div className="space-y-6">
                                  <BilingualTextarea
                                    label="Join Description"
                                    enKey="joinDescription"
                                    arKey="joinDescriptionArabic"
                                    placeholderEn="Encourage people to join..."
                                    placeholderAr="شجع الناس على الانضمام..."
                                    rows={3}
                                    localPublicInfo={localPublicInfo}
                                    setLocalPublicInfo={setLocalPublicInfo}
                                    configLang={configLang}
                                    bilingualMode={bilingualMode}
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'backup' && (
                      <motion.div
                        key="backup"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-2xl"
                      >
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center gap-3 mb-8">
                            <div className="p-3 bg-zinc-900 rounded-2xl">
                              <Database size={24} className="text-white" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">Backup & Export</h3>
                              <p className="text-sm text-zinc-500">Securely export your application data and system configuration</p>
                            </div>
                          </div>

                          <div className="space-y-6">
                            {/* Data & Attachments Backup */}
                            <div className="p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-start gap-4">
                                <div className="p-2 bg-zinc-900 rounded-xl mt-1">
                                  <FileText size={18} className="text-white" />
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-zinc-900">Data & Attachments</h4>
                                  <p className="text-sm text-zinc-500 mb-4">
                                    Export all members, attendance records, payments, evaluations, and expenses. 
                                    This includes all dynamic data stored in the database.
                                  </p>
                                  <button
                                    onClick={handleExportData}
                                    disabled={isBackingUp === 'data'}
                                    className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all disabled:opacity-50"
                                  >
                                    {isBackingUp === 'data' ? (
                                      <>
                                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        Exporting...
                                      </>
                                    ) : (
                                      <>
                                        <Download size={18} />
                                        Backup Data & Attachments
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Attachments Backup */}
                            <div className="p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-start gap-4">
                                <div className="p-2 bg-zinc-900 rounded-xl mt-1">
                                  <Camera size={18} className="text-white" />
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-zinc-900">Attachments (IDs & Images)</h4>
                                  <p className="text-sm text-zinc-500 mb-4">
                                    Download all profile images, ID copies, and gallery photos as a single ZIP archive.
                                  </p>
                                  <button
                                    onClick={handleExportAttachments}
                                    disabled={isBackingUp === 'attachments'}
                                    className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all disabled:opacity-50"
                                  >
                                    {isBackingUp === 'attachments' ? (
                                      <>
                                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        Zipping...
                                      </>
                                    ) : (
                                      <>
                                        <Download size={18} />
                                        Download All Attachments
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>

                            {/* Database Objects Backup */}
                            <div className="p-6 bg-zinc-50 rounded-3xl border border-zinc-100">
                              <div className="flex items-start gap-4">
                                <div className="p-2 bg-zinc-900 rounded-xl mt-1">
                                  <Shield size={18} className="text-white" />
                                </div>
                                <div className="flex-1">
                                  <h4 className="font-bold text-zinc-900">Database Objects & System Config</h4>
                                  <p className="text-sm text-zinc-500 mb-4">
                                    Export system configuration, security rules, data blueprints, and application metadata. 
                                    (Equivalent to tables, views, packages, and functions).
                                  </p>
                                  <button
                                    onClick={handleExportSystem}
                                    disabled={isBackingUp === 'system'}
                                    className="flex items-center gap-2 px-6 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all disabled:opacity-50"
                                  >
                                    {isBackingUp === 'system' ? (
                                      <>
                                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                        Exporting...
                                      </>
                                    ) : (
                                      <>
                                        <Download size={18} />
                                        Backup Database Objects
                                      </>
                                    )}
                                  </button>
                                </div>
                              </div>
                            </div>

                            <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl">
                              <div className="flex gap-3">
                                <AlertCircle size={18} className="text-amber-600 shrink-0" />
                                <p className="text-xs text-amber-800 leading-relaxed">
                                  <strong>Note:</strong> Backups are exported as JSON files. Keep these files secure as they contain sensitive information. 
                                  In Firestore, "Database Objects" include security rules and data schemas which define the structure of your collections.
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'whatsapp_config' && (
                      <motion.div
                        key="whatsapp_config"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-2xl"
                      >
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm">
                          <div className="flex items-center gap-3 mb-8">
                            <div className="p-3 bg-emerald-500 rounded-2xl">
                              <MessageCircle size={24} className="text-white" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">WhatsApp Configuration</h3>
                              <p className="text-sm text-zinc-500">Configure your WhatsApp API settings for automated messaging</p>
                            </div>
                          </div>

                          <form onSubmit={async (e) => {
                            e.preventDefault();
                            if (!user || !config) return;
                            setIsSaving('whatsapp');
                            const formData = new FormData(e.currentTarget);
                            const updatedConfig = {
                              ...config,
                              whatsapp: {
                                apiKey: formData.get('apiKey') as string,
                                instanceId: formData.get('instanceId') as string,
                                apiUrl: formData.get('apiUrl') as string,
                                enabled: formData.get('enabled') === 'on'
                              }
                            };
                            try {
                              await updateDoc(doc(db, 'configs', config.id), updatedConfig);
                              setJustSaved('whatsapp');
                              setTimeout(() => setJustSaved(null), 2000);
                            } catch (err: any) {
                              alert("Failed to save WhatsApp config.");
                              handleFirestoreError(err, OperationType.UPDATE, 'configs');
                            } finally {
                              setIsSaving(null);
                            }
                          }} className="space-y-6">
                            <div className="space-y-4">
                              <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                                <div className="flex items-center gap-3">
                                  <div className="p-2 bg-white rounded-xl border border-zinc-100">
                                    <Activity size={18} className="text-zinc-600" />
                                  </div>
                                  <div>
                                    <p className="font-bold text-zinc-900">Enable WhatsApp</p>
                                    <p className="text-xs text-zinc-500">Enable or disable WhatsApp messaging features</p>
                                  </div>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                  <input 
                                    type="checkbox" 
                                    name="enabled"
                                    defaultChecked={config?.whatsapp?.enabled}
                                    className="sr-only peer" 
                                  />
                                  <div className="w-11 h-6 bg-zinc-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                                </label>
                              </div>

                              <div className="space-y-2">
                                <label className="text-sm font-bold text-zinc-700 ml-1">API URL</label>
                                <input
                                  type="text"
                                  name="apiUrl"
                                  defaultValue={config?.whatsapp?.apiUrl || 'https://api.ultramsg.com'}
                                  placeholder="e.g., https://api.ultramsg.com"
                                  className="w-full px-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 outline-none transition-all"
                                />
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <label className="text-sm font-bold text-zinc-700 ml-1">Instance ID</label>
                                  <input
                                    type="text"
                                    name="instanceId"
                                    defaultValue={config?.whatsapp?.instanceId}
                                    placeholder="Your Instance ID"
                                    className="w-full px-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 outline-none transition-all"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <label className="text-sm font-bold text-zinc-700 ml-1">API Key / Token</label>
                                  <input
                                    type="password"
                                    name="apiKey"
                                    defaultValue={config?.whatsapp?.apiKey}
                                    placeholder="Your API Token"
                                    className="w-full px-5 py-4 bg-zinc-50 border border-zinc-100 rounded-2xl focus:ring-2 focus:ring-zinc-900 outline-none transition-all"
                                  />
                                </div>
                              </div>
                            </div>

                            <button 
                              type="submit"
                              disabled={isSaving === 'whatsapp'}
                              className={cn(
                                "w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-zinc-900/10",
                                justSaved === 'whatsapp' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                              )}
                            >
                              {isSaving === 'whatsapp' ? (
                                <Loader2 className="animate-spin" size={20} />
                              ) : justSaved === 'whatsapp' ? (
                                <Check size={20} />
                              ) : (
                                <Save size={20} />
                              )}
                              {isSaving === 'whatsapp' ? 'Saving...' : justSaved === 'whatsapp' ? 'Saved!' : 'Save Configuration'}
                            </button>
                          </form>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'notifications' && (
                      <motion.div
                        key="notifications"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-2xl"
                      >
                        {/* Email Settings */}
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <Settings size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Email Notifications</h3>
                                <p className="text-sm text-zinc-500">Control which events trigger automated emails</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig({ emailNotifications: localNotifications! }, 'notifications')}
                              disabled={isSaving === 'notifications'}
                              className={cn(
                                "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50",
                                isSaving === 'notifications' ? "bg-zinc-100 text-zinc-400" : 
                                justSaved === 'notifications' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                              )}
                            >
                              {isSaving === 'notifications' ? 'Saving...' : 
                               justSaved === 'notifications' ? (
                                 <>
                                   <Check size={16} />
                                   Saved!
                                 </>
                               ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                          </div>

                          <div className="space-y-6 flex-1">
                            {[
                              { key: 'registration', label: 'New Registration', description: 'Send welcome email to new members' },
                              { key: 'trial', label: 'Trial Session Status', description: 'Notify users when trial request is approved/rejected' },
                              { key: 'attendance', label: 'Attendance Recorded', description: 'Notify members when attendance is marked', subOptions: [
                                { key: 'attendancePresent', label: 'When Present' },
                                { key: 'attendanceAbsent', label: 'When Absent' }
                              ] },
                              { key: 'payment', label: 'Payment Received', description: 'Send receipt after payment is recorded' },
                              { key: 'reminder', label: 'Payment Reminder', description: 'Send automated payment reminders' },
                              { key: 'evaluation', label: 'Evaluation Recorded', description: 'Send assessment details to members' },
                              { key: 'kit', label: 'Kit Received', description: 'Notify members when kit is marked as received' },
                              { key: 'whatsapp', label: 'WhatsApp Joined', description: 'Notify members when WhatsApp group is joined' },
                              { key: 'combineOnboardingEmails', label: 'Combine Onboarding Emails', description: 'Send one email when both kit and WhatsApp are selected' }
                            ].map((item) => (
                              <div key={item.key} className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                                  <div>
                                    <p className="font-bold text-zinc-900">{item.label}</p>
                                    <p className="text-xs text-zinc-500">{item.description}</p>
                                  </div>
                                  <button
                                    onClick={() => setLocalNotifications(prev => prev ? ({
                                      ...prev,
                                      [item.key]: !prev[item.key as keyof typeof prev]
                                    }) : null)}
                                    className={cn(
                                      "w-12 h-6 rounded-full transition-all relative",
                                      localNotifications?.[item.key as keyof typeof localNotifications] ? "bg-zinc-900" : "bg-zinc-200"
                                    )}
                                  >
                                    <motion.div
                                      animate={{ x: localNotifications?.[item.key as keyof typeof localNotifications] ? 24 : 4 }}
                                      className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm"
                                    />
                                  </button>
                                </div>

                                {item.subOptions && localNotifications?.[item.key as keyof typeof localNotifications] && (
                                  <div className="ml-8 space-y-3">
                                    {item.subOptions.map(sub => (
                                      <div key={sub.key} className="flex items-center justify-between p-3 bg-white rounded-xl border border-zinc-100">
                                        <p className="text-sm font-bold text-zinc-700">{sub.label}</p>
                                        <button
                                          onClick={() => setLocalNotifications(prev => prev ? ({
                                            ...prev,
                                            [sub.key]: !prev[sub.key as keyof typeof prev]
                                          }) : null)}
                                          className={cn(
                                            "w-10 h-5 rounded-full transition-all relative",
                                            localNotifications?.[sub.key as keyof typeof localNotifications] ? "bg-zinc-900" : "bg-zinc-200"
                                          )}
                                        >
                                          <motion.div
                                            animate={{ x: localNotifications?.[sub.key as keyof typeof localNotifications] ? 20 : 4 }}
                                            className="absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm"
                                          />
                                        </button>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'registration' && (
                      <motion.div
                        key="registration"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="space-y-8 max-w-4xl"
                      >
                        {/* Registration Settings */}
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <Users size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Registration Settings</h3>
                                <p className="text-sm text-zinc-500">Control member registration behavior</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig({ 
                                registrationEnabled: config?.registrationEnabled,
                                trialEnabled: config?.trialEnabled 
                              }, 'registration_settings')}
                              disabled={isSaving === 'registration_settings'}
                              className={cn(
                                "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50",
                                isSaving === 'registration_settings' ? "bg-zinc-100 text-zinc-400" : 
                                justSaved === 'registration_settings' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                              )}
                            >
                              {isSaving === 'registration_settings' ? 'Saving...' : 
                               justSaved === 'registration_settings' ? (
                                 <>
                                   <Check size={16} />
                                   Saved!
                                 </>
                               ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                          </div>

                          <div className="space-y-6 flex-1">
                            <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                              <div>
                                <p className="font-bold text-zinc-900">Public Registration</p>
                                <p className="text-xs text-zinc-500">Allow new members to request registration via public link</p>
                              </div>
                              <button
                                onClick={() => setConfig(prev => prev ? ({ ...prev, registrationEnabled: !prev.registrationEnabled }) : null)}
                                className={cn(
                                  "w-12 h-6 rounded-full transition-all relative",
                                  config?.registrationEnabled ? "bg-zinc-900" : "bg-zinc-200"
                                )}
                              >
                                <motion.div
                                  animate={{ x: config?.registrationEnabled ? 24 : 4 }}
                                  className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm"
                                />
                              </button>
                            </div>

                            <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                              <div>
                                <p className="font-bold text-zinc-900">Public Trial Sessions</p>
                                <p className="text-xs text-zinc-500">Allow public users to book trial sessions</p>
                              </div>
                              <button
                                onClick={() => setConfig(prev => prev ? ({ ...prev, trialEnabled: !prev.trialEnabled }) : null)}
                                className={cn(
                                  "w-12 h-6 rounded-full transition-all relative",
                                  config?.trialEnabled ? "bg-zinc-900" : "bg-zinc-200"
                                )}
                              >
                                <motion.div
                                  animate={{ x: config?.trialEnabled ? 24 : 4 }}
                                  className="absolute top-1 w-4 h-4 rounded-full bg-white shadow-sm"
                                />
                              </button>
                            </div>

                            {config?.registrationEnabled && user && (
                              <div className="mt-6 p-4 bg-zinc-50 rounded-2xl border border-dashed border-zinc-200">
                                <div className="flex items-center justify-between mb-2">
                                  <p className="text-xs font-bold text-zinc-500 uppercase tracking-wider">Your Public Registration Link</p>
                                  <button 
                                    onClick={() => {
                                      const link = `${window.location.origin}?reg=${user.uid}`;
                                      navigator.clipboard.writeText(link);
                                      setCopied(true);
                                      setTimeout(() => setCopied(false), 2000);
                                    }}
                                    className="text-xs font-bold text-zinc-900 hover:underline flex items-center gap-1"
                                  >
                                    {copied ? <Check size={12} className="text-emerald-500" /> : <Copy size={12} />}
                                    {copied ? 'Copied!' : 'Copy Link'}
                                  </button>
                                </div>
                                <div className="bg-white p-3 rounded-xl border border-zinc-100 text-xs font-mono text-zinc-600 break-all select-all">
                                  {`${window.location.origin}?reg=${user.uid}`}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Terms & Conditions */}
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <FileText size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Terms & Conditions</h3>
                                <p className="text-sm text-zinc-500">Define the terms users must agree to during registration</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig({ termsAndConditions: localTerms }, 'terms')}
                              disabled={isSaving === 'terms'}
                              className={cn(
                                "flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all disabled:opacity-50",
                                isSaving === 'terms' ? "bg-zinc-100 text-zinc-400" : 
                                justSaved === 'terms' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800 shadow-lg shadow-zinc-200"
                              )}
                            >
                              {isSaving === 'terms' ? 'Saving...' : 
                               justSaved === 'terms' ? (
                                 <>
                                   <Check size={16} />
                                   Saved!
                                 </>
                               ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <label className="text-sm font-bold text-zinc-900">Markdown Editor</label>
                                <span className="text-[10px] text-zinc-400">Supports standard Markdown</span>
                              </div>
                              <textarea
                                value={localTerms}
                                onChange={(e) => setLocalTerms(e.target.value)}
                                placeholder="# Terms and Conditions&#10;&#10;1. General Rules...&#10;2. Privacy Policy..."
                                className="w-full h-[400px] p-6 bg-zinc-50 border border-zinc-100 rounded-3xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none font-mono"
                              />
                            </div>

                            <div className="space-y-4">
                              <label className="text-sm font-bold text-zinc-900">Preview</label>
                              <div className="w-full h-[400px] p-6 bg-white border border-zinc-100 rounded-3xl overflow-y-auto prose prose-zinc prose-sm max-w-none">
                                {localTerms ? (
                                  <Markdown>{localTerms}</Markdown>
                                ) : (
                                  <p className="text-zinc-400 italic">No terms defined. Start typing in the editor to see a preview.</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Trial Terms & Conditions */}
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <FileText size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Trial Terms & Conditions</h3>
                                <p className="text-sm text-zinc-500">Define the terms users must agree to during trial booking</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig({ trialTermsAndConditions: localTrialTerms }, 'trial_terms')}
                              disabled={isSaving === 'trial_terms'}
                              className={cn(
                                "flex items-center gap-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all disabled:opacity-50",
                                isSaving === 'trial_terms' ? "bg-zinc-100 text-zinc-400" : 
                                justSaved === 'trial_terms' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800 shadow-lg shadow-zinc-200"
                              )}
                            >
                              {isSaving === 'trial_terms' ? 'Saving...' : 
                               justSaved === 'trial_terms' ? (
                                 <>
                                   <Check size={16} />
                                   Saved!
                                 </>
                               ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <label className="text-sm font-bold text-zinc-900">Markdown Editor</label>
                                <span className="text-[10px] text-zinc-400">Supports standard Markdown</span>
                              </div>
                              <textarea
                                value={localTrialTerms}
                                onChange={(e) => setLocalTrialTerms(e.target.value)}
                                placeholder="# Trial Terms and Conditions&#10;&#10;1. General Rules...&#10;2. Privacy Policy..."
                                className="w-full h-[400px] p-6 bg-zinc-50 border border-zinc-100 rounded-3xl text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none font-mono"
                              />
                            </div>

                            <div className="space-y-4">
                              <label className="text-sm font-bold text-zinc-900">Preview</label>
                              <div className="w-full h-[400px] p-6 bg-white border border-zinc-100 rounded-3xl overflow-y-auto prose prose-zinc prose-sm max-w-none">
                                {localTrialTerms ? (
                                  <Markdown>{localTrialTerms}</Markdown>
                                ) : (
                                  <p className="text-zinc-400 italic">No terms defined. Start typing in the editor to see a preview.</p>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'evaluations' && (
                      <motion.div
                        key="evaluations"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-4xl"
                      >
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center justify-between mb-8">
                            <div className="flex items-center gap-3">
                              <div className="p-3 bg-zinc-900 rounded-2xl">
                                <Trophy size={24} className="text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-zinc-900">Evaluation Skills</h3>
                                <p className="text-sm text-zinc-500">Manage categories and skills for member evaluations</p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUpdateConfig({ evaluationSettings: localEvaluationSettings }, 'evaluations')}
                              disabled={isSaving === 'evaluations'}
                              className="px-6 py-3 bg-zinc-900 text-white rounded-xl font-bold hover:bg-zinc-800 transition-all flex items-center gap-2 disabled:opacity-50"
                            >
                              {isSaving === 'evaluations' ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                              {justSaved === 'evaluations' ? 'Saved!' : 'Save Settings'}
                            </button>
                          </div>

                          <div className="space-y-6">
                            {localEvaluationSettings?.categories.map((category, catIdx) => (
                              <div key={category.id} className="p-6 bg-zinc-50 rounded-3xl border border-zinc-100 space-y-4">
                                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                                  <div className="flex-1 flex items-center gap-4">
                                    <input
                                      type="text"
                                      value={category.name}
                                      onChange={(e) => {
                                        const newCats = [...(localEvaluationSettings?.categories || [])];
                                        newCats[catIdx].name = e.target.value;
                                        setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats });
                                      }}
                                      className="text-lg font-bold bg-transparent border-none focus:ring-0 p-0 text-zinc-900 placeholder:text-zinc-300 min-w-[200px]"
                                      placeholder="Category Name (e.g. Technical)"
                                    />
                                    <div className="h-6 w-px bg-zinc-200 hidden md:block" />
                                    <select
                                      value={category.activity || ''}
                                      onChange={(e) => {
                                        const newCats = [...(localEvaluationSettings?.categories || [])];
                                        newCats[catIdx].activity = e.target.value;
                                        setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats });
                                      }}
                                      className="text-xs font-bold text-zinc-500 bg-white border border-zinc-200 rounded-lg px-3 py-1.5 focus:ring-2 focus:ring-zinc-900/10 outline-none"
                                    >
                                      <option value="">All Activities</option>
                                      {config?.lists?.activities.map(a => <option key={a} value={a}>{a}</option>)}
                                    </select>
                                  </div>
                                  <button
                                    onClick={() => {
                                      const newCats = localEvaluationSettings?.categories.filter((_, i) => i !== catIdx);
                                      setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats || [] });
                                    }}
                                    className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-colors"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                                </div>

                                <div className="space-y-3">
                                  {category.skills.map((skill, skillIdx) => (
                                    <div key={skill.id} className="flex items-center gap-3 bg-white p-3 rounded-2xl border border-zinc-100">
                                      <div className="flex-1">
                                        <input
                                          type="text"
                                          value={skill.name}
                                          onChange={(e) => {
                                            const newCats = [...(localEvaluationSettings?.categories || [])];
                                            newCats[catIdx].skills[skillIdx].name = e.target.value;
                                            setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats });
                                          }}
                                          className="w-full text-sm font-medium bg-transparent border-none focus:ring-0 p-0 text-zinc-900 placeholder:text-zinc-300"
                                          placeholder="Skill Name (e.g. Dribbling)"
                                        />
                                      </div>
                                      <button
                                        onClick={() => {
                                          const newCats = [...(localEvaluationSettings?.categories || [])];
                                          newCats[catIdx].skills = newCats[catIdx].skills.filter((_, i) => i !== skillIdx);
                                          setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats });
                                        }}
                                        className="p-1.5 text-zinc-400 hover:text-rose-500 transition-colors"
                                      >
                                        <X size={16} />
                                      </button>
                                    </div>
                                  ))}
                                  <button
                                    onClick={() => {
                                      const newCats = [...(localEvaluationSettings?.categories || [])];
                                      newCats[catIdx].skills.push({ id: Math.random().toString(36).substr(2, 9), name: '' });
                                      setLocalEvaluationSettings({ ...localEvaluationSettings!, categories: newCats });
                                    }}
                                    className="w-full py-2 border-2 border-dashed border-zinc-200 rounded-2xl text-zinc-400 text-xs font-bold hover:border-zinc-900 hover:text-zinc-900 transition-all flex items-center justify-center gap-2"
                                  >
                                    <Plus size={14} /> Add Skill
                                  </button>
                                </div>
                              </div>
                            ))}

                            <button
                              onClick={() => {
                                setLocalEvaluationSettings({
                                  ...localEvaluationSettings!,
                                  categories: [
                                    ...(localEvaluationSettings?.categories || []),
                                    { id: Math.random().toString(36).substr(2, 9), name: '', skills: [] }
                                  ]
                                });
                              }}
                              className="w-full py-4 border-2 border-dashed border-zinc-200 rounded-3xl text-zinc-500 font-bold hover:border-zinc-900 hover:text-zinc-900 transition-all flex items-center justify-center gap-2"
                            >
                              <PlusCircle size={20} /> Add Category
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'logs' && (
                      <motion.div
                        key="logs"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="max-w-4xl"
                      >
                        {/* Email Log */}
                        <div className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm flex flex-col">
                          <div className="flex items-center gap-3 mb-8">
                            <div className="p-3 bg-zinc-100 rounded-2xl">
                              <History size={24} className="text-zinc-900" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">Sent Emails Log</h3>
                              <p className="text-sm text-zinc-500">History of all automated communications</p>
                            </div>
                          </div>

                          <div className="flex-1 overflow-y-auto max-h-[600px] space-y-4 pr-2 custom-scrollbar">
                            {sentEmails.length === 0 ? (
                              <div className="text-center py-10">
                                <Mail className="mx-auto text-zinc-200 mb-4" size={48} />
                                <p className="text-zinc-400">No emails sent yet</p>
                              </div>
                            ) : (
                              sentEmails.map((email) => (
                                <div key={email.id} className="p-4 bg-zinc-50 rounded-2xl border border-zinc-100 flex items-start gap-4">
                                  <div className={cn(
                                    "p-2 rounded-xl shrink-0",
                                    email.type === 'registration' ? "bg-blue-50 text-blue-600" :
                                    email.type === 'attendance' ? "bg-emerald-50 text-emerald-600" :
                                    email.type === 'payment' ? "bg-purple-50 text-purple-600" :
                                    "bg-amber-50 text-amber-600"
                                  )}>
                                    <Mail size={16} />
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <div className="flex justify-between items-start mb-1">
                                      <p className="font-bold text-zinc-900 truncate">{email.to}</p>
                                      <div className="flex items-center gap-2">
                                        <span className="text-[10px] text-zinc-400 whitespace-nowrap">{format(new Date(email.sentAt), 'MMM d, HH:mm')}</span>
                                        <button 
                                          onClick={() => setDeleteConfirm({ type: 'sent_emails', id: email.id, label: `Email to ${email.to}` })}
                                          className="p-1 text-zinc-300 hover:text-rose-500 transition-colors"
                                        >
                                          <Trash2 size={12} />
                                        </button>
                                      </div>
                                    </div>
                                    <p className="text-xs text-zinc-600 truncate">{email.subject}</p>
                                    <span className="inline-block mt-2 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                                      {email.type}
                                    </span>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'lists' && (
                      <motion.div
                        key="lists"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm"
                      >
                        <div className="flex items-center justify-between mb-8">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-indigo-100 rounded-2xl">
                              <Settings size={24} className="text-indigo-600" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">List Management</h3>
                              <p className="text-sm text-zinc-500">Configure dropdown options for member profiles</p>
                            </div>
                          </div>
                          <button
                            onClick={() => handleUpdateConfig({ lists: localLists }, 'lists')}
                            disabled={isSaving === 'lists'}
                            className={cn(
                              "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50",
                              isSaving === 'lists' ? "bg-zinc-100 text-zinc-400" : 
                              justSaved === 'lists' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                            )}
                          >
                            {isSaving === 'lists' ? (
                              <>
                                <Clock size={16} className="animate-spin" />
                                Saving...
                              </>
                            ) : justSaved === 'lists' ? (
                              <>
                                <Check size={16} />
                                Saved!
                              </>
                            ) : (
                              <>
                                <Save size={16} />
                                Save Lists
                              </>
                            )}
                          </button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                          {(Object.keys(localLists) as Array<keyof typeof localLists>).map((listKey) => (
                            <div key={listKey} className="space-y-3">
                              <label className="text-xs font-bold text-zinc-500 uppercase flex justify-between items-center">
                                {listKey.replace(/([A-Z])/g, ' $1').trim()}
                                <span className="text-[10px] lowercase font-normal">({localLists[listKey].length} items)</span>
                              </label>
                              <div className="space-y-2">
                                <div className="flex gap-2">
                                  <input
                                    type="text"
                                    id={`new-item-${listKey}`}
                                    placeholder={`Add new ${listKey.slice(0, -1)}...`}
                                    className="flex-1 px-3 py-1.5 text-sm bg-zinc-50 border border-zinc-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') {
                                        const val = e.currentTarget.value.trim();
                                        if (val && !localLists[listKey].includes(val)) {
                                          setLocalLists(prev => ({
                                            ...prev,
                                            [listKey]: [...prev[listKey], val]
                                          }));
                                          e.currentTarget.value = '';
                                        }
                                      }
                                    }}
                                  />
                                  <button
                                    onClick={() => {
                                      const input = document.getElementById(`new-item-${listKey}`) as HTMLInputElement;
                                      const val = input.value.trim();
                                      if (val && !localLists[listKey].includes(val)) {
                                        setLocalLists(prev => ({
                                          ...prev,
                                          [listKey]: [...prev[listKey], val]
                                        }));
                                        input.value = '';
                                      }
                                    }}
                                    className="p-2 bg-zinc-100 text-zinc-600 rounded-lg hover:bg-zinc-200 transition-colors"
                                  >
                                    <Plus size={16} />
                                  </button>
                                </div>
                                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-2 bg-zinc-50/50 rounded-xl border border-zinc-100">
                                  {localLists[listKey].map((item, idx) => (
                                    <span 
                                      key={idx} 
                                      className="inline-flex items-center gap-1 px-2 py-1 bg-white border border-zinc-200 rounded-md text-xs text-zinc-600 group"
                                    >
                                      {item}
                                      <button 
                                        onClick={() => {
                                          setLocalLists(prev => ({
                                            ...prev,
                                            [listKey]: prev[listKey].filter((_, i) => i !== idx)
                                          }));
                                        }}
                                        className="text-zinc-300 hover:text-rose-500 transition-colors"
                                      >
                                        <X size={12} />
                                      </button>
                                    </span>
                                  ))}
                                  {localLists[listKey].length === 0 && (
                                    <span className="text-[10px] text-zinc-400 italic">No items added</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'smtp' && user?.email === "anafj246@gmail.com" && (
                      <motion.div
                        key="smtp"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm max-w-2xl"
                      >
                        <div className="flex items-center justify-between mb-8">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-amber-100 rounded-2xl">
                              <Server size={24} className="text-amber-600" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">SMTP Settings</h3>
                              <p className="text-sm text-zinc-500">Configure your custom email server</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleUpdateConfig({ smtp: localSmtp! }, 'smtp')}
                              disabled={isSaving === 'smtp'}
                              className={cn(
                                "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50",
                                isSaving === 'smtp' ? "bg-zinc-100 text-zinc-400" : 
                                justSaved === 'smtp' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                              )}
                            >
                              {isSaving === 'smtp' ? 'Saving...' : 
                               justSaved === 'smtp' ? (
                                 <>
                                   <Check size={16} />
                                   Saved!
                                 </>
                               ) : (
                                <>
                                  <Save size={16} />
                                  Save
                                </>
                              )}
                            </button>
                            <button
                              onClick={async () => {
                                setIsSaving('test_smtp');
                                try {
                                  const res = await sendEmail(
                                    user!.email!,
                                    "SMTP Test Connection",
                                    "This is a test email to verify your SMTP settings.",
                                    'reminder',
                                    user!.uid,
                                    "<h1>SMTP Test</h1><p>This is a test email to verify your SMTP settings.</p>",
                                    localSmtp!
                                  );
                                  if (res.success) {
                                    alert("Test email sent successfully! Please check your inbox.");
                                  } else {
                                    alert("Failed to send test email: " + (res.error || "Unknown error"));
                                  }
                                } catch (err: any) {
                                  alert("Error testing connection: " + err.message);
                                } finally {
                                  setIsSaving(null);
                                }
                              }}
                              disabled={isSaving === 'test_smtp'}
                              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold bg-zinc-100 text-zinc-600 hover:bg-zinc-200 transition-all disabled:opacity-50"
                            >
                              {isSaving === 'test_smtp' ? 'Testing...' : (
                                <>
                                  <Send size={16} />
                                  Test Connection
                                </>
                              )}
                            </button>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-3">
                            <div className="p-2 bg-blue-100 rounded-xl mt-0.5">
                              <Info size={18} className="text-blue-600" />
                            </div>
                            <div>
                              <h4 className="font-bold text-blue-900 text-sm">Gmail Users</h4>
                              <p className="text-xs text-blue-700 mt-1 leading-relaxed">
                                If you are using Gmail, you <strong>must</strong> use an <strong>App Password</strong>. 
                                Your regular account password will not work. 
                                <br />
                                <a href="https://support.google.com/mail/answer/185833" target="_blank" rel="noopener noreferrer" className="underline font-bold">How to create an App Password</a>
                              </p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-zinc-500 uppercase">Host</label>
                              <input
                                type="text"
                                value={localSmtp?.host || ''}
                                onChange={(e) => setLocalSmtp(prev => prev ? ({ ...prev, host: e.target.value }) : null)}
                                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                placeholder="smtp.example.com"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-zinc-500 uppercase">Port</label>
                              <input
                                type="number"
                                value={localSmtp?.port || ''}
                                onChange={(e) => setLocalSmtp(prev => prev ? ({ ...prev, port: parseInt(e.target.value) || 0 }) : null)}
                                className="w-full px-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                placeholder="587"
                              />
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              id="smtp-secure"
                              checked={localSmtp?.secure || false}
                              onChange={(e) => setLocalSmtp(prev => prev ? ({ ...prev, secure: e.target.checked }) : null)}
                              className="w-4 h-4 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900"
                            />
                            <label htmlFor="smtp-secure" className="text-sm font-medium text-zinc-700">Use Secure Connection (SSL/TLS)</label>
                          </div>
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-zinc-500 uppercase">Username</label>
                            <input
                              type="text"
                              value={localSmtp?.user || ''}
                              onChange={(e) => setLocalSmtp(prev => prev ? ({ ...prev, user: e.target.value }) : null)}
                              className="w-full px-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              placeholder="user@example.com"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-xs font-bold text-zinc-500 uppercase">Password</label>
                            <input
                              type="password"
                              value={localSmtp?.pass || ''}
                              onChange={(e) => setLocalSmtp(prev => prev ? ({ ...prev, pass: e.target.value }) : null)}
                              className="w-full px-4 py-2 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                              placeholder="••••••••"
                            />
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'templates' && user?.email === "anafj246@gmail.com" && (
                      <motion.div
                        key="templates"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm max-w-3xl"
                      >
                        <div className="flex items-center justify-between mb-8">
                          <div className="flex items-center gap-3">
                            <div className="p-3 bg-blue-100 rounded-2xl">
                              <FileText size={24} className="text-blue-600" />
                            </div>
                            <div>
                              <h3 className="text-xl font-bold text-zinc-900">Email Templates</h3>
                              <p className="text-sm text-zinc-500">Customize the content of your emails</p>
                            </div>
                          </div>
                          <button
                            onClick={() => handleUpdateConfig({ templates: localTemplates! }, 'templates')}
                            disabled={isSaving === 'templates'}
                            className={cn(
                              "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition-all disabled:opacity-50",
                              isSaving === 'templates' ? "bg-zinc-100 text-zinc-400" : 
                              justSaved === 'templates' ? "bg-emerald-500 text-white" : "bg-zinc-900 text-white hover:bg-zinc-800"
                            )}
                          >
                            {isSaving === 'templates' ? 'Saving...' : 
                             justSaved === 'templates' ? (
                               <>
                                 <Check size={16} />
                                 Saved!
                               </>
                             ) : (
                              <>
                                <Save size={16} />
                                Save
                              </>
                            )}
                          </button>
                        </div>

                        <div className="space-y-6">
                          {['registration', 'trial_approved', 'trial_rejected', 'attendance', 'payment', 'reminder', 'evaluation', 'kit', 'whatsapp', 'onboarding_combined'].map((type) => (
                            <div key={type} className="space-y-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                              <h4 className="font-bold text-zinc-900 capitalize">{type.replace('_', ' ')} Template</h4>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-zinc-400 uppercase">Subject</label>
                                <input
                                  type="text"
                                  value={localTemplates?.[type as keyof typeof localTemplates]?.subject || ''}
                                  onChange={(e) => setLocalTemplates(prev => prev ? ({
                                    ...prev,
                                    [type]: { ...prev[type as keyof typeof localTemplates], subject: e.target.value }
                                  }) : null)}
                                  className="w-full px-3 py-2 bg-white border border-zinc-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                                />
                              </div>
                              <div className="space-y-1">
                                <label className="text-[10px] font-bold text-zinc-400 uppercase">Body</label>
                                <textarea
                                  rows={4}
                                  value={localTemplates?.[type as keyof typeof localTemplates]?.body || ''}
                                  onChange={(e) => setLocalTemplates(prev => prev ? ({
                                    ...prev,
                                    [type]: { ...prev[type as keyof typeof localTemplates], body: e.target.value }
                                  }) : null)}
                                  className="w-full px-3 py-2 bg-white border border-zinc-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none"
                                />
                                <p className="text-[10px] text-zinc-400 italic">Available tags: {'{name}'}, {'{date}'}, {'{status}'}, {'{amount}'}, {'{type}'}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {configTab === 'data' && user?.email === "anafj246@gmail.com" && (
                      <motion.div
                        key="data"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="bg-white p-8 rounded-[2.5rem] border border-zinc-100 shadow-sm max-w-2xl"
                      >
                        <div className="flex items-center gap-3 mb-8">
                          <div className="p-3 bg-rose-100 rounded-2xl">
                            <Trash2 size={24} className="text-rose-600" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-zinc-900">Data Management</h3>
                            <p className="text-sm text-zinc-500">Destructive actions for your data</p>
                          </div>
                        </div>
                        
                        <div className="p-6 bg-rose-50 rounded-3xl border border-rose-100 flex items-center justify-between">
                          <div>
                            <h4 className="font-bold text-rose-900">Clear Attendance Records</h4>
                            <p className="text-xs text-rose-600 mt-1">This will permanently delete all attendance history for all members.</p>
                          </div>
                          <button
                            onClick={() => setDeleteConfirm({ type: 'attendance', id: 'all', label: 'All Attendance' })}
                            className="px-6 py-3 bg-rose-600 text-white rounded-xl text-sm font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200"
                          >
                            Clear All Records
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>

        {/* Modals */}
        <Modal 
          isOpen={isModalOpen} 
          onClose={() => { setIsModalOpen(false); setEditingItem(null); setScannedData({}); }} 
          title={editingItem ? `Edit ${modalType === 'user' ? 'User' : modalType === 'member' ? 'Member' : modalType}` : modalType === 'evaluation' ? 'Member Evaluation' : `Add New ${modalType === 'user' ? 'User' : modalType === 'member' ? 'Member' : modalType}`}
          maxWidth={modalType === 'user' || modalType === 'member' || modalType === 'evaluation' ? 'max-w-4xl' : 'max-w-lg'}
          variant={modalType === 'user' || modalType === 'member' || modalType === 'evaluation' ? 'side' : 'center'}
        >
          {modalType === 'evaluation' ? (
            renderEvaluationModal()
          ) : modalType === 'expense' ? (
            <form onSubmit={handleAddExpense} className="space-y-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Expense Title</label>
                  <input
                    name="title"
                    required
                    defaultValue={editingItem?.title}
                    placeholder="e.g., Coach Ahmed Salary - March"
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Amount (AED)</label>
                    <input
                      name="amount"
                      type="number"
                      required
                      defaultValue={editingItem?.amount}
                      placeholder="0.00"
                      className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Date</label>
                    <input
                      name="date"
                      type="date"
                      required
                      defaultValue={editingItem?.date || format(new Date(), 'yyyy-MM-dd')}
                      className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Category</label>
                  <select
                    name="category"
                    required
                    defaultValue={editingItem?.category || (localLists.expenseCategories?.[0] || 'Other')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  >
                    <option value="">Select Category</option>
                    {localLists.expenseCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Description (Optional)</label>
                  <textarea
                    name="description"
                    rows={3}
                    defaultValue={editingItem?.description}
                    placeholder="Add more details about this expense..."
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none"
                  />
                </div>
              </div>
              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingItem ? 'Update Expense' : 'Add Expense'}
                </button>
              </div>
            </form>
          ) : modalType === 'member' ? (
            <form onSubmit={handleAddMember} className="space-y-8">
              <div className="space-y-8">
                {/* Section: Identity */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <UserIcon size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Identity & Contact</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Full Name (English)</label>
                      <input
                        name="name"
                        required
                        key={`name-${scannedData.name || editingItem?.name}`}
                        defaultValue={scannedData.name || editingItem?.name}
                        placeholder="John Doe"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Full Name (Arabic)</label>
                      <input
                        name="nameArabic"
                        key={`nameArabic-${scannedData.nameArabic || editingItem?.nameArabic}`}
                        defaultValue={scannedData.nameArabic || editingItem?.nameArabic}
                        placeholder="جون دو"
                        dir="rtl"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 text-right transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
                      <input
                        name="email"
                        type="email"
                        required
                        defaultValue={editingItem?.email}
                        placeholder="john@example.com"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Category</label>
                      <select
                        name="category"
                        defaultValue={editingItem?.category || (localLists.memberCategories?.[0] || '')}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Category</option>
                        {localLists.memberCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Phone Number</label>
                      <input
                        name="phone"
                        defaultValue={editingItem?.phone}
                        placeholder="+971 ..."
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">WhatsApp</label>
                      <input
                        name="whatsapp"
                        defaultValue={editingItem?.whatsapp}
                        placeholder="+971 ..."
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Section: Personal Details */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <Calendar size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Personal Details</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Birthday</label>
                      <input
                        name="birthday"
                        type="date"
                        key={`birthday-${scannedData.birthday || editingItem?.birthday}`}
                        defaultValue={scannedData.birthday || editingItem?.birthday}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Nationality</label>
                      <input
                        name="nationality"
                        key={`nationality-${scannedData.nationality || editingItem?.nationality}`}
                        defaultValue={scannedData.nationality || editingItem?.nationality}
                        placeholder="United Arab Emirates"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Emirates ID</label>
                      <input
                        name="emiratesId"
                        key={`emiratesId-${scannedData.emiratesId || editingItem?.emiratesId}`}
                        defaultValue={scannedData.emiratesId || editingItem?.emiratesId}
                        placeholder="784-XXXX-XXXXXXX-X"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Status</label>
                      <select
                        name="status"
                        defaultValue={editingItem?.status || (localLists.memberStatuses?.[0] || 'active')}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        {localLists.memberStatuses.map(status => <option key={status} value={status}>{status.charAt(0).toUpperCase() + status.slice(1)}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Onboarding Status */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <CheckCircle2 size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Onboarding Status</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className="flex items-center gap-3 p-4 bg-zinc-50 border border-zinc-100 rounded-2xl cursor-pointer hover:bg-zinc-100 transition-all">
                      <input
                        type="checkbox"
                        name="receivedKit"
                        defaultChecked={editingItem?.receivedKit}
                        className="w-5 h-5 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900"
                      />
                      <span className="text-sm font-medium text-zinc-700">Received Kit</span>
                    </label>
                    <label className="flex items-center gap-3 p-4 bg-zinc-50 border border-zinc-100 rounded-2xl cursor-pointer hover:bg-zinc-100 transition-all">
                      <input
                        type="checkbox"
                        name="joinedWhatsApp"
                        defaultChecked={editingItem?.joinedWhatsApp}
                        className="w-5 h-5 rounded border-zinc-300 text-zinc-900 focus:ring-zinc-900"
                      />
                      <span className="text-sm font-medium text-zinc-700">Joined WhatsApp Group</span>
                    </label>
                  </div>
                </div>

                {/* Section: Sports Profile */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <Trophy size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Sports Profile</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Location</label>
                      <select
                        name="location"
                        defaultValue={editingItem?.location || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Location</option>
                        {localLists.locations.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Age Group</label>
                      <select
                        name="ageGroup"
                        defaultValue={editingItem?.ageGroup || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Age Group</option>
                        {localLists.ageGroups.map(ag => <option key={ag} value={ag}>{ag}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Level</label>
                      <select
                        name="level"
                        defaultValue={editingItem?.level || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Level</option>
                        {localLists.levels.map(lvl => <option key={lvl} value={lvl}>{lvl}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Coach</label>
                      <select
                        name="coach"
                        defaultValue={editingItem?.coach || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Coach</option>
                        {localLists.coaches.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Activity</label>
                      <select
                        name="activity"
                        defaultValue={editingItem?.activity || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="">Select Activity</option>
                        {localLists.activities.map(a => <option key={a} value={a}>{a}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Family & Notes */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <Users size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Family & Notes</h4>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Parents Information</label>
                      <textarea
                        name="parentsInformation"
                        defaultValue={editingItem?.parentsInformation || ''}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 min-h-[80px] resize-none transition-all"
                        placeholder="Names, contact details, etc."
                      />
                    </div>
                  </div>
                </div>

                {/* Section: Attachments */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <Camera size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Documents & Photos</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-3 ml-1">Profile Image</label>
                      <div className="flex items-center gap-4">
                        {editingItem?.profileImage && !removedAttachments.has('profileImage') && (
                          <div className="relative group w-16 h-16 shrink-0">
                            <img 
                              src={editingItem.profileImage} 
                              alt="Current Profile" 
                              className="w-16 h-16 object-cover rounded-xl border border-zinc-200 cursor-pointer"
                              referrerPolicy="no-referrer"
                              onClick={() => setPreviewImage(editingItem.profileImage)}
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center gap-1">
                              <button 
                                type="button"
                                onClick={() => setRemovedAttachments(prev => new Set(prev).add('profileImage'))}
                                className="p-1.5 bg-rose-500 rounded-lg text-white transition-colors"
                              >
                                <X size={12} />
                              </button>
                            </div>
                          </div>
                        )}
                        <input
                          name="profileImageFile"
                          type="file"
                          accept="image/*"
                          className="w-full text-xs text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-white file:text-zinc-700 hover:file:bg-zinc-100 file:shadow-sm"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-3 ml-1 flex justify-between items-center">
                        Emirates ID
                        <button
                          type="button"
                          disabled={isScanning}
                          onClick={() => {
                            const fileInput = document.querySelector('input[name="idImageFile"]') as HTMLInputElement;
                            if (fileInput?.files?.[0]) {
                              handleScanID(fileInput.files[0]);
                            } else {
                              alert("Please select an ID image first.");
                            }
                          }}
                          className="text-[10px] text-zinc-900 bg-white border border-zinc-100 px-2 py-1 rounded-lg hover:bg-zinc-50 disabled:opacity-50 flex items-center gap-1 shadow-sm transition-all"
                        >
                          {isScanning ? <Clock size={10} className="animate-spin" /> : <Search size={10} />}
                          {isScanning ? "Scanning..." : "Scan ID"}
                        </button>
                      </label>
                      <div className="flex items-center gap-4">
                        {editingItem?.idImage && !removedAttachments.has('idImage') && (
                          <div className="relative group w-16 h-16 shrink-0">
                            {editingItem.idImage.startsWith('data:application/pdf') ? (
                              <div className="w-16 h-16 bg-white rounded-xl border border-zinc-200 flex items-center justify-center">
                                <FileText size={20} className="text-zinc-400" />
                              </div>
                            ) : (
                              <img 
                                src={editingItem.idImage} 
                                alt="Current ID" 
                                className="w-16 h-16 object-cover rounded-xl border border-zinc-200 cursor-pointer"
                                referrerPolicy="no-referrer"
                                onClick={() => setPreviewImage(editingItem.idImage)}
                              />
                            )}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center gap-1">
                              <button 
                                type="button"
                                onClick={() => setRemovedAttachments(prev => new Set(prev).add('idImage'))}
                                className="p-1.5 bg-rose-500 rounded-lg text-white transition-colors"
                              >
                                <X size={12} />
                              </button>
                            </div>
                          </div>
                        )}
                        <input
                          name="idImageFile"
                          type="file"
                          accept="image/*,application/pdf"
                          className="w-full text-xs text-zinc-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-semibold file:bg-white file:text-zinc-700 hover:file:bg-zinc-100 file:shadow-sm"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-8 flex gap-4 sticky bottom-0 bg-white pb-4 mt-auto">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-[2] py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Clock size={20} className="animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Save size={20} />
                      {editingItem ? 'Save Member Changes' : 'Register New Member'}
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : modalType === 'registration_request' ? (
            <form onSubmit={handleUpdateRegistrationRequest} className="space-y-8">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
                    <input name="name" required defaultValue={editingItem?.name} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Email</label>
                    <input name="email" type="email" required defaultValue={editingItem?.email} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Status</label>
                    <select name="status" defaultValue={editingItem?.status} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                      <option value="pending">Pending</option>
                      <option value="approved">Approved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Admin Notes</label>
                    <textarea name="notes" defaultValue={editingItem?.notes} rows={4} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none" placeholder="Add comments, requirements, or reasons for status update..." />
                  </div>
                </div>
              </div>
              <div className="pt-8 flex gap-4 sticky bottom-0 bg-white pb-4 mt-auto">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all">Cancel</button>
                <button type="submit" disabled={isSubmitting} className="flex-[2] py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200 disabled:opacity-50 flex items-center justify-center gap-2">
                  {isSubmitting ? 'Saving...' : 'Update Request'}
                </button>
              </div>
            </form>
          ) : modalType === 'trial_request' ? (
            <form onSubmit={handleUpdateTrialRequest} className="space-y-8">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
                    <input name="name" required defaultValue={editingItem?.name} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Email</label>
                    <input name="email" type="email" required defaultValue={editingItem?.email} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Status</label>
                    <select name="status" defaultValue={editingItem?.status} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10">
                      <option value="pending">Pending</option>
                      <option value="approved">Approved</option>
                      <option value="rejected">Rejected</option>
                    </select>
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Admin Notes</label>
                    <textarea name="notes" defaultValue={editingItem?.notes} rows={4} className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none" placeholder="Add comments, requirements, or reasons for status update..." />
                  </div>
                </div>
              </div>
              <div className="pt-8 flex gap-4 sticky bottom-0 bg-white pb-4 mt-auto">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all">Cancel</button>
                <button type="submit" disabled={isSubmitting} className="flex-[2] py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200 disabled:opacity-50 flex items-center justify-center gap-2">
                  {isSubmitting ? 'Saving...' : 'Update Request'}
                </button>
              </div>
            </form>
          ) : modalType === 'user' ? (
            <form onSubmit={handleAddUser} className="space-y-8">
              <div className="space-y-8">
                {/* Section: Identity */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <UserIcon size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Identity & Contact</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Full Name</label>
                      <input
                        name="name"
                        required
                        defaultValue={editingItem?.name}
                        placeholder="e.g., Coach Ahmed"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Email Address</label>
                      <input
                        name="email"
                        type="email"
                        required
                        defaultValue={editingItem?.email}
                        placeholder="coach@example.com"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Phone Number</label>
                      <input
                        name="phone"
                        defaultValue={editingItem?.phone}
                        placeholder="+971 50 123 4567"
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Role</label>
                      <select
                        name="role"
                        required
                        defaultValue={editingItem?.role || 'staff'}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="staff">Staff Member</option>
                        <option value="coach">Professional Coach</option>
                        <option value="admin">System Administrator</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Section: Permissions */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <Shield size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Access Control</h4>
                  </div>
                  <p className="text-xs text-zinc-500 bg-zinc-50 p-3 rounded-xl border border-zinc-100">
                    Select specific pages this user can access. If none are selected, the default permissions for their role will be applied.
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    {AVAILABLE_PAGES.map(page => (
                      <label key={page.id} className="flex items-center gap-3 p-3 bg-white border border-zinc-100 rounded-2xl cursor-pointer hover:border-zinc-300 hover:bg-zinc-50 transition-all group">
                        <div className="relative flex items-center justify-center">
                          <input
                            type="checkbox"
                            name="permissions"
                            value={page.id}
                            defaultChecked={editingItem?.permissions?.includes(page.id)}
                            className="peer w-5 h-5 rounded-lg border-zinc-200 text-zinc-900 focus:ring-zinc-900/10 transition-all"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <page.icon size={16} className="text-zinc-400 group-hover:text-zinc-900 transition-colors" />
                          <span className="text-xs font-bold text-zinc-600 group-hover:text-zinc-900 transition-colors">{page.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Section: Additional */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-zinc-900">
                    <FileText size={18} className="text-zinc-400" />
                    <h4 className="text-sm font-bold uppercase tracking-wider">Administration</h4>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Account Status</label>
                      <select
                        name="status"
                        required
                        defaultValue={editingItem?.status || 'active'}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 transition-all appearance-none"
                      >
                        <option value="active">Active Access</option>
                        <option value="disabled">Disabled / Suspended</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5 ml-1">Internal Notes</label>
                      <textarea
                        name="notes"
                        defaultValue={editingItem?.notes}
                        placeholder="Add any internal notes about this user's role or access..."
                        rows={3}
                        className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 resize-none transition-all"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-8 flex gap-4 sticky bottom-0 bg-white pb-4 mt-auto">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-4 bg-zinc-100 text-zinc-900 rounded-2xl font-bold hover:bg-zinc-200 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-[2] py-4 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-200 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <Clock size={20} className="animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Save size={20} />
                      {editingItem ? 'Update User Account' : 'Create User Account'}
                    </>
                  )}
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleAddPayment} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Member</label>
                <div className="relative">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search active member..."
                      value={memberSearch}
                      onChange={(e) => {
                        setMemberSearch(e.target.value);
                        setIsMemberDropdownOpen(true);
                        if (e.target.value === '') setSelectedMember(null);
                      }}
                      onFocus={() => setIsMemberDropdownOpen(true)}
                      className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10 pr-10"
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400">
                      <Search size={18} />
                    </div>
                  </div>

                  <AnimatePresence>
                    {isMemberDropdownOpen && (
                      <>
                        <div 
                          className="fixed inset-0 z-10" 
                          onClick={() => setIsMemberDropdownOpen(false)}
                        />
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="absolute left-0 right-0 mt-2 bg-white border border-zinc-100 rounded-2xl shadow-xl z-20 max-h-60 overflow-y-auto custom-scrollbar"
                        >
                          {members
                            .filter(m => m.status === (localLists.memberStatuses?.[0] || 'active') && m.name.toLowerCase().includes(memberSearch.toLowerCase()))
                            .map(m => (
                              <button
                                key={m.id}
                                type="button"
                                onClick={() => {
                                  setSelectedMember(m);
                                  setMemberSearch(m.name);
                                  setIsMemberDropdownOpen(false);
                                }}
                                className={cn(
                                  "w-full px-4 py-3 text-left hover:bg-zinc-50 transition-colors flex items-center justify-between",
                                  selectedMember?.id === m.id && "bg-zinc-50"
                                )}
                              >
                                <span className="font-medium text-zinc-900">{m.name}</span>
                                {selectedMember?.id === m.id && <Check size={16} className="text-emerald-600" />}
                              </button>
                            ))}
                          {members.filter(m => m.status === (localLists.memberStatuses?.[0] || 'active') && m.name.toLowerCase().includes(memberSearch.toLowerCase())).length === 0 && (
                            <div className="px-4 py-8 text-center text-zinc-500 text-sm">
                              No active members found
                            </div>
                          )}
                        </motion.div>
                      </>
                    )}
                  </AnimatePresence>
                </div>
                <input type="hidden" name="memberId" value={selectedMember?.id || ''} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Amount ($)</label>
                  <input
                    name="amount"
                    type="number"
                    required
                    defaultValue={editingItem?.amount}
                    placeholder="50"
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Date</label>
                  <input
                    name="date"
                    type="date"
                    required
                    defaultValue={editingItem?.date || format(new Date(), 'yyyy-MM-dd')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Membership Start</label>
                  <input
                    name="startDate"
                    type="date"
                    defaultValue={editingItem?.startDate}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Membership End</label>
                  <input
                    name="endDate"
                    type="date"
                    defaultValue={editingItem?.endDate}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Fees Description</label>
                  <select
                    name="feesDescription"
                    required
                    defaultValue={editingItem?.feesDescription || (localLists.feesDescriptions?.[0] || '')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  >
                    {localLists.feesDescriptions.map(desc => <option key={desc} value={desc}>{desc}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Period</label>
                  <select
                    name="period"
                    required
                    defaultValue={editingItem?.period || (localLists.periods?.[0] || '')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  >
                    {localLists.periods.map(p => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Payment Option</label>
                  <select
                    name="paymentOption"
                    required
                    defaultValue={editingItem?.paymentOption || (localLists.paymentOptions?.[0] || '')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  >
                    {localLists.paymentOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Status</label>
                  <select
                    name="status"
                    required
                    defaultValue={editingItem?.status || (localLists.paymentStatuses?.[0] || 'paid')}
                    className="w-full px-4 py-3 bg-zinc-50 border border-zinc-100 rounded-xl focus:outline-none focus:ring-2 focus:ring-zinc-900/10"
                  >
                    {localLists.paymentStatuses.map(status => <option key={status} value={status}>{status.charAt(0).toUpperCase() + status.slice(1)}</option>)}
                  </select>
                </div>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-semibold hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-200 mt-4 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting && <Clock size={20} className="animate-spin" />}
                {editingItem ? 'Save Changes' : 'Record Payment'}
              </button>
            </form>
          )}
        </Modal>

        {/* Lightbox Preview */}
        <AnimatePresence>
          {previewImage && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setPreviewImage(null)}
                className="absolute inset-0 bg-zinc-900/90 backdrop-blur-md"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative max-w-4xl max-h-[90vh] z-10"
              >
                <img 
                  src={previewImage} 
                  alt="Preview" 
                  className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl border border-white/10"
                  referrerPolicy="no-referrer"
                />
                <button 
                  onClick={() => setPreviewImage(null)}
                  className="absolute -top-4 -right-4 p-2 bg-white text-zinc-900 rounded-full shadow-xl hover:bg-zinc-100 transition-colors"
                >
                  <X size={20} />
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Delete Confirmation Modal */}
        <AnimatePresence>
          {deleteConfirm && (
            <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setDeleteConfirm(null)}
                className="absolute inset-0 bg-zinc-900/40 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl p-8 text-center"
              >
                <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <Trash2 size={32} />
                </div>
                <h3 className="text-xl font-bold text-zinc-900 mb-2">
                  {deleteConfirm.id === 'all' ? 'Clear All Records' : 'Confirm Delete'}
                </h3>
                <p className="text-zinc-500 mb-8">
                  {deleteConfirm.id === 'all' 
                    ? `Are you sure you want to clear ALL ${deleteConfirm.type} records? This action cannot be undone.`
                    : <>Are you sure you want to delete <span className="font-bold text-zinc-900">"{deleteConfirm.label}"</span>? This action cannot be undone.</>
                  }
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => setDeleteConfirm(null)}
                    className="px-6 py-3 bg-zinc-100 text-zinc-600 font-bold rounded-xl hover:bg-zinc-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (deleteConfirm.id === 'all') {
                        if (deleteConfirm.type === 'attendance') handleClearAttendance();
                      } else {
                        handleDelete(deleteConfirm.type, deleteConfirm.id);
                      }
                    }}
                    disabled={isSaving === 'clear_attendance'}
                    className="px-6 py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 transition-colors shadow-lg shadow-rose-200 disabled:opacity-50"
                  >
                    {isSaving === 'clear_attendance' ? 'Clearing...' : (deleteConfirm.id === 'all' ? 'Clear All' : 'Delete')}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}
