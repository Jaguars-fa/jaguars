# Deployment Guide for Etisalat (e&) Domain

This guide provides step-by-step instructions to deploy your application to your own server and point your Etisalat (e&) domain to it.

## Prerequisites

1.  **A Server (VPS):** You need a server with Docker and Docker Compose installed. (e.g., Ubuntu 22.04).
2.  **Domain Access:** Access to your Etisalat (e&) domain control panel.
3.  **Firebase Project:** Your own Firebase project (if using Firestore/Auth).

## Step 1: Prepare the Code

1.  **Export Code:** Download the project as a ZIP from AI Studio or push it to a private GitHub repository.
2.  **Upload to Server:** Transfer the files to your server using SCP, SFTP, or `git clone`.

## Step 2: Configure Environment Variables

1.  On your server, navigate to the project directory.
2.  Create a `.env` file:
    ```bash
    cp .env.example .env
    ```
3.  Edit the `.env` file and fill in your production values:
    *   `GEMINI_API_KEY`: Your Google Gemini API key.
    *   `EMAIL_HOST`, `EMAIL_USER`, `EMAIL_PASS`: Your SMTP credentials for sending emails.
    *   `FIREBASE_CONFIG`: (If applicable) Update `firebase-applet-config.json` with your new Firebase project details.

## Step 3: Deploy with Docker

We have provided a `Dockerfile` and `docker-compose.yml` for easy deployment.

1.  **Run the deployment script:**
    ```bash
    chmod +x deploy.sh
    ./deploy.sh
    ```
    This will build the container and start the application on port 3000.

## Step 4: Configure Your Domain (Etisalat e&)

1.  **Find your Server IP:** Get the public IP address of your server.
2.  **Update DNS Records:**
    *   Log in to your Etisalat domain management portal.
    *   Go to **DNS Management**.
    *   Add an **A Record**:
        *   **Host:** `@` (or your subdomain like `app`)
        *   **Value:** `[Your Server IP]`
        *   **TTL:** `3600` (default)
3.  **Wait for Propagation:** DNS changes can take up to 24-48 hours to propagate globally, but usually happen within an hour.

## Step 5: (Optional) Set up a Reverse Proxy (Nginx)

For production, it's recommended to use Nginx to handle SSL (HTTPS) and route traffic from port 80/443 to port 3000.

1.  **Install Nginx:** `sudo apt update && sudo apt install nginx`
2.  **Configure Nginx:** Create a file at `/etc/nginx/sites-available/yourdomain.com`:
    ```nginx
    server {
        listen 80;
        server_name yourdomain.com;

        location / {
            proxy_pass http://localhost:3000;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_cache_bypass $http_upgrade;
        }
    }
    ```
3.  **Enable and Restart:**
    ```bash
    sudo ln -s /etc/nginx/sites-available/yourdomain.com /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl restart nginx
    ```
4.  **SSL (HTTPS):** Use Certbot to get a free SSL certificate:
    ```bash
    sudo apt install certbot python3-certbot-nginx
    sudo certbot --nginx -d yourdomain.com
    ```

## Troubleshooting

*   **Logs:** Check application logs using `docker-compose logs -f`.
*   **Port 3000:** Ensure your server's firewall (e.g., `ufw`) allows traffic on port 3000 or port 80/443 if using Nginx.
