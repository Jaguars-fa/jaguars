#!/bin/bash

# Deployment script for Etisalat (e&) Domain

echo "🚀 Starting deployment process..."

# 1. Check for .env file
if [ ! -f .env ]; then
    echo "❌ Error: .env file not found. Please create one based on .env.example"
    exit 1
fi

# 2. Build and start the container
echo "📦 Building and starting the container..."
docker-compose up -d --build

echo "✅ Deployment complete! Your app should be running on http://localhost:3000"
echo "🌐 You can now configure your Etisalat (e&) domain to point to this server's IP."
