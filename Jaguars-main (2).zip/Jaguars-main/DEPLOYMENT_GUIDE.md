# 🚀 Complete Deployment Guide: AI Studio to Etisalat (e&) Domain

This guide provides a visual, step-by-step walkthrough to move your **Club Management App** from AI Studio to your own private hosting and connect it to your **Etisalat (e&)** domain.

---

## 📋 Table of Contents
1. [Step 1: Exporting Your Code from AI Studio](#step-1-exporting-your-code-from-ai-studio)
2. [Step 2: Setting Up Your Private Firebase Backend](#step-2-setting-up-your-private-firebase-backend)
3. [Step 3: Preparing Your Server (VPS)](#step-3-preparing-your-server-vps)
4. [Step 4: Deploying the Application](#step-4-deploying-the-application)
5. [Step 5: Connecting Your Etisalat (e&) Domain](#step-5-connecting-your-etisalat-e-domain)
6. [Step 6: Securing with HTTPS (SSL)](#step-6-securing-with-https-ssl)

---

## Step 1: Exporting Your Code from AI Studio

To get your application code, you need to download it from the AI Studio Editor.

### 📸 [Picture Placeholder: AI Studio Sidebar]
> *Description: A screenshot of the AI Studio left sidebar showing the Gear Icon (⚙️) at the bottom.*

1.  Open the **AI Studio Editor** (where you see the chat and files).
2.  Click the **Gear Icon (⚙️)** in the bottom-left corner.
3.  In the menu that appears, click **"Download ZIP"**.
4.  Save the file to your computer and unzip it.

---

## Step 2: Setting Up Your Private Firebase Backend

Since your app uses Firestore for data, you need your own Firebase project.

### 📸 [Picture Placeholder: Firebase Console]
> *Description: A screenshot of the Firebase Console (console.firebase.google.com) showing the "Add Project" button.*

1.  Go to [console.firebase.google.com](https://console.firebase.google.com/).
2.  Click **"Add Project"** and follow the prompts.
3.  **Enable Firestore:** Go to "Build" > "Firestore Database" and click **"Create Database"**.
4.  **Enable Authentication:** Go to "Build" > "Authentication" and enable the **Google** sign-in provider.
5.  **Get Config:** Go to Project Settings (⚙️ icon) > "General" > "Your apps" > "Web app" (click the `</>` icon).
6.  **Update Code:** Open `firebase-applet-config.json` in your unzipped folder and replace the values with the ones from the Firebase Console.

---

## Step 3: Preparing Your Server (VPS)

You need a server (like a VPS from Etisalat, AWS, or DigitalOcean) running **Ubuntu 22.04** or higher.

1.  **Install Docker:**
    ```bash
    sudo apt update
    sudo apt install docker.io docker-compose -y
    ```
2.  **Upload Code:** Use SFTP or SCP to upload your unzipped project folder to the server.

---

## Step 4: Deploying the Application

We have provided a `deploy.sh` script to make this easy.

1.  **Navigate to the folder:** `cd your-project-folder`
2.  **Set Environment Variables:**
    *   Copy the example file: `cp .env.example .env`
    *   Edit it: `nano .env`
    *   Add your `GEMINI_API_KEY` and SMTP details.
3.  **Run the script:**
    ```bash
    chmod +x deploy.sh
    ./deploy.sh
    ```

### 📸 [Picture Placeholder: Terminal Output]
> *Description: A screenshot showing the terminal output of the docker-compose build process finishing successfully.*

---

## Step 5: Connecting Your Etisalat (e&) Domain

Now you need to tell Etisalat where your server is.

### 📸 [Picture Placeholder: Etisalat DNS Panel]
> *Description: A screenshot of the Etisalat Domain Management DNS settings page.*

1.  Log in to your **Etisalat (e&)** domain portal.
2.  Find the **DNS Management** or **Nameserver** section.
3.  Add an **A Record**:
    *   **Host/Name:** `@`
    *   **Value/IP:** `[Your Server's Public IP Address]`
    *   **TTL:** `3600`
4.  Save changes. It may take 1-24 hours to update globally.

---

## Step 6: Securing with HTTPS (SSL)

To make your site secure (HTTPS), use Nginx and Certbot.

1.  **Install Nginx:** `sudo apt install nginx -y`
2.  **Configure Nginx:** Create a file at `/etc/nginx/sites-available/yourdomain.com` (replace with your domain).
3.  **Get SSL Certificate:**
    ```bash
    sudo apt install certbot python3-certbot-nginx -y
    sudo certbot --nginx -d yourdomain.com
    ```

### 📸 [Picture Placeholder: Secure Website]
> *Description: A screenshot of a browser address bar showing the padlock icon and "https://" next to your domain.*

---

## 🛠️ Support & Troubleshooting
*   **Logs:** Run `docker-compose logs -f` to see what the app is doing.
*   **Database:** Check your Firebase Console to see your data appearing in real-time.
*   **Firewall:** Ensure port 80 and 443 are open on your server.

**Note:** I have provided the text and structure for this guide. Since I am an AI, I cannot generate actual image files, but I have included descriptions of what images you should take at each step to complete your documentation.
